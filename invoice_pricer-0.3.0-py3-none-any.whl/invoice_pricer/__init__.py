"""
Invoice Pricer - Treasury futures invoice spread pricing.

Simple API:
    >>> from invoice_pricer import price_invoice_spread, build_curve
    >>> curve = build_curve([1,2,5,10,30], [0.043,0.041,0.042,0.045,0.046])
    >>> result = price_invoice_spread(
    ...     futures_price=110.25,
    ...     conversion_factor=0.8456,
    ...     coupon=0.04125,
    ...     maturity_years=9.5,
    ...     delivery_years=0.12,
    ...     curve=curve,
    ... )
    >>> print(f"Spread: {result.spread_bp:.2f} bp")

For advanced usage, import from submodules:
    >>> from invoice_pricer.bonds import bond_price, bond_yield, dv01
    >>> from invoice_pricer.curves import SwapCurve
    >>> from invoice_pricer.carry import calculate_carry
"""

from __future__ import annotations

__version__ = "0.3.0"

# Clean API (recommended)
from .api import (
    build_curve,
    price_invoice_spread,
    implied_yield,
    futures_dv01,
    forward_swap_rate,
    InvoiceSpread,
)
from .swaps import price_swap, swap_dv01, SwapValuation

# Practitioner API (streamlined for trading)
from .practitioner import (
    invoice_spread,
    invoice_spread_carry,
    invoice_spread_adjusted,
    spread_to_swap_rate,
    swap_pnl,
    SpreadResult,
    CarrySpreadResult,
    AdjustedSpreadResult,
    SwapPnL,
)

# Core types
from .curves import SwapCurve, SwapRateSplineCurve
from .bonds import Bond, TreasuryBond

# Legacy API (for backwards compatibility)
from .bonds import bond_price, bond_yield, dv01, modified_duration
from .curves import bootstrap_swap_curve
from .futures import analyze_futures, implied_yield_from_futures
from .invoice import (
    compute_invoice_spread,
    reverse_invoice_spread,
    compute_invoice_spread_adjusted,
    InvoiceSpreadResult,
    # New methodology (v2)
    compute_invoice_spread_v2,
    InvoiceSpreadResultV2,
    compute_accrued_interest,
    compute_yield_from_dirty_price,
    # Option-adjusted (v2)
    compute_invoice_spread_option_adjusted,
    OptionAdjustedInvoiceSpread,
)
from .sample_data import get_sample_scenario, build_sample_curve

__all__ = [
    # Version
    "__version__",
    # Clean API
    "build_curve",
    "price_invoice_spread",
    "implied_yield",
    "futures_dv01",
    "forward_swap_rate",
    "InvoiceSpread",
    # Swap pricing
    "price_swap",
    "swap_dv01",
    "SwapValuation",
    # Practitioner API
    "invoice_spread",
    "invoice_spread_carry",
    "invoice_spread_adjusted",
    "spread_to_swap_rate",
    "swap_pnl",
    "SpreadResult",
    "CarrySpreadResult",
    "AdjustedSpreadResult",
    "SwapPnL",
    # Core types
    "SwapCurve",
    "SwapRateSplineCurve",
    "Bond",
    "TreasuryBond",
    # Legacy
    "bond_price",
    "bond_yield",
    "dv01",
    "modified_duration",
    "bootstrap_swap_curve",
    "analyze_futures",
    "implied_yield_from_futures",
    "compute_invoice_spread",
    "reverse_invoice_spread",
    "compute_invoice_spread_adjusted",
    "InvoiceSpreadResult",
    # New methodology (v2)
    "compute_invoice_spread_v2",
    "InvoiceSpreadResultV2",
    "compute_accrued_interest",
    "compute_yield_from_dirty_price",
    # Option-adjusted (v2)
    "compute_invoice_spread_option_adjusted",
    "OptionAdjustedInvoiceSpread",
    "get_sample_scenario",
    "build_sample_curve",
]
