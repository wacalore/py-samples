"""
Invoice Spread Backtesting System.

Provides tools for backtesting invoice spread trading strategies.

Quick Start:
    >>> from invoice_pricer.backtest import (
    ...     BacktestEngine, BacktestData, ThresholdSignal, BacktestConfig
    ... )
    >>> data = BacktestData.from_dict_list(records, curve_builder)
    >>> signal = ThresholdSignal(upper_bp=20, lower_bp=-10, exit_band_bp=5)
    >>> config = BacktestConfig(target_dv01=1000, transaction_cost_bp=0.5)
    >>> engine = BacktestEngine(data, signal, config)
    >>> result = engine.run()
    >>> print(f"Sharpe: {result.sharpe_ratio:.2f}")

See Also:
    invoice_pricer.backtest.engine - Core backtest loop
    invoice_pricer.backtest.signals - Signal implementations
    invoice_pricer.backtest.analytics - Performance metrics
"""

from .data import (
    DailySnapshot,
    BacktestData,
)

from .position import (
    SpreadPosition,
    PositionState,
    PositionTracker,
    ClosedTrade,
    DailyPnL,
)

from .signals import (
    Signal,
    SignalOutput,
    ThresholdSignal,
    ExternalSignal,
    CompositeSignal,
    RollingZScoreSignal,
)

from .analytics import (
    TradeRecord,
    BacktestResult,
    Analytics,
    print_backtest_summary,
)

from .engine import (
    BacktestConfig,
    BacktestEngine,
    run_backtest,
)


__all__ = [
    # Data
    "DailySnapshot",
    "BacktestData",
    # Position
    "SpreadPosition",
    "PositionState",
    "PositionTracker",
    "ClosedTrade",
    "DailyPnL",
    # Signals
    "Signal",
    "SignalOutput",
    "ThresholdSignal",
    "ExternalSignal",
    "CompositeSignal",
    "RollingZScoreSignal",
    # Analytics
    "TradeRecord",
    "BacktestResult",
    "Analytics",
    "print_backtest_summary",
    # Engine
    "BacktestConfig",
    "BacktestEngine",
    "run_backtest",
]
