"""
Position Tracking for Invoice Spread Backtest.

Tracks P&L from underlying legs (futures and swap) rather than spread.

P&L Model:
    Long spread = Short futures + Receive fixed swap

    Futures P&L = -direction × (price_change) × futures_dv01 / price_dv01
    Swap P&L = -direction × (rate_change_bp) × swap_dv01
    Total P&L = Futures P&L + Swap P&L

Example:
    >>> tracker = PositionTracker()
    >>> tracker.open_position(
    ...     dt=date(2024, 1, 15),
    ...     futures_price=110.5,
    ...     swap_rate=0.0425,
    ...     target_dv01=1000.0,
    ...     futures_dv01=75.0,
    ...     swap_dv01=750.0,
    ...     direction="long",
    ...     ctd_cusip="912810TM",
    ... )
    >>> pnl = tracker.mark_to_market(
    ...     dt=date(2024, 1, 16),
    ...     futures_price=110.3,
    ...     swap_rate=0.0430,
    ...     ctd_cusip="912810TM",
    ... )
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Optional, List, Literal


@dataclass
class SpreadPosition:
    """
    An open invoice spread position tracking underlying legs.

    Long spread = Short futures + Receive fixed swap
    Short spread = Long futures + Pay fixed swap

    Attributes:
        entry_date: Date position was opened
        direction: "long" = short futures + receive fixed

        # Sizing
        target_dv01: Target DV01 exposure
        swap_notional: Swap notional amount
        futures_notional: Futures notional (hedge_ratio × swap_notional)

        # Entry levels
        entry_futures_price: Futures price at entry
        entry_swap_rate: Forward swap rate at entry (decimal)
        entry_spread_bp: Invoice spread at entry (for reference)
        entry_ctd_cusip: CTD CUSIP at entry

        # DV01s for P&L calculation
        futures_dv01: Futures DV01 per contract
        swap_dv01: Swap DV01 for position

        # Current levels (for daily P&L)
        last_futures_price: Most recent futures price
        last_swap_rate: Most recent swap rate

        # Cumulative P&L by leg
        futures_pnl: Cumulative P&L from futures leg
        swap_pnl: Cumulative P&L from swap leg

        # CTD tracking
        ctd_rolls: Number of CTD changes while in position
    """
    entry_date: date
    direction: Literal["long", "short"]

    # Sizing
    target_dv01: float
    swap_notional: float
    futures_notional: float

    # Entry levels
    entry_futures_price: float
    entry_swap_rate: float
    entry_spread_bp: float
    entry_ctd_cusip: str

    # DV01s
    futures_dv01: float  # Per contract
    swap_dv01: float     # Total for position

    # Current levels
    last_futures_price: float = field(default=0.0)
    last_swap_rate: float = field(default=0.0)

    # P&L by leg
    futures_pnl: float = field(default=0.0)
    swap_pnl: float = field(default=0.0)

    # CTD tracking
    ctd_rolls: int = field(default=0)

    def __post_init__(self):
        self.last_futures_price = self.entry_futures_price
        self.last_swap_rate = self.entry_swap_rate

    @property
    def direction_sign(self) -> int:
        """Return +1 for long spread, -1 for short spread."""
        return 1 if self.direction == "long" else -1

    @property
    def cumulative_pnl(self) -> float:
        """Total P&L from both legs."""
        return self.futures_pnl + self.swap_pnl


@dataclass
class PositionState:
    """
    Current state of position tracking.

    Attributes:
        position: Current open position (None if flat)
        current_futures_price: Most recent futures price
        current_swap_rate: Most recent swap rate
        current_spread_bp: Most recent spread (derived)
        current_ctd_cusip: Current CTD CUSIP
        unrealized_pnl: P&L on open position
        unrealized_futures_pnl: Futures leg P&L
        unrealized_swap_pnl: Swap leg P&L
        realized_pnl: P&L from closed positions
        ctd_rolls: Total CTD changes across all positions
    """
    position: Optional[SpreadPosition]
    current_futures_price: float
    current_swap_rate: float
    current_spread_bp: float
    current_ctd_cusip: str
    unrealized_pnl: float
    unrealized_futures_pnl: float
    unrealized_swap_pnl: float
    realized_pnl: float
    ctd_rolls: int

    @property
    def total_pnl(self) -> float:
        """Total P&L (realized + unrealized)."""
        return self.realized_pnl + self.unrealized_pnl

    @property
    def is_flat(self) -> bool:
        """True if no open position."""
        return self.position is None


@dataclass
class ClosedTrade:
    """Record of a closed trade with leg-level attribution."""
    entry_date: date
    exit_date: date
    direction: str

    # Spread levels (for reference)
    entry_spread_bp: float
    exit_spread_bp: float

    # Futures leg
    entry_futures_price: float
    exit_futures_price: float
    futures_pnl: float

    # Swap leg
    entry_swap_rate: float
    exit_swap_rate: float
    swap_pnl: float

    # Totals
    pnl: float
    holding_days: int
    ctd_rolls: int
    swap_notional: float
    futures_notional: float


@dataclass
class DailyPnL:
    """Daily P&L breakdown by leg."""
    date: date
    futures_pnl: float
    swap_pnl: float
    total_pnl: float
    futures_price: float
    swap_rate: float
    spread_bp: float
    ctd_cusip: str
    ctd_changed: bool


class PositionTracker:
    """
    Tracks invoice spread positions with leg-level P&L.

    P&L is computed from actual instrument moves:
    - Futures P&L from futures price changes
    - Swap P&L from swap rate changes

    The "spread" is tracked for reference but doesn't drive P&L.
    """

    def __init__(self):
        self._position: Optional[SpreadPosition] = None
        self._realized_pnl: float = 0.0
        self._realized_futures_pnl: float = 0.0
        self._realized_swap_pnl: float = 0.0
        self._current_futures_price: float = 0.0
        self._current_swap_rate: float = 0.0
        self._current_spread_bp: float = 0.0
        self._current_ctd_cusip: str = ""
        self._total_ctd_rolls: int = 0
        self._closed_trades: List[ClosedTrade] = []
        self._daily_pnl_history: List[DailyPnL] = []

    @property
    def is_flat(self) -> bool:
        """True if no open position."""
        return self._position is None

    @property
    def closed_trades(self) -> List[ClosedTrade]:
        """List of all closed trades."""
        return self._closed_trades.copy()

    @property
    def daily_pnl_history(self) -> List[DailyPnL]:
        """List of daily P&L records."""
        return self._daily_pnl_history.copy()

    def open_position(
        self,
        dt: date,
        futures_price: float,
        swap_rate: float,
        spread_bp: float,
        target_dv01: float,
        futures_dv01: float,
        swap_dv01: float,
        hedge_ratio: float,
        direction: Literal["long", "short"],
        ctd_cusip: str,
    ) -> None:
        """
        Open a new position.

        Args:
            dt: Entry date
            futures_price: Current futures price
            swap_rate: Current forward swap rate (decimal, e.g., 0.0425)
            spread_bp: Current invoice spread (for reference)
            target_dv01: Desired DV01 exposure
            futures_dv01: Futures DV01 per contract
            swap_dv01: Total swap DV01 for position
            hedge_ratio: Futures notional / swap notional
            direction: "long" = short futures + receive fixed
            ctd_cusip: Current CTD CUSIP

        Raises:
            ValueError: If position already open
        """
        if self._position is not None:
            raise ValueError("Position already open - close first")

        # Size the position
        # swap_dv01 is total DV01, so swap_notional = target_dv01 / (swap_dv01 / swap_notional)
        # Actually, we receive swap_dv01 as total DV01 for the position
        # swap_notional can be derived or passed separately
        # For simplicity, use target_dv01 to size and track notionals via hedge_ratio

        # Assuming swap_dv01 is per $1 notional (as pv01), size accordingly
        # Actually from earlier code: swap_notional = target_dv01 / swap_pv01
        # Here swap_dv01 might be total. Let's keep it consistent with before.
        # We'll compute swap_notional assuming swap_dv01 is the total DV01 target
        swap_notional = target_dv01 / (swap_dv01 / 1_000_000) if swap_dv01 > 0 else 1_000_000
        # Actually simpler: just use target_dv01 relationship
        # If target_dv01 = 1000 and typical 10yr swap is ~$750 DV01 per $1M
        # Then notional = 1000 / 0.00075 = ~$1.33M
        # Let's just store notional as passed or derived

        # Simplify: swap_notional sized to achieve target_dv01
        # swap_dv01 passed is the DV01 for that notional
        swap_notional = target_dv01 * 1_000_000 / swap_dv01 if swap_dv01 > 0 else 1_000_000
        futures_notional = hedge_ratio * swap_notional

        self._position = SpreadPosition(
            entry_date=dt,
            direction=direction,
            target_dv01=target_dv01,
            swap_notional=swap_notional,
            futures_notional=futures_notional,
            entry_futures_price=futures_price,
            entry_swap_rate=swap_rate,
            entry_spread_bp=spread_bp,
            entry_ctd_cusip=ctd_cusip,
            futures_dv01=futures_dv01,
            swap_dv01=swap_dv01,
        )
        self._current_futures_price = futures_price
        self._current_swap_rate = swap_rate
        self._current_spread_bp = spread_bp
        self._current_ctd_cusip = ctd_cusip

    def mark_to_market(
        self,
        dt: date,
        futures_price: float,
        swap_rate: float,
        spread_bp: float,
        ctd_cusip: str,
    ) -> DailyPnL:
        """
        Mark position to current market levels.

        P&L computed from underlying legs:
        - Futures P&L = -direction × price_change × (futures_dv01 / 0.01)
          (since DV01 is per 1bp, price change in points needs conversion)
        - Swap P&L = -direction × rate_change_bp × swap_dv01

        Args:
            dt: Current date
            futures_price: Current futures price
            swap_rate: Current forward swap rate (decimal)
            spread_bp: Current invoice spread (for reference)
            ctd_cusip: Current CTD CUSIP

        Returns:
            DailyPnL with leg breakdown
        """
        ctd_changed = ctd_cusip != self._current_ctd_cusip

        if self._position is None:
            daily = DailyPnL(
                date=dt,
                futures_pnl=0.0,
                swap_pnl=0.0,
                total_pnl=0.0,
                futures_price=futures_price,
                swap_rate=swap_rate,
                spread_bp=spread_bp,
                ctd_cusip=ctd_cusip,
                ctd_changed=ctd_changed,
            )
            self._current_futures_price = futures_price
            self._current_swap_rate = swap_rate
            self._current_spread_bp = spread_bp
            self._current_ctd_cusip = ctd_cusip
            self._daily_pnl_history.append(daily)
            return daily

        # Track CTD roll
        if ctd_changed:
            self._position.ctd_rolls += 1
            self._total_ctd_rolls += 1

        # Calculate leg P&L
        # Long spread = Short futures + Receive fixed
        # Short futures: profit when price falls -> P&L = -1 × (new - old) × dv01_scaling
        # Receive fixed: profit when rates fall -> P&L = -1 × (new - old) × dv01

        direction = self._position.direction_sign

        # Futures P&L
        # 1 point move on $100k face = $1000
        # So: futures_pnl = -direction × Δprice × futures_notional / 100
        futures_price_change = futures_price - self._position.last_futures_price
        futures_pnl = (
            -direction
            * futures_price_change
            * self._position.futures_notional
            / 100  # Convert price points to P&L
        )

        # Swap P&L
        # On CTD switch, the swap "rolls" to match new CTD maturity
        # Treat roll as zero P&L (close old at market, open new at market)
        # Only compute swap P&L if CTD didn't change
        if ctd_changed:
            # Conceptual roll: reset swap reference, zero P&L
            swap_pnl = 0.0
        else:
            # Normal day: P&L from swap rate change
            swap_rate_change_bp = (swap_rate - self._position.last_swap_rate) * 10000
            swap_pnl = -direction * swap_rate_change_bp * self._position.swap_dv01

        total_pnl = futures_pnl + swap_pnl

        # Update position
        self._position.futures_pnl += futures_pnl
        self._position.swap_pnl += swap_pnl
        self._position.last_futures_price = futures_price
        self._position.last_swap_rate = swap_rate

        # Update tracker state
        self._current_futures_price = futures_price
        self._current_swap_rate = swap_rate
        self._current_spread_bp = spread_bp
        self._current_ctd_cusip = ctd_cusip

        daily = DailyPnL(
            date=dt,
            futures_pnl=futures_pnl,
            swap_pnl=swap_pnl,
            total_pnl=total_pnl,
            futures_price=futures_price,
            swap_rate=swap_rate,
            spread_bp=spread_bp,
            ctd_cusip=ctd_cusip,
            ctd_changed=ctd_changed,
        )
        self._daily_pnl_history.append(daily)
        return daily

    def close_position(
        self,
        dt: date,
        futures_price: float,
        swap_rate: float,
        spread_bp: float,
    ) -> ClosedTrade:
        """
        Close current position.

        Args:
            dt: Exit date
            futures_price: Exit futures price
            swap_rate: Exit swap rate
            spread_bp: Exit spread (for reference)

        Returns:
            ClosedTrade with full leg attribution

        Raises:
            ValueError: If no position open
        """
        if self._position is None:
            raise ValueError("No position to close")

        # Final mark to market
        self.mark_to_market(dt, futures_price, swap_rate, spread_bp, self._current_ctd_cusip)

        # Record totals
        futures_pnl = self._position.futures_pnl
        swap_pnl = self._position.swap_pnl
        total_pnl = futures_pnl + swap_pnl

        self._realized_pnl += total_pnl
        self._realized_futures_pnl += futures_pnl
        self._realized_swap_pnl += swap_pnl

        # Record closed trade
        holding_days = (dt - self._position.entry_date).days
        trade = ClosedTrade(
            entry_date=self._position.entry_date,
            exit_date=dt,
            direction=self._position.direction,
            entry_spread_bp=self._position.entry_spread_bp,
            exit_spread_bp=spread_bp,
            entry_futures_price=self._position.entry_futures_price,
            exit_futures_price=futures_price,
            futures_pnl=futures_pnl,
            entry_swap_rate=self._position.entry_swap_rate,
            exit_swap_rate=swap_rate,
            swap_pnl=swap_pnl,
            pnl=total_pnl,
            holding_days=holding_days,
            ctd_rolls=self._position.ctd_rolls,
            swap_notional=self._position.swap_notional,
            futures_notional=self._position.futures_notional,
        )
        self._closed_trades.append(trade)

        self._position = None
        self._current_spread_bp = spread_bp

        return trade

    def get_state(self) -> PositionState:
        """Get current position state."""
        unrealized = 0.0
        unrealized_futures = 0.0
        unrealized_swap = 0.0

        if self._position is not None:
            unrealized = self._position.cumulative_pnl
            unrealized_futures = self._position.futures_pnl
            unrealized_swap = self._position.swap_pnl

        return PositionState(
            position=self._position,
            current_futures_price=self._current_futures_price,
            current_swap_rate=self._current_swap_rate,
            current_spread_bp=self._current_spread_bp,
            current_ctd_cusip=self._current_ctd_cusip,
            unrealized_pnl=unrealized,
            unrealized_futures_pnl=unrealized_futures,
            unrealized_swap_pnl=unrealized_swap,
            realized_pnl=self._realized_pnl,
            ctd_rolls=self._total_ctd_rolls,
        )

    def reset(self) -> None:
        """Reset tracker to initial state."""
        self._position = None
        self._realized_pnl = 0.0
        self._realized_futures_pnl = 0.0
        self._realized_swap_pnl = 0.0
        self._current_futures_price = 0.0
        self._current_swap_rate = 0.0
        self._current_spread_bp = 0.0
        self._current_ctd_cusip = ""
        self._total_ctd_rolls = 0
        self._closed_trades = []
        self._daily_pnl_history = []
