"""
Backtest Data Management.

Data structures and loading utilities for invoice spread backtesting.

Example:
    >>> from invoice_pricer.backtest.data import DailySnapshot, BacktestData
    >>> snapshot = DailySnapshot(
    ...     date=date(2024, 1, 15),
    ...     curve=curve,
    ...     futures_price=110.5,
    ...     ctd_cusip="912810TM",
    ...     ctd_price=98.50,
    ...     ctd_cf=0.88,
    ...     ctd_coupon=0.04125,
    ...     ctd_maturity=date(2033, 11, 15),
    ...     contract="TY",
    ... )
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Dict, List, Optional, Iterator

from ..curves import SwapCurve


@dataclass
class DailySnapshot:
    """
    Single day's market data for backtesting.

    Attributes:
        date: Observation date
        curve: SOFR swap curve for the day
        futures_price: Treasury futures price
        ctd_cusip: CUSIP of the CTD bond
        ctd_price: CTD clean price
        ctd_cf: CTD conversion factor
        ctd_coupon: CTD annual coupon rate (decimal)
        ctd_maturity: CTD maturity date
        contract: Futures contract code (TY, FV, US, WN)
        delivery_date: Next delivery date (optional, computed if not provided)
    """
    date: date
    curve: SwapCurve
    futures_price: float
    ctd_cusip: str
    ctd_price: float
    ctd_cf: float
    ctd_coupon: float
    ctd_maturity: date
    contract: str
    delivery_date: Optional[date] = None

    def __post_init__(self):
        """Compute delivery date if not provided."""
        if self.delivery_date is None:
            self.delivery_date = self._estimate_delivery_date()

    def _estimate_delivery_date(self) -> date:
        """Estimate next delivery date based on contract month cycle."""
        # Treasury futures deliver in Mar, Jun, Sep, Dec
        # Delivery is typically last business day of delivery month
        year = self.date.year
        month = self.date.month

        # Find next delivery month
        delivery_months = [3, 6, 9, 12]
        for dm in delivery_months:
            if dm > month:
                return date(year, dm, 28)  # Approximate last day
        # Roll to next year
        return date(year + 1, 3, 28)


class BacktestData:
    """
    Container for historical backtest data.

    Provides indexed access to daily snapshots and helper methods
    for detecting CTD changes.
    """

    def __init__(self, snapshots: List[DailySnapshot]):
        """
        Initialize with list of daily snapshots.

        Args:
            snapshots: List of DailySnapshot, will be sorted by date
        """
        self._snapshots = sorted(snapshots, key=lambda s: s.date)
        self._by_date: Dict[date, DailySnapshot] = {
            s.date: s for s in self._snapshots
        }
        self._dates = [s.date for s in self._snapshots]

    def __len__(self) -> int:
        return len(self._snapshots)

    def __iter__(self) -> Iterator[DailySnapshot]:
        return iter(self._snapshots)

    def __getitem__(self, idx: int) -> DailySnapshot:
        return self._snapshots[idx]

    def get(self, dt: date) -> Optional[DailySnapshot]:
        """Get snapshot for a specific date."""
        return self._by_date.get(dt)

    def date_range(self) -> List[date]:
        """Return list of all dates in chronological order."""
        return self._dates.copy()

    @property
    def start_date(self) -> date:
        """First date in dataset."""
        return self._dates[0]

    @property
    def end_date(self) -> date:
        """Last date in dataset."""
        return self._dates[-1]

    def ctd_changed(self, dt: date) -> bool:
        """
        Check if CTD changed from previous day.

        Args:
            dt: Date to check

        Returns:
            True if CTD CUSIP differs from previous day, False otherwise
        """
        idx = self._dates.index(dt) if dt in self._dates else -1
        if idx <= 0:
            return False
        return self._snapshots[idx].ctd_cusip != self._snapshots[idx - 1].ctd_cusip

    def get_previous(self, dt: date) -> Optional[DailySnapshot]:
        """Get snapshot for the previous trading day."""
        idx = self._dates.index(dt) if dt in self._dates else -1
        if idx <= 0:
            return None
        return self._snapshots[idx - 1]

    @classmethod
    def from_dict_list(
        cls,
        records: List[dict],
        curve_builder,
    ) -> "BacktestData":
        """
        Build BacktestData from list of dictionaries.

        Args:
            records: List of dicts with keys:
                - date: date object
                - curve_tenors: list of tenors (years)
                - curve_rates: list of rates (decimal)
                - futures_price: float
                - ctd_cusip: str
                - ctd_price: float
                - ctd_cf: float
                - ctd_coupon: float
                - ctd_maturity: date
                - contract: str
            curve_builder: Function(tenors, rates) -> SwapCurve

        Returns:
            BacktestData instance
        """
        snapshots = []
        for rec in records:
            curve = curve_builder(rec["curve_tenors"], rec["curve_rates"])
            snapshot = DailySnapshot(
                date=rec["date"],
                curve=curve,
                futures_price=rec["futures_price"],
                ctd_cusip=rec["ctd_cusip"],
                ctd_price=rec["ctd_price"],
                ctd_cf=rec["ctd_cf"],
                ctd_coupon=rec["ctd_coupon"],
                ctd_maturity=rec["ctd_maturity"],
                contract=rec["contract"],
                delivery_date=rec.get("delivery_date"),
            )
            snapshots.append(snapshot)
        return cls(snapshots)

    def filter_by_contract(self, contract: str) -> "BacktestData":
        """Return new BacktestData filtered to specific contract."""
        filtered = [s for s in self._snapshots if s.contract == contract]
        return BacktestData(filtered)

    def slice(self, start: date, end: date) -> "BacktestData":
        """Return new BacktestData for date range [start, end]."""
        filtered = [s for s in self._snapshots if start <= s.date <= end]
        return BacktestData(filtered)
