"""
Backtest Engine for Invoice Spread Trading.

P&L is computed from underlying legs (futures + swap), not spread directly.

Example:
    >>> from invoice_pricer.backtest import BacktestEngine, BacktestData, ThresholdSignal, BacktestConfig
    >>> engine = BacktestEngine(data, signal, config)
    >>> result = engine.run()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional

from .data import DailySnapshot, BacktestData
from .position import PositionTracker, ClosedTrade, DailyPnL
from .signals import Signal, SignalOutput
from .analytics import BacktestResult, TradeRecord

from ..invoice import compute_invoice_spread_option_adjusted, OptionAdjustedInvoiceSpread
from ..curves import SwapCurve


@dataclass
class BacktestConfig:
    """
    Backtest configuration parameters.

    Attributes:
        target_dv01: Position size in DV01 terms
        transaction_cost_bp: Estimated round-trip cost in bp
        contract: Futures contract code (TY, FV, US, WN)
        min_holding_days: Minimum days to hold position
        max_holding_days: Maximum days to hold (force exit)
        verbose: Print progress during backtest
    """
    target_dv01: float = 1000.0
    transaction_cost_bp: float = 0.5
    contract: str = "TY"
    min_holding_days: int = 0
    max_holding_days: Optional[int] = None
    verbose: bool = False


@dataclass
class DailyState:
    """Record of state at end of each day."""
    date: date
    futures_price: float
    swap_rate: float
    spread_bp: float
    position: int  # 1=long, -1=short, 0=flat
    futures_pnl: float
    swap_pnl: float
    daily_pnl: float
    cumulative_pnl: float
    ctd_cusip: str
    ctd_changed: bool
    signal_action: str


class BacktestEngine:
    """
    Main backtest engine.

    Computes P&L from underlying legs:
    - Futures P&L from futures price changes
    - Swap P&L from swap rate changes

    The spread is tracked for reference/signals but doesn't drive P&L.
    """

    def __init__(
        self,
        data: BacktestData,
        signal: Signal,
        config: BacktestConfig,
    ):
        """
        Initialize backtest engine.

        Args:
            data: Historical market data
            signal: Signal generator
            config: Backtest configuration
        """
        self.data = data
        self.signal = signal
        self.config = config
        self._tracker = PositionTracker()
        self._daily_states: List[DailyState] = []

    def run(self) -> BacktestResult:
        """
        Run the backtest.

        Returns:
            BacktestResult with full results and statistics
        """
        self._tracker.reset()
        self._daily_states = []

        # Reset signal if it has state
        if hasattr(self.signal, "reset"):
            self.signal.reset()

        cumulative_pnl = 0.0
        cumulative_futures_pnl = 0.0
        cumulative_swap_pnl = 0.0
        dates = self.data.date_range()

        for i, dt in enumerate(dates):
            snapshot = self.data.get(dt)
            if snapshot is None:
                continue

            # Compute invoice spread (gives us futures price, swap rate, spread)
            spread = self._compute_spread(snapshot)
            if spread is None:
                continue

            # Mark position to market using leg prices
            daily = self._tracker.mark_to_market(
                dt=dt,
                futures_price=snapshot.futures_price,
                swap_rate=spread.forward_swap_rate,
                spread_bp=spread.raw_spread_bp,
                ctd_cusip=snapshot.ctd_cusip,
            )

            cumulative_pnl += daily.total_pnl
            cumulative_futures_pnl += daily.futures_pnl
            cumulative_swap_pnl += daily.swap_pnl

            # Get current state
            state = self._tracker.get_state()

            # Generate signal
            signal_output = self.signal.generate(dt, snapshot, spread, state)

            # Check holding constraints
            signal_output = self._apply_holding_constraints(dt, signal_output)

            # Execute signal
            self._execute_signal(dt, snapshot, spread, signal_output)

            # Record state
            position = 0
            if state.position is not None:
                position = state.position.direction_sign

            self._daily_states.append(
                DailyState(
                    date=dt,
                    futures_price=snapshot.futures_price,
                    swap_rate=spread.forward_swap_rate,
                    spread_bp=spread.raw_spread_bp,
                    position=position,
                    futures_pnl=daily.futures_pnl,
                    swap_pnl=daily.swap_pnl,
                    daily_pnl=daily.total_pnl,
                    cumulative_pnl=cumulative_pnl,
                    ctd_cusip=snapshot.ctd_cusip,
                    ctd_changed=daily.ctd_changed,
                    signal_action=signal_output.action,
                )
            )

            if self.config.verbose and i % 50 == 0:
                print(f"  {dt}: fut={snapshot.futures_price:.2f}, swap={spread.forward_swap_rate*100:.3f}%, "
                      f"spread={spread.raw_spread_bp:.1f}bp, pnl={cumulative_pnl:,.0f}")

        # Close any remaining position at end
        if not self._tracker.is_flat and self._daily_states:
            last = self._daily_states[-1]
            self._tracker.close_position(
                dt=last.date,
                futures_price=last.futures_price,
                swap_rate=last.swap_rate,
                spread_bp=last.spread_bp,
            )

        return self._build_result()

    def _compute_spread(self, snapshot: DailySnapshot) -> Optional[OptionAdjustedInvoiceSpread]:
        """Compute invoice spread from snapshot."""
        try:
            # Validate dates
            if snapshot.delivery_date <= snapshot.date:
                return None
            if snapshot.ctd_maturity <= snapshot.delivery_date:
                return None

            return compute_invoice_spread_option_adjusted(
                futures_price=snapshot.futures_price,
                conversion_factor=snapshot.ctd_cf,
                coupon=snapshot.ctd_coupon,
                delivery_date=snapshot.delivery_date,
                maturity_date=snapshot.ctd_maturity,
                curve=snapshot.curve,
                value_date=snapshot.date,
                contract=snapshot.contract,
                include_option_adjustment=False,
            )
        except Exception as e:
            if self.config.verbose:
                print(f"  Warning: spread calc failed for {snapshot.date}: {e}")
            return None

    def _apply_holding_constraints(
        self,
        dt: date,
        signal: SignalOutput,
    ) -> SignalOutput:
        """Apply min/max holding period constraints."""
        state = self._tracker.get_state()

        if state.position is None:
            return signal

        holding_days = (dt - state.position.entry_date).days

        # Prevent exit before min holding period
        if signal.action == "exit" and holding_days < self.config.min_holding_days:
            return SignalOutput(
                action="hold",
                reason=f"Min holding period not met ({holding_days}/{self.config.min_holding_days})"
            )

        # Force exit after max holding period
        if self.config.max_holding_days and holding_days >= self.config.max_holding_days:
            return SignalOutput(
                action="exit",
                reason=f"Max holding period reached ({holding_days} days)"
            )

        return signal

    def _execute_signal(
        self,
        dt: date,
        snapshot: DailySnapshot,
        spread: OptionAdjustedInvoiceSpread,
        signal: SignalOutput,
    ) -> None:
        """Execute trading signal."""
        state = self._tracker.get_state()

        if signal.action == "hold":
            return

        if signal.action == "exit":
            if not state.is_flat:
                self._tracker.close_position(
                    dt=dt,
                    futures_price=snapshot.futures_price,
                    swap_rate=spread.forward_swap_rate,
                    spread_bp=spread.raw_spread_bp,
                )

        elif signal.action in ("enter_long", "enter_short"):
            if state.is_flat:
                direction = "long" if signal.action == "enter_long" else "short"

                # Scale position by signal strength
                target_dv01 = self.config.target_dv01 * signal.strength

                self._tracker.open_position(
                    dt=dt,
                    futures_price=snapshot.futures_price,
                    swap_rate=spread.forward_swap_rate,
                    spread_bp=spread.raw_spread_bp,
                    target_dv01=target_dv01,
                    futures_dv01=spread.futures_dv01,
                    swap_dv01=target_dv01,  # Use target DV01 as swap DV01 for sizing
                    hedge_ratio=spread.hedge_ratio,
                    direction=direction,
                    ctd_cusip=snapshot.ctd_cusip,
                )

    def _build_result(self) -> BacktestResult:
        """Build BacktestResult from daily states and closed trades."""
        dates = [s.date for s in self._daily_states]
        daily_pnl = [s.daily_pnl for s in self._daily_states]
        cumulative_pnl = [s.cumulative_pnl for s in self._daily_states]
        spread_series = [s.spread_bp for s in self._daily_states]
        position_series = [s.position for s in self._daily_states]

        # Build additional series for leg attribution
        futures_pnl_series = [s.futures_pnl for s in self._daily_states]
        swap_pnl_series = [s.swap_pnl for s in self._daily_states]
        futures_price_series = [s.futures_price for s in self._daily_states]
        swap_rate_series = [s.swap_rate for s in self._daily_states]

        trades = [
            TradeRecord.from_closed_trade(t)
            for t in self._tracker.closed_trades
        ]

        return BacktestResult(
            dates=dates,
            daily_pnl=daily_pnl,
            cumulative_pnl=cumulative_pnl,
            spread_series=spread_series,
            position_series=position_series,
            trades=trades,
            # Leg-level series
            futures_pnl_series=futures_pnl_series,
            swap_pnl_series=swap_pnl_series,
            futures_price_series=futures_price_series,
            swap_rate_series=swap_rate_series,
        )


def run_backtest(
    data: BacktestData,
    signal: Signal,
    target_dv01: float = 1000.0,
    transaction_cost_bp: float = 0.5,
    contract: str = "TY",
    verbose: bool = False,
) -> BacktestResult:
    """
    Convenience function to run a backtest.

    Args:
        data: Historical market data
        signal: Signal generator
        target_dv01: Position size in DV01
        transaction_cost_bp: Round-trip cost estimate
        contract: Futures contract code
        verbose: Print progress

    Returns:
        BacktestResult with full results
    """
    config = BacktestConfig(
        target_dv01=target_dv01,
        transaction_cost_bp=transaction_cost_bp,
        contract=contract,
        verbose=verbose,
    )
    engine = BacktestEngine(data, signal, config)
    return engine.run()
