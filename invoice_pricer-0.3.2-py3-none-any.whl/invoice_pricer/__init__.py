"""
Invoice Pricer - Treasury futures invoice spread pricing.

Simple API:
    >>> from invoice_pricer import price_invoice_spread, build_curve
    >>> curve = build_curve([1,2,5,10,30], [0.043,0.041,0.042,0.045,0.046])
    >>> result = price_invoice_spread(
    ...     futures_price=110.25,
    ...     conversion_factor=0.8456,
    ...     coupon=0.04125,
    ...     maturity_years=9.5,
    ...     delivery_years=0.12,
    ...     curve=curve,
    ... )
    >>> print(f"Spread: {result.spread_bp:.2f} bp")

Security Master & Deliverable Basket:
    >>> from invoice_pricer import build_secmaster, get_deliverable_basket, find_ctd
    >>> from datetime import date
    >>> secmaster = build_secmaster()  # Fetches from Treasury Direct
    >>> basket = get_deliverable_basket("TY", secmaster, date(2024, 3, 1), futures_price=110.5)
    >>> ctd = find_ctd(basket, 110.5, spot_prices)
    >>> print(f"CTD: {ctd.cusip}, CF: {ctd.cf:.4f}")

Conversion Factors:
    >>> from invoice_pricer import compute_cf, compute_cf_from_dates
    >>> cf = compute_cf(coupon=0.04, maturity_years=9.5)
    >>> cf = compute_cf_from_dates(0.04, date(2029, 11, 15), date(2024, 3, 1))

For advanced usage, import from submodules:
    >>> from invoice_pricer.bonds import bond_price, bond_yield, dv01
    >>> from invoice_pricer.curves import SwapCurve
    >>> from invoice_pricer.carry import calculate_carry
"""

from __future__ import annotations

__version__ = "0.3.2"

# Clean API (recommended)
from .api import (
    build_curve,
    price_invoice_spread,
    implied_yield,
    futures_dv01,
    forward_swap_rate,
    InvoiceSpread,
)
from .swaps import price_swap, price_swap_from_dates, swap_dv01, SwapValuation

# Practitioner API (streamlined for trading)
from .practitioner import (
    invoice_spread,
    invoice_spread_carry,
    invoice_spread_adjusted,
    spread_to_swap_rate,
    swap_pnl,
    SpreadResult,
    CarrySpreadResult,
    AdjustedSpreadResult,
    SwapPnL,
)

# Core types
from .curves import SwapCurve, SwapRateSplineCurve
from .bonds import Bond, TreasuryBond

# Legacy API (for backwards compatibility)
from .bonds import bond_price, bond_yield, dv01, modified_duration
from .curves import bootstrap_swap_curve
from .futures import analyze_futures, implied_yield_from_futures
from .invoice import (
    compute_invoice_spread,
    reverse_invoice_spread,
    compute_invoice_spread_adjusted,
    InvoiceSpreadResult,
    # New methodology (v2)
    compute_invoice_spread_v2,
    InvoiceSpreadResultV2,
    # With hedge ratio
    compute_invoice_spread_with_hedge,
    InvoiceSpreadWithHedge,
    compute_accrued_interest,
    compute_yield_from_dirty_price,
    # Option-adjusted (v2)
    compute_invoice_spread_option_adjusted,
    OptionAdjustedInvoiceSpread,
)
from .sample_data import get_sample_scenario, build_sample_curve

# Security Master & Deliverables
from .secmaster import (
    TreasuryBondInfo,
    fetch_treasury_auctions,
    build_secmaster,
    filter_by_maturity,
)
from .conversion_factor import (
    compute_cf,
    compute_cf_detailed,
    compute_cf_from_dates,
    get_contract_spec,
    CONTRACT_SPECS,
    ConversionFactorResult,
)
from .hedge import (
    FuturesDV01,
    HedgeRatio,
    HedgePosition,
    compute_futures_dv01,
    compute_hedge_ratio,
    compute_rebalance,
    estimate_hedge_change,
    print_hedge_summary,
)
from .deliverable import (
    DeliverableBond,
    is_deliverable,
    get_deliverable_basket,
    compute_basis,
    compute_net_basis,
    compute_implied_repo,
    compute_carry,
    compute_accrued_at_date,
    find_ctd,
    rank_deliverables,
    get_delivery_months,
    get_next_delivery_date,
    print_basket,
)

__all__ = [
    # Version
    "__version__",
    # Clean API
    "build_curve",
    "price_invoice_spread",
    "implied_yield",
    "futures_dv01",
    "forward_swap_rate",
    "InvoiceSpread",
    # Swap pricing
    "price_swap",
    "price_swap_from_dates",
    "swap_dv01",
    "SwapValuation",
    # Practitioner API
    "invoice_spread",
    "invoice_spread_carry",
    "invoice_spread_adjusted",
    "spread_to_swap_rate",
    "swap_pnl",
    "SpreadResult",
    "CarrySpreadResult",
    "AdjustedSpreadResult",
    "SwapPnL",
    # Core types
    "SwapCurve",
    "SwapRateSplineCurve",
    "Bond",
    "TreasuryBond",
    # Legacy
    "bond_price",
    "bond_yield",
    "dv01",
    "modified_duration",
    "bootstrap_swap_curve",
    "analyze_futures",
    "implied_yield_from_futures",
    "compute_invoice_spread",
    "reverse_invoice_spread",
    "compute_invoice_spread_adjusted",
    "InvoiceSpreadResult",
    # New methodology (v2)
    "compute_invoice_spread_v2",
    "InvoiceSpreadResultV2",
    # With hedge ratio
    "compute_invoice_spread_with_hedge",
    "InvoiceSpreadWithHedge",
    "compute_accrued_interest",
    "compute_yield_from_dirty_price",
    # Option-adjusted (v2)
    "compute_invoice_spread_option_adjusted",
    "OptionAdjustedInvoiceSpread",
    "get_sample_scenario",
    "build_sample_curve",
    # Security Master
    "TreasuryBondInfo",
    "fetch_treasury_auctions",
    "build_secmaster",
    "filter_by_maturity",
    # Conversion Factors
    "compute_cf",
    "compute_cf_detailed",
    "compute_cf_from_dates",
    "get_contract_spec",
    "CONTRACT_SPECS",
    "ConversionFactorResult",
    # Hedge Ratio
    "FuturesDV01",
    "HedgeRatio",
    "HedgePosition",
    "compute_futures_dv01",
    "compute_hedge_ratio",
    "compute_rebalance",
    "estimate_hedge_change",
    "print_hedge_summary",
    # Deliverable Basket
    "DeliverableBond",
    "is_deliverable",
    "get_deliverable_basket",
    "compute_basis",
    "compute_net_basis",
    "compute_implied_repo",
    "compute_carry",
    "compute_accrued_at_date",
    "find_ctd",
    "rank_deliverables",
    "get_delivery_months",
    "get_next_delivery_date",
    "print_basket",
    # Backtesting
    "backtest",
]

# Backtest subpackage (import as submodule)
from . import backtest
