"""
Invoice Spread Hedge Ratio Calculator.

Computes and tracks hedge ratios for DV01-neutral invoice spread positions.

Example:
    >>> from invoice_pricer.hedge import compute_hedge_ratio, HedgePosition
    >>> ratio = compute_hedge_ratio(
    ...     ctd_duration=7.5,
    ...     ctd_price=98.50,
    ...     ctd_cf=0.88,
    ...     swap_dv01=7500,
    ...     contract="TY",
    ... )
    >>> print(f"Contracts needed: {ratio.n_contracts}")
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Optional, List, Literal
import math

from .conversion_factor import CONTRACT_SPECS


@dataclass
class FuturesDV01:
    """
    DV01 characteristics of a futures contract.

    Attributes:
        contract: Contract code (TY, FV, etc.)
        ctd_duration: CTD modified duration
        ctd_price: CTD clean price
        ctd_cf: CTD conversion factor
        dv01_per_100: DV01 per $100 face of CTD
        dv01_per_contract: DV01 per futures contract
        contract_size: Contract face value
    """
    contract: str
    ctd_duration: float
    ctd_price: float
    ctd_cf: float
    dv01_per_100: float
    dv01_per_contract: float
    contract_size: int


@dataclass
class HedgeRatio:
    """
    Hedge ratio calculation result.

    Attributes:
        n_contracts: Number of futures contracts (+ = long, - = short)
        futures_dv01: DV01 per futures contract
        swap_dv01: Total swap DV01
        swap_notional: Swap notional amount
        hedge_dv01: Total hedged futures DV01
        dv01_mismatch: Residual DV01 after hedging
        contract: Futures contract code
    """
    n_contracts: int
    futures_dv01: FuturesDV01
    swap_dv01: float
    swap_notional: float
    hedge_dv01: float
    dv01_mismatch: float
    contract: str

    @property
    def contracts_exact(self) -> float:
        """Exact (non-rounded) number of contracts."""
        return self.swap_dv01 / self.futures_dv01.dv01_per_contract


@dataclass
class HedgePosition:
    """
    Tracks a hedged invoice spread position over time.

    Attributes:
        contract: Futures contract code
        swap_notional: Swap notional
        swap_dv01: Current swap DV01
        n_contracts: Current number of futures contracts
        entry_date: Position entry date
        history: List of hedge ratio snapshots
    """
    contract: str
    swap_notional: float
    swap_dv01: float
    n_contracts: int
    entry_date: date
    history: List[dict] = field(default_factory=list)

    def current_dv01_mismatch(self, futures_dv01_per_contract: float) -> float:
        """Calculate current DV01 mismatch."""
        hedge_dv01 = self.n_contracts * futures_dv01_per_contract
        return self.swap_dv01 - hedge_dv01

    def rebalance_needed(
        self,
        futures_dv01_per_contract: float,
        threshold_pct: float = 0.05,
    ) -> tuple[bool, int]:
        """
        Check if rebalancing is needed.

        Args:
            futures_dv01_per_contract: Current futures DV01
            threshold_pct: Rebalance if mismatch exceeds this % of swap DV01

        Returns:
            (needs_rebalance, contracts_to_trade)
        """
        target = self.swap_dv01 / futures_dv01_per_contract
        diff = target - self.n_contracts
        threshold = self.swap_dv01 * threshold_pct / futures_dv01_per_contract

        if abs(diff) > threshold:
            return True, round(diff)
        return False, 0


def compute_futures_dv01(
    ctd_duration: float,
    ctd_price: float,
    ctd_cf: float,
    contract: str = "TY",
) -> FuturesDV01:
    """
    Compute futures DV01 from CTD characteristics.

    Futures DV01 = (CTD DV01 / CF) × (Contract Size / 100)

    Args:
        ctd_duration: CTD modified duration (years)
        ctd_price: CTD clean price (per $100 face)
        ctd_cf: CTD conversion factor
        contract: Contract code (TY, FV, US, WN, TU)

    Returns:
        FuturesDV01 with per-contract DV01

    Example:
        >>> dv01 = compute_futures_dv01(7.5, 98.50, 0.88, "TY")
        >>> print(f"DV01 per contract: ${dv01.dv01_per_contract:.2f}")
    """
    spec = CONTRACT_SPECS.get(contract.upper())
    if not spec:
        raise ValueError(f"Unknown contract: {contract}")

    contract_size = spec["contract_size"]

    # CTD DV01 per $100 face
    # DV01 = Duration × Price × 0.0001
    dv01_per_100 = ctd_duration * ctd_price * 0.0001

    # Futures DV01 per contract
    # = (CTD DV01 / CF) × (Contract Size / 100)
    dv01_per_contract = (dv01_per_100 / ctd_cf) * (contract_size / 100)

    return FuturesDV01(
        contract=contract.upper(),
        ctd_duration=ctd_duration,
        ctd_price=ctd_price,
        ctd_cf=ctd_cf,
        dv01_per_100=dv01_per_100,
        dv01_per_contract=dv01_per_contract,
        contract_size=contract_size,
    )


def compute_hedge_ratio(
    ctd_duration: float,
    ctd_price: float,
    ctd_cf: float,
    swap_dv01: float,
    contract: str = "TY",
    swap_notional: Optional[float] = None,
    direction: Literal["long", "short"] = "long",
) -> HedgeRatio:
    """
    Compute hedge ratio for DV01-neutral invoice spread.

    Args:
        ctd_duration: CTD modified duration (years)
        ctd_price: CTD clean price
        ctd_cf: CTD conversion factor
        swap_dv01: Total swap DV01 (absolute value)
        contract: Futures contract code
        swap_notional: Swap notional (optional, for reference)
        direction: "long" spread = long futures, "short" = short futures

    Returns:
        HedgeRatio with contract count and DV01 details

    Example:
        >>> ratio = compute_hedge_ratio(
        ...     ctd_duration=7.5,
        ...     ctd_price=98.50,
        ...     ctd_cf=0.88,
        ...     swap_dv01=7500,
        ...     contract="TY",
        ...     swap_notional=10_000_000,
        ... )
        >>> print(f"Need {ratio.n_contracts} TY contracts")
    """
    futures_dv01 = compute_futures_dv01(ctd_duration, ctd_price, ctd_cf, contract)

    # Exact number of contracts
    n_exact = swap_dv01 / futures_dv01.dv01_per_contract

    # Round to nearest integer
    n_contracts = round(n_exact)

    # Apply direction
    if direction == "short":
        n_contracts = -n_contracts

    # Calculate actual hedge DV01 and mismatch
    hedge_dv01 = abs(n_contracts) * futures_dv01.dv01_per_contract
    dv01_mismatch = swap_dv01 - hedge_dv01

    return HedgeRatio(
        n_contracts=n_contracts,
        futures_dv01=futures_dv01,
        swap_dv01=swap_dv01,
        swap_notional=swap_notional or 0,
        hedge_dv01=hedge_dv01,
        dv01_mismatch=dv01_mismatch,
        contract=contract.upper(),
    )


def compute_rebalance(
    current_contracts: int,
    ctd_duration: float,
    ctd_price: float,
    ctd_cf: float,
    swap_dv01: float,
    contract: str = "TY",
    threshold_pct: float = 0.05,
) -> dict:
    """
    Determine if rebalancing is needed and by how much.

    Args:
        current_contracts: Current number of futures contracts
        ctd_duration: Current CTD modified duration
        ctd_price: Current CTD clean price
        ctd_cf: Current CTD conversion factor
        swap_dv01: Current swap DV01
        contract: Futures contract code
        threshold_pct: Rebalance if DV01 mismatch exceeds this %

    Returns:
        Dict with rebalance recommendation

    Example:
        >>> result = compute_rebalance(
        ...     current_contracts=89,
        ...     ctd_duration=7.8,  # Duration increased
        ...     ctd_price=101.50,  # Price increased
        ...     ctd_cf=0.88,
        ...     swap_dv01=7500,
        ... )
        >>> if result["rebalance_needed"]:
        ...     print(f"Trade {result['contracts_to_trade']} contracts")
    """
    futures_dv01 = compute_futures_dv01(ctd_duration, ctd_price, ctd_cf, contract)

    # Current hedge DV01
    current_hedge_dv01 = abs(current_contracts) * futures_dv01.dv01_per_contract

    # Target contracts
    target_exact = swap_dv01 / futures_dv01.dv01_per_contract
    target_rounded = round(target_exact)

    # Mismatch
    dv01_mismatch = swap_dv01 - current_hedge_dv01
    mismatch_pct = abs(dv01_mismatch) / swap_dv01 if swap_dv01 > 0 else 0

    # Contracts to trade
    contracts_to_trade = target_rounded - abs(current_contracts)
    if current_contracts < 0:
        contracts_to_trade = -contracts_to_trade

    rebalance_needed = mismatch_pct > threshold_pct

    return {
        "rebalance_needed": rebalance_needed,
        "contracts_to_trade": contracts_to_trade if rebalance_needed else 0,
        "current_contracts": current_contracts,
        "target_contracts": target_rounded if current_contracts >= 0 else -target_rounded,
        "futures_dv01": futures_dv01.dv01_per_contract,
        "current_hedge_dv01": current_hedge_dv01,
        "target_hedge_dv01": swap_dv01,
        "dv01_mismatch": dv01_mismatch,
        "mismatch_pct": mismatch_pct,
        "threshold_pct": threshold_pct,
    }


def duration_from_yield_change(
    initial_duration: float,
    initial_yield: float,
    yield_change: float,
    convexity: Optional[float] = None,
) -> float:
    """
    Estimate new duration after a yield change.

    Duration changes approximately as:
    New Duration ≈ Duration × (1 + yield_change × Duration / (1 + yield))

    Args:
        initial_duration: Starting modified duration
        initial_yield: Starting yield (decimal)
        yield_change: Change in yield (decimal, e.g., 0.005 for 50bp)
        convexity: Optional convexity for better estimate

    Returns:
        Estimated new duration

    Example:
        >>> new_dur = duration_from_yield_change(7.5, 0.04, -0.005)
        >>> print(f"Duration after 50bp rally: {new_dur:.2f}")
    """
    # Simple approximation: duration extends as yields fall
    # Based on the relationship between Macaulay and modified duration
    new_yield = initial_yield + yield_change

    # Rough approximation
    # Modified duration = Macaulay duration / (1 + y/2) for semi-annual
    # When yields change, Mac duration stays ~constant, so mod duration changes
    mac_duration = initial_duration * (1 + initial_yield / 2)
    new_mod_duration = mac_duration / (1 + new_yield / 2)

    return new_mod_duration


def estimate_hedge_change(
    initial_duration: float,
    initial_price: float,
    ctd_cf: float,
    swap_dv01: float,
    yield_change: float,
    initial_yield: float = 0.04,
    contract: str = "TY",
) -> dict:
    """
    Estimate how hedge ratio changes with yield movement.

    Args:
        initial_duration: Starting CTD duration
        initial_price: Starting CTD price
        ctd_cf: CTD conversion factor
        swap_dv01: Swap DV01
        yield_change: Yield change (decimal)
        initial_yield: Starting yield level
        contract: Futures contract

    Returns:
        Dict with before/after hedge ratios

    Example:
        >>> result = estimate_hedge_change(
        ...     initial_duration=7.5,
        ...     initial_price=98.50,
        ...     ctd_cf=0.88,
        ...     swap_dv01=7500,
        ...     yield_change=-0.005,  # 50bp rally
        ... )
        >>> print(f"Contracts: {result['initial_contracts']} -> {result['new_contracts']}")
    """
    # Initial hedge ratio
    initial = compute_hedge_ratio(
        initial_duration, initial_price, ctd_cf, swap_dv01, contract
    )

    # Estimate new duration
    new_duration = duration_from_yield_change(
        initial_duration, initial_yield, yield_change
    )

    # Estimate new price (using duration approximation)
    price_change_pct = -initial_duration * yield_change
    new_price = initial_price * (1 + price_change_pct)

    # New hedge ratio
    new = compute_hedge_ratio(
        new_duration, new_price, ctd_cf, swap_dv01, contract
    )

    return {
        "yield_change_bp": yield_change * 10000,
        "initial_duration": initial_duration,
        "new_duration": new_duration,
        "duration_change": new_duration - initial_duration,
        "initial_price": initial_price,
        "new_price": new_price,
        "initial_dv01_per_contract": initial.futures_dv01.dv01_per_contract,
        "new_dv01_per_contract": new.futures_dv01.dv01_per_contract,
        "dv01_change_pct": (new.futures_dv01.dv01_per_contract - initial.futures_dv01.dv01_per_contract) / initial.futures_dv01.dv01_per_contract,
        "initial_contracts": initial.n_contracts,
        "new_contracts": new.n_contracts,
        "contracts_change": new.n_contracts - initial.n_contracts,
    }


def print_hedge_summary(ratio: HedgeRatio) -> None:
    """Print hedge ratio summary."""
    print(f"{'='*50}")
    print(f"HEDGE RATIO SUMMARY - {ratio.contract}")
    print(f"{'='*50}")
    print(f"CTD Duration:     {ratio.futures_dv01.ctd_duration:.2f} years")
    print(f"CTD Price:        {ratio.futures_dv01.ctd_price:.3f}")
    print(f"CTD CF:           {ratio.futures_dv01.ctd_cf:.4f}")
    print(f"Contract Size:    ${ratio.futures_dv01.contract_size:,}")
    print(f"-" * 50)
    print(f"CTD DV01/$100:    ${ratio.futures_dv01.dv01_per_100:.4f}")
    print(f"Futures DV01:     ${ratio.futures_dv01.dv01_per_contract:.2f} per contract")
    print(f"-" * 50)
    print(f"Swap DV01:        ${ratio.swap_dv01:,.2f}")
    if ratio.swap_notional:
        print(f"Swap Notional:    ${ratio.swap_notional:,.0f}")
    print(f"-" * 50)
    print(f"Contracts:        {ratio.n_contracts} (exact: {ratio.contracts_exact:.2f})")
    print(f"Hedge DV01:       ${ratio.hedge_dv01:,.2f}")
    print(f"DV01 Mismatch:    ${ratio.dv01_mismatch:,.2f}")
    print(f"{'='*50}")
