"""
Invoice spread calculation engine.

WHAT IS AN INVOICE SPREAD?
==========================
An invoice spread is the yield difference between:
1. A forward-starting SOFR swap (delivery date → CTD maturity)
2. Treasury futures forward bond yield (from invoice price)

    Invoice Spread = Forward Swap Rate - Forward Bond Yield

WHY TRADE INVOICE SPREADS?
==========================
- Express view on treasury vs swap spreads going forward
- Hedge treasury/swap basis risk
- Relative value between cash treasuries and swaps
- Capture roll-down or curve movements

FORWARD BOND YIELD CALCULATION
==============================
The forward bond yield is computed from the invoice price:

    Invoice Price (Dirty) = Futures × CF + Accrued at Delivery
    Forward Bond Yield = Yield from dirty price (30/360, semi-annual)

This properly accounts for accrued interest at delivery settlement.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional, List, Tuple

from scipy.optimize import brentq

from .bonds import Bond, TreasuryBond, bond_yield
from .curves import SwapCurve
from .futures import (
    implied_bond_price_from_futures,
    analyze_futures,
    compute_adjusted_implied_yield,
)
from .carry import calculate_carry, CarryComponents
from .delivery_option import estimate_delivery_option_value, FuturesContract


# =============================================================================
# DAY COUNT AND YIELD HELPERS
# =============================================================================

def days_30360(d1: date, d2: date) -> int:
    """
    Calculate days between two dates using 30/360 convention.

    30/360 (Bond Basis): Each month is treated as 30 days, year as 360.
    """
    y1, m1, day1 = d1.year, d1.month, min(d1.day, 30)
    y2, m2, day2 = d2.year, d2.month, d2.day
    if day1 == 30 and day2 == 31:
        day2 = 30
    return 360 * (y2 - y1) + 30 * (m2 - m1) + (day2 - day1)


def get_coupon_dates(maturity_date: date) -> Tuple[int, int]:
    """
    Get coupon payment months for a bond based on maturity date.

    Treasury bonds pay semi-annually on the same day of month as maturity.

    Returns:
        Tuple of (month1, month2) for coupon payments
    """
    mat_month = maturity_date.month
    if mat_month <= 6:
        return (mat_month, mat_month + 6)
    else:
        return (mat_month - 6, mat_month)


def compute_accrued_interest(
    settlement_date: date,
    maturity_date: date,
    coupon: float,
) -> Tuple[float, date, date]:
    """
    Compute accrued interest at settlement date.

    Args:
        settlement_date: Date to compute accrued for
        maturity_date: Bond maturity date
        coupon: Annual coupon rate (decimal, e.g., 0.04 for 4%)

    Returns:
        Tuple of (accrued_interest, last_coupon_date, next_coupon_date)
        Accrued is per 100 face value.
    """
    # Determine coupon months from maturity
    coupon_day = maturity_date.day
    month1, month2 = get_coupon_dates(maturity_date)

    # Find last and next coupon dates relative to settlement
    year = settlement_date.year

    # Build list of nearby coupon dates
    potential_dates = []
    for y in [year - 1, year, year + 1]:
        for m in [month1, month2]:
            # Try actual coupon day first, fall back for invalid dates (e.g., Feb 30)
            try:
                potential_dates.append(date(y, m, coupon_day))
            except ValueError:
                # Use last valid day of month
                if m == 2:
                    # February: check for leap year
                    last_day = 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28
                else:
                    last_day = 30 if m in [4, 6, 9, 11] else 31
                potential_dates.append(date(y, m, min(coupon_day, last_day)))

    potential_dates.sort()

    # Find last coupon (on or before settlement) and next coupon (after settlement)
    last_coupon = None
    next_coupon = None

    for d in potential_dates:
        if d <= settlement_date:
            last_coupon = d
        elif next_coupon is None:
            next_coupon = d
            break

    if last_coupon is None or next_coupon is None:
        raise ValueError(f"Could not determine coupon dates for settlement {settlement_date}")

    # Accrued = (days since last coupon / days in period) × (coupon/2) × 100
    days_since = (settlement_date - last_coupon).days
    days_in_period = (next_coupon - last_coupon).days

    accrued = (days_since / days_in_period) * (coupon / 2) * 100

    return accrued, last_coupon, next_coupon


def get_cash_flow_schedule(
    settlement_date: date,
    maturity_date: date,
    coupon: float,
) -> List[Tuple[date, float]]:
    """
    Generate cash flow schedule from settlement to maturity.

    Args:
        settlement_date: Start date for cash flows
        maturity_date: Bond maturity date
        coupon: Annual coupon rate (decimal)

    Returns:
        List of (date, cash_flow) tuples
    """
    _, last_coupon, next_coupon = compute_accrued_interest(
        settlement_date, maturity_date, coupon
    )

    coupon_day = maturity_date.day
    month1, month2 = get_coupon_dates(maturity_date)
    semi_coupon = (coupon / 2) * 100  # Per 100 face

    cash_flows = []
    current_date = next_coupon

    while current_date <= maturity_date:
        cash_flows.append((current_date, semi_coupon))

        # Move to next coupon date
        if current_date.month == month1:
            next_month = month2
            next_year = current_date.year
        else:
            next_month = month1
            next_year = current_date.year + 1

        try:
            current_date = date(next_year, next_month, coupon_day)
        except ValueError:
            # Use last valid day of month for invalid dates (e.g., Feb 30)
            if next_month == 2:
                last_day = 29 if (next_year % 4 == 0 and (next_year % 100 != 0 or next_year % 400 == 0)) else 28
            else:
                last_day = 30 if next_month in [4, 6, 9, 11] else 31
            current_date = date(next_year, next_month, min(coupon_day, last_day))

    # Add principal repayment at maturity
    # Principal is paid at maturity date, which may differ from last coupon date
    if cash_flows:
        last_cf_date, last_cf_amt = cash_flows[-1]
        # Add principal to the last cash flow (coupon closest to maturity)
        cash_flows[-1] = (last_cf_date, last_cf_amt + 100)

    return cash_flows


def compute_yield_from_dirty_price(
    dirty_price: float,
    settlement_date: date,
    maturity_date: date,
    coupon: float,
) -> float:
    """
    Compute yield from dirty price using 30/360 day count, semi-annual compounding.

    This is the standard Treasury yield calculation convention.

    Args:
        dirty_price: Full price including accrued (per 100 face)
        settlement_date: Settlement/valuation date
        maturity_date: Bond maturity date
        coupon: Annual coupon rate (decimal)

    Returns:
        Yield to maturity (decimal, e.g., 0.035 for 3.5%)
    """
    # Get cash flow schedule
    cash_flows = get_cash_flow_schedule(settlement_date, maturity_date, coupon)

    if not cash_flows:
        raise ValueError("No cash flows remaining")

    def npv(y: float) -> float:
        """Calculate NPV of cash flows at yield y."""
        pv = 0.0
        for cf_date, cf_amount in cash_flows:
            # Time in years using 30/360
            days = days_30360(settlement_date, cf_date)
            t = days / 360.0
            # Semi-annual compounding
            pv += cf_amount / (1 + y / 2) ** (t * 2)
        return pv - dirty_price

    # Solve for yield
    try:
        return brentq(npv, -0.20, 0.50)
    except ValueError:
        # If brentq fails, try wider bounds
        return brentq(npv, -0.50, 1.00)


@dataclass
class InvoiceSpreadResult:
    """Result of invoice spread calculation."""
    spread_bp: float              # Invoice spread in basis points
    implied_yield: float          # Futures-implied bond yield
    forward_swap_rate: float      # Forward swap rate
    delivery_tenor: float         # Time to delivery in years
    maturity_tenor: float         # Time to bond maturity in years
    futures_dv01: float           # DV01 of futures position


@dataclass
class AdjustedInvoiceSpreadResult:
    """
    Production-level invoice spread with adjustments.

    Provides THREE yield/spread measures:
    1. RAW: Simple Futures × CF (ignores carry and options)
    2. CARRY-ADJUSTED: Accounts for repo financing (requires spot + repo inputs)
    3. FULLY ADJUSTED: Carry + delivery options

    If spot_price/repo_rate not provided, carry fields will equal raw.
    """
    # Raw calculation (simple futures × CF)
    raw_spread_bp: float
    raw_implied_yield: float

    # Carry-adjusted (uses spot price and repo rate)
    carry_adjusted_spread_bp: float
    carry_adjusted_yield: float

    # Fully adjusted (carry + delivery options)
    adjusted_spread_bp: float
    adjusted_implied_yield: float

    # Common components
    forward_swap_rate: float
    delivery_tenor: float
    maturity_tenor: float
    futures_dv01: float

    # Adjustment details
    carry_adjustment_bp: float       # Carry effect in bp
    option_adjustment_ticks: float   # Option value in ticks
    option_adjustment_bp: float      # Option effect in bp

    @property
    def total_adjustment_bp(self) -> float:
        """Total adjustment from raw to fully adjusted."""
        return self.raw_spread_bp - self.adjusted_spread_bp

    @property
    def spread_difference_bp(self) -> float:
        """Alias for total_adjustment_bp (backwards compatibility)."""
        return self.total_adjustment_bp


# =============================================================================
# NEW METHODOLOGY: Invoice Spread with Proper Forward Yield
# =============================================================================

@dataclass
class InvoiceSpreadResultV2:
    """
    Invoice spread result using correct forward bond yield methodology.

    Invoice Spread = Forward Swap Rate - Forward Bond Yield

    Where:
        Invoice Price (Dirty) = Futures × CF + Accrued at Delivery
        Forward Bond Yield = Yield from dirty price (30/360, semi-annual)
    """
    spread_bp: float              # Invoice spread in basis points
    forward_bond_yield: float     # Forward bond yield (from invoice dirty price)
    forward_swap_rate: float      # Forward swap rate
    invoice_price_clean: float    # Futures × CF
    invoice_price_dirty: float    # Futures × CF + Accrued
    accrued_at_delivery: float    # Accrued interest at delivery
    delivery_date: date           # Futures delivery date
    maturity_date: date           # CTD maturity date


@dataclass
class InvoiceSpreadWithHedge:
    """
    Invoice spread result with hedge ratio for position management.

    Includes all spread components plus DV01 and hedge ratio metrics
    for tracking rebalancing needs period-to-period.

    Hedge Ratio Change:
        contracts_to_trade = (hr_new - hr_old) × position_notional / 1_000_000
    """
    # Spread components
    spread_bp: float              # Invoice spread in basis points
    forward_bond_yield: float     # Forward bond yield
    forward_swap_rate: float      # Forward swap rate
    invoice_price_clean: float    # Futures × CF
    invoice_price_dirty: float    # Futures × CF + Accrued
    accrued_at_delivery: float    # Accrued interest at delivery

    # Duration and DV01
    ctd_duration: float           # CTD modified duration
    ctd_dv01: float               # CTD DV01 per $100 face
    futures_dv01: float           # Futures DV01 per contract

    # Hedge ratio and DV01
    hedge_ratio: float            # futures_notional / swap_notional
    swap_pv01: float              # Swap PV01 per $1 notional

    # Reference data
    futures_price: float          # Futures price
    conversion_factor: float      # CTD conversion factor
    coupon: float                 # CTD coupon
    delivery_date: date           # Futures delivery date
    maturity_date: date           # CTD maturity date
    contract: str                 # Contract code (TY, FV, etc.)

    def futures_notional(self, swap_notional: float) -> float:
        """Calculate futures notional needed for a given swap notional."""
        return self.hedge_ratio * swap_notional

    def rebalance_notional(
        self,
        previous: "InvoiceSpreadWithHedge",
        swap_notional: float,
    ) -> float:
        """
        Calculate futures notional to trade to rebalance from previous period.

        Args:
            previous: Previous period's result
            swap_notional: Swap notional

        Returns:
            Futures notional to trade (+ = buy, - = sell)
        """
        hr_change = self.hedge_ratio - previous.hedge_ratio
        return hr_change * swap_notional


def _compute_swap_pv01(
    curve: SwapCurve,
    start_years: float,
    end_years: float,
    freq: int = 2,
) -> float:
    """
    Compute swap PV01 (DV01 per $1 notional) from the curve.

    PV01 = Σ(DF_i × accrual_i) × 0.0001

    This is the present value change for a 1bp move in rates.

    Args:
        curve: SOFR swap curve
        start_years: Swap start in years from value_date
        end_years: Swap end in years from value_date
        freq: Payment frequency (2 = semi-annual)

    Returns:
        PV01 per $1 notional
    """
    # Generate payment schedule
    period = 1.0 / freq
    accrual = period  # Simplified accrual

    # Payment times from start to end
    n_periods = int((end_years - start_years) * freq + 0.5)
    if n_periods < 1:
        n_periods = 1

    pv01 = 0.0
    for i in range(1, n_periods + 1):
        t = start_years + i * period
        if t > end_years:
            t = end_years
        df = curve.df(t)
        pv01 += df * accrual

    return pv01 * 0.0001  # Convert to per bp


def _compute_swap_duration(
    curve: SwapCurve,
    start_years: float,
    end_years: float,
    freq: int = 2,
) -> float:
    """
    Compute swap modified duration from the curve.

    Duration is measured from swap start date:
    Duration = Σ((t_i - start) × DF_i × accrual_i) / Σ(DF_i × accrual_i)

    Args:
        curve: SOFR swap curve
        start_years: Swap start in years from value_date
        end_years: Swap end in years from value_date
        freq: Payment frequency (2 = semi-annual)

    Returns:
        Modified duration in years (from swap start)
    """
    period = 1.0 / freq
    accrual = period

    n_periods = int((end_years - start_years) * freq + 0.5)
    if n_periods < 1:
        n_periods = 1

    duration_num = 0.0
    annuity = 0.0

    for i in range(1, n_periods + 1):
        t = start_years + i * period
        if t > end_years:
            t = end_years
        df = curve.df(t)
        # Time from swap start, not from today
        time_from_start = t - start_years
        duration_num += time_from_start * df * accrual
        annuity += df * accrual

    if annuity > 0:
        return duration_num / annuity
    else:
        return (end_years - start_years) / 2


def _compute_modified_duration(
    dirty_price: float,
    coupon: float,
    settlement_date: date,
    maturity_date: date,
    yield_rate: float,
) -> float:
    """
    Compute modified duration for a bond.

    Uses analytic formula for semi-annual bond:
    ModDur = MacDur / (1 + y/2)

    MacDur = Σ(t × CF × DF) / Price
    """
    # Years to maturity
    years_to_mat = (maturity_date - settlement_date).days / 365.0

    # Semi-annual periods
    n_periods = int(years_to_mat * 2 + 0.5)
    if n_periods < 1:
        n_periods = 1

    # Semi-annual yield
    y_semi = yield_rate / 2
    semi_coupon = coupon / 2 * 100  # Per $100 face

    # Calculate Macaulay duration
    mac_dur_num = 0.0
    pv_sum = 0.0

    for i in range(1, n_periods + 1):
        t = i / 2  # Time in years
        df = 1 / (1 + y_semi) ** i

        if i < n_periods:
            cf = semi_coupon
        else:
            cf = semi_coupon + 100  # Final payment includes principal

        pv = cf * df
        mac_dur_num += t * pv
        pv_sum += pv

    if pv_sum > 0:
        mac_dur = mac_dur_num / pv_sum
    else:
        mac_dur = years_to_mat

    # Modified duration
    mod_dur = mac_dur / (1 + y_semi)

    return mod_dur


def compute_invoice_spread_with_hedge(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    delivery_date: date,
    maturity_date: date,
    curve: SwapCurve,
    value_date: date,
    contract: str = "TY",
) -> InvoiceSpreadWithHedge:
    """
    Compute invoice spread with hedge ratio for position management.

    Returns spread plus DV01 and hedge ratio metrics for tracking
    rebalancing needs period-to-period.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        delivery_date: Futures delivery date
        maturity_date: CTD bond maturity date
        curve: SOFR swap curve
        value_date: Current valuation date
        contract: Futures contract code (TY, FV, US, WN, TU)

    Returns:
        InvoiceSpreadWithHedge with spread, DV01, and hedge ratio

    Example:
        >>> result_t0 = compute_invoice_spread_with_hedge(...)
        >>> result_t1 = compute_invoice_spread_with_hedge(...)  # Next day
        >>> rebal = result_t1.rebalance_contracts(result_t0, notional=10_000_000)
        >>> print(f"Trade {rebal} contracts to rebalance")
    """
    from .conversion_factor import CONTRACT_SPECS

    # Get contract spec
    spec = CONTRACT_SPECS.get(contract.upper())
    if not spec:
        raise ValueError(f"Unknown contract: {contract}")
    contract_size = spec["contract_size"]

    # Invoice price (clean) = Futures × CF
    invoice_clean = futures_price * conversion_factor

    # Accrued interest at delivery
    accrued, _, _ = compute_accrued_interest(delivery_date, maturity_date, coupon)

    # Invoice price (dirty) = clean + accrued
    invoice_dirty = invoice_clean + accrued

    # Forward bond yield from dirty price (30/360, semi-annual)
    forward_bond_yield = compute_yield_from_dirty_price(
        dirty_price=invoice_dirty,
        settlement_date=delivery_date,
        maturity_date=maturity_date,
        coupon=coupon,
    )

    # Forward swap rate (delivery → maturity)
    delivery_years = (delivery_date - value_date).days / 365.0
    maturity_years = (maturity_date - value_date).days / 365.0
    forward_swap_rate = curve.swap_rate(
        start=delivery_years,
        end=maturity_years,
        freq=2,  # Semi-annual
    )

    # Invoice spread = Forward Swap Rate - Forward Bond Yield
    spread_bp = (forward_swap_rate - forward_bond_yield) * 10000

    # Compute duration and DV01
    ctd_duration = _compute_modified_duration(
        dirty_price=invoice_dirty,
        coupon=coupon,
        settlement_date=delivery_date,
        maturity_date=maturity_date,
        yield_rate=forward_bond_yield,
    )

    # CTD DV01 per $100 face
    ctd_dv01 = ctd_duration * invoice_clean * 0.0001

    # Futures DV01 per $1 notional
    # ctd_dv01 is per $100 face, so divide by 100 and adjust for CF
    futures_dv01_per_dollar = (ctd_dv01 / conversion_factor) / 100

    # Futures DV01 per contract (for reference)
    futures_dv01 = futures_dv01_per_dollar * contract_size

    # Swap PV01 per $1 notional (precise from curve)
    swap_pv01 = _compute_swap_pv01(
        curve=curve,
        start_years=delivery_years,
        end_years=maturity_years,
        freq=2,
    )

    # Hedge ratio: futures_notional / swap_notional
    # HR = swap_dv01_per_dollar / futures_dv01_per_dollar
    hedge_ratio = swap_pv01 / futures_dv01_per_dollar

    return InvoiceSpreadWithHedge(
        spread_bp=spread_bp,
        forward_bond_yield=forward_bond_yield,
        forward_swap_rate=forward_swap_rate,
        invoice_price_clean=invoice_clean,
        invoice_price_dirty=invoice_dirty,
        accrued_at_delivery=accrued,
        ctd_duration=ctd_duration,
        ctd_dv01=ctd_dv01,
        futures_dv01=futures_dv01,
        hedge_ratio=hedge_ratio,
        swap_pv01=swap_pv01,
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        delivery_date=delivery_date,
        maturity_date=maturity_date,
        contract=contract.upper(),
    )


def compute_invoice_spread_v2(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    delivery_date: date,
    maturity_date: date,
    curve: SwapCurve,
    value_date: date,
) -> InvoiceSpreadResultV2:
    """
    Compute invoice spread using correct forward bond yield methodology.

    Invoice Spread = Forward Swap Rate - Forward Bond Yield

    Where:
        Invoice Price (Dirty) = Futures × CF + Accrued at Delivery
        Forward Bond Yield = Yield from dirty price (30/360, semi-annual)

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal, e.g., 0.04 for 4%)
        delivery_date: Futures delivery date
        maturity_date: CTD bond maturity date
        curve: SOFR swap curve
        value_date: Current valuation date

    Returns:
        InvoiceSpreadResultV2 with spread and components
    """
    # Invoice price (clean) = Futures × CF
    invoice_clean = futures_price * conversion_factor

    # Accrued interest at delivery
    accrued, _, _ = compute_accrued_interest(delivery_date, maturity_date, coupon)

    # Invoice price (dirty) = clean + accrued
    invoice_dirty = invoice_clean + accrued

    # Forward bond yield from dirty price (30/360, semi-annual)
    forward_bond_yield = compute_yield_from_dirty_price(
        dirty_price=invoice_dirty,
        settlement_date=delivery_date,
        maturity_date=maturity_date,
        coupon=coupon,
    )

    # Forward swap rate (delivery → maturity)
    delivery_years = (delivery_date - value_date).days / 365.0
    maturity_years = (maturity_date - value_date).days / 365.0
    forward_swap_rate = curve.swap_rate(
        start=delivery_years,
        end=maturity_years,
        freq=2,  # Semi-annual
    )

    # Invoice spread = Forward Swap Rate - Forward Bond Yield
    spread_bp = (forward_swap_rate - forward_bond_yield) * 10000

    return InvoiceSpreadResultV2(
        spread_bp=spread_bp,
        forward_bond_yield=forward_bond_yield,
        forward_swap_rate=forward_swap_rate,
        invoice_price_clean=invoice_clean,
        invoice_price_dirty=invoice_dirty,
        accrued_at_delivery=accrued,
        delivery_date=delivery_date,
        maturity_date=maturity_date,
    )


@dataclass
class OptionAdjustedInvoiceSpread:
    """
    Option-adjusted invoice spread result.

    Provides both raw and option-adjusted spreads:
    - Raw: Direct calculation from market futures price
    - Adjusted: Accounts for delivery option value embedded in futures

    Invoice Spread = Forward Swap Rate - Forward Bond Yield

    Includes DV01 and hedge ratio for position management:
        contracts_to_trade = (hr_new - hr_old) × notional / 1_000_000

    If previous swap details are provided, includes:
    - prev_swap_market_rate: Today's market rate for the previous swap tenor
    - prev_swap_pv01: PV01 of the previous swap
    This enables P&L calculation when CTD switches and swap tenor changes.
    """
    # Raw spread (no option adjustment)
    raw_spread_bp: float
    raw_forward_yield: float

    # Option-adjusted spread
    adjusted_spread_bp: float
    adjusted_forward_yield: float

    # Common components
    forward_swap_rate: float
    invoice_price_clean: float
    invoice_price_dirty: float
    accrued_at_delivery: float

    # Option details
    option_value_ticks: float
    option_value_price: float
    option_adjustment_bp: float

    # DV01 and hedge ratio
    ctd_duration: float           # CTD modified duration
    ctd_dv01: float               # CTD DV01 per $100 face
    futures_dv01: float           # Futures DV01 per contract
    hedge_ratio: float            # futures_notional / swap_notional
    swap_pv01: float              # Swap PV01 per $1 notional

    # Reference data
    futures_price: float
    conversion_factor: float
    coupon: float
    contract: str

    # Dates
    delivery_date: date
    maturity_date: date

    # Previous swap details (for P&L tracking on CTD switch)
    prev_swap_market_rate: Optional[float] = None   # Today's rate for prev swap tenor
    prev_swap_pv01: Optional[float] = None          # PV01 of previous swap

    def futures_notional(self, swap_notional: float) -> float:
        """Calculate futures notional needed for a given swap notional."""
        return self.hedge_ratio * swap_notional

    def rebalance_notional(
        self,
        previous: "OptionAdjustedInvoiceSpread",
        swap_notional: float,
    ) -> float:
        """
        Calculate futures notional to trade to rebalance from previous period.

        Args:
            previous: Previous period's result
            swap_notional: Swap notional

        Returns:
            Futures notional to trade (+ = buy, - = sell)
        """
        hr_change = self.hedge_ratio - previous.hedge_ratio
        return hr_change * swap_notional


def compute_invoice_spread_option_adjusted(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    delivery_date: date,
    maturity_date: date,
    curve: SwapCurve,
    value_date: date,
    contract: str = "TY",
    yield_vol_bp: float = 100.0,
    include_option_adjustment: bool = True,
    # Optional: for pricing previous swap (useful on CTD switch)
    prev_swap_start: Optional[date] = None,
    prev_swap_maturity: Optional[date] = None,
    prev_swap_rate: Optional[float] = None,
) -> OptionAdjustedInvoiceSpread:
    """
    Compute invoice spread with optional delivery option adjustment.

    Invoice Spread = Forward Swap Rate - Forward Bond Yield

    The option adjustment accounts for the delivery options embedded in
    treasury futures (quality, timing, wild card, end-of-month options).
    These options make futures trade cheap, so adjusting for them
    TIGHTENS the spread (makes it less negative).

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal, e.g., 0.04 for 4%)
        delivery_date: Futures delivery date
        maturity_date: CTD bond maturity date
        curve: SOFR swap curve
        value_date: Current valuation date
        contract: Contract type for option estimation ("TU", "FV", "TY", "US", "WN")
        yield_vol_bp: Yield volatility in bp for option estimation (default 100)
        include_option_adjustment: If False, option adjustment is zero

        # For pricing previous swap (all optional, use together):
        prev_swap_start: Start date of the previous swap position
        prev_swap_maturity: Maturity date of the previous swap position
        prev_swap_rate: Fixed rate of the previous swap position (decimal)

    Returns:
        OptionAdjustedInvoiceSpread with raw and adjusted spreads.
        If prev_swap details provided, includes prev_swap_market_rate
        (today's market rate for that swap) and prev_swap_pv01.

    See Also:
        invoice_pricer.swaps.price_swap_from_dates - Standalone swap pricer
    """
    # ---- RAW CALCULATION ----
    # Invoice price (clean) = Futures × CF
    invoice_clean = futures_price * conversion_factor

    # Accrued interest at delivery
    accrued, _, _ = compute_accrued_interest(delivery_date, maturity_date, coupon)

    # Invoice price (dirty) = clean + accrued
    invoice_dirty = invoice_clean + accrued

    # Forward bond yield from dirty price (30/360, semi-annual)
    raw_forward_yield = compute_yield_from_dirty_price(
        dirty_price=invoice_dirty,
        settlement_date=delivery_date,
        maturity_date=maturity_date,
        coupon=coupon,
    )

    # Forward swap rate (delivery → maturity)
    delivery_years = (delivery_date - value_date).days / 365.0
    maturity_years = (maturity_date - value_date).days / 365.0
    forward_swap_rate = curve.swap_rate(
        start=delivery_years,
        end=maturity_years,
        freq=2,
    )

    # Raw spread
    raw_spread_bp = (forward_swap_rate - raw_forward_yield) * 10000

    # ---- OPTION ADJUSTMENT ----
    if include_option_adjustment:
        days_to_delivery = (delivery_date - value_date).days
        option_value = estimate_delivery_option_value(
            contract=contract,
            days_to_delivery=days_to_delivery,
            yield_vol_bp=yield_vol_bp,
        )
        option_ticks = option_value.total_ticks
        option_price = option_value.total_price
    else:
        option_ticks = 0.0
        option_price = 0.0

    # Adjusted futures price (add option value)
    adjusted_futures = futures_price + option_price
    adjusted_invoice_clean = adjusted_futures * conversion_factor
    adjusted_invoice_dirty = adjusted_invoice_clean + accrued

    # Adjusted forward yield
    adjusted_forward_yield = compute_yield_from_dirty_price(
        dirty_price=adjusted_invoice_dirty,
        settlement_date=delivery_date,
        maturity_date=maturity_date,
        coupon=coupon,
    )

    # Adjusted spread
    adjusted_spread_bp = (forward_swap_rate - adjusted_forward_yield) * 10000

    # Option adjustment in bp
    option_adjustment_bp = adjusted_spread_bp - raw_spread_bp

    # ---- DV01 AND HEDGE RATIO ----
    from .conversion_factor import CONTRACT_SPECS

    spec = CONTRACT_SPECS.get(contract.upper(), CONTRACT_SPECS["TY"])
    contract_size = spec["contract_size"]

    # Compute duration from raw forward yield
    ctd_duration = _compute_modified_duration(
        dirty_price=invoice_dirty,
        coupon=coupon,
        settlement_date=delivery_date,
        maturity_date=maturity_date,
        yield_rate=raw_forward_yield,
    )

    # CTD DV01 per $100 face
    ctd_dv01 = ctd_duration * invoice_clean * 0.0001

    # Futures DV01 per $1 notional
    futures_dv01_per_dollar = (ctd_dv01 / conversion_factor) / 100

    # Futures DV01 per contract (for reference)
    futures_dv01 = futures_dv01_per_dollar * contract_size

    # Swap PV01 per $1 notional (precise from curve)
    swap_pv01 = _compute_swap_pv01(
        curve=curve,
        start_years=delivery_years,
        end_years=maturity_years,
        freq=2,
    )

    # Hedge ratio: futures_notional / swap_notional
    hedge_ratio = swap_pv01 / futures_dv01_per_dollar

    # ---- PREVIOUS SWAP PRICING (optional) ----
    # If previous swap details provided, compute today's market rate and PV01
    # for that swap. Useful for P&L calculation on CTD switch.
    prev_swap_market_rate_result: Optional[float] = None
    prev_swap_pv01_result: Optional[float] = None

    if prev_swap_start is not None and prev_swap_maturity is not None:
        # Compute years from value_date to prev swap dates
        prev_start_years = (prev_swap_start - value_date).days / 365.0
        prev_end_years = (prev_swap_maturity - value_date).days / 365.0

        # Today's market rate for the previous swap tenor
        if prev_start_years > 0 and prev_end_years > prev_start_years:
            prev_swap_market_rate_result = curve.swap_rate(
                start=prev_start_years,
                end=prev_end_years,
                freq=2,
            )
            # PV01 of the previous swap
            prev_swap_pv01_result = _compute_swap_pv01(
                curve=curve,
                start_years=prev_start_years,
                end_years=prev_end_years,
                freq=2,
            )
        elif prev_end_years > 0:
            # Swap has already started (prev_start_years <= 0)
            # Use spot-starting swap from today to prev_maturity
            prev_swap_market_rate_result = curve.swap_rate(
                start=0.0,
                end=prev_end_years,
                freq=2,
            )
            prev_swap_pv01_result = _compute_swap_pv01(
                curve=curve,
                start_years=0.0,
                end_years=prev_end_years,
                freq=2,
            )

    return OptionAdjustedInvoiceSpread(
        raw_spread_bp=raw_spread_bp,
        raw_forward_yield=raw_forward_yield,
        adjusted_spread_bp=adjusted_spread_bp,
        adjusted_forward_yield=adjusted_forward_yield,
        forward_swap_rate=forward_swap_rate,
        invoice_price_clean=invoice_clean,
        invoice_price_dirty=invoice_dirty,
        accrued_at_delivery=accrued,
        option_value_ticks=option_ticks,
        option_value_price=option_price,
        option_adjustment_bp=option_adjustment_bp,
        ctd_duration=ctd_duration,
        ctd_dv01=ctd_dv01,
        futures_dv01=futures_dv01,
        hedge_ratio=hedge_ratio,
        swap_pv01=swap_pv01,
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        contract=contract.upper(),
        delivery_date=delivery_date,
        maturity_date=maturity_date,
        prev_swap_market_rate=prev_swap_market_rate_result,
        prev_swap_pv01=prev_swap_pv01_result,
    )


# =============================================================================
# LEGACY FUNCTIONS (kept for backwards compatibility)
# =============================================================================

def compute_invoice_spread(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    curve: SwapCurve,
    delivery_years: float,
    swap_freq: int = 2,
) -> InvoiceSpreadResult:
    """
    Compute invoice spread in basis points.

    Invoice spread = Implied Bond Yield - Forward Swap Rate

    The forward swap starts at futures delivery and matures at the CTD
    bond maturity. This represents the basis between treasury futures
    and the matched-maturity swap.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity from value date
        curve: SOFR swap curve
        delivery_years: Time to futures delivery in years
        swap_freq: Swap payment frequency (default 2 = semi-annual)

    Returns:
        InvoiceSpreadResult with spread and components
    """
    # Get futures analytics
    analytics = analyze_futures(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
    )

    implied_yield = analytics.implied_yield

    # Compute forward swap rate (delivery → maturity)
    # The swap tenor at delivery = maturity_years - delivery_years
    swap_end = maturity_years
    forward_swap_rate = curve.swap_rate(
        start=delivery_years,
        end=swap_end,
        freq=swap_freq,
    )

    # Invoice spread in basis points
    spread_bp = (implied_yield - forward_swap_rate) * 10000

    return InvoiceSpreadResult(
        spread_bp=spread_bp,
        implied_yield=implied_yield,
        forward_swap_rate=forward_swap_rate,
        delivery_tenor=delivery_years,
        maturity_tenor=maturity_years,
        futures_dv01=analytics.futures_dv01,
    )


def reverse_invoice_spread(
    invoice_spread_bp: float,
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
) -> float:
    """
    Reverse calculate: given invoice spread and futures price, find the
    implied forward swap fixed rate.

    This is useful for:
    - Verifying spread calculations
    - Trading: given target spread, what swap rate to execute

    Args:
        invoice_spread_bp: Invoice spread in basis points
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity from value date
        delivery_years: Time to futures delivery in years

    Returns:
        Implied forward swap fixed rate (decimal)
    """
    # Get implied yield from futures
    implied_price = implied_bond_price_from_futures(futures_price, conversion_factor)
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    implied_yield = bond_yield(bond, implied_price)

    # Swap rate = Implied yield - spread
    spread_decimal = invoice_spread_bp / 10000
    return implied_yield - spread_decimal


@dataclass
class InvoiceTradeAnalytics:
    """Complete analytics for an invoice spread trade."""
    spread_bp: float
    implied_yield: float
    forward_swap_rate: float
    futures_dv01: float
    swap_dv01: float
    hedge_ratio: float  # Swap notional per futures contract


def analyze_invoice_trade(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    curve: SwapCurve,
    delivery_years: float,
    futures_notional: float = 100_000,
    swap_freq: int = 2,
) -> InvoiceTradeAnalytics:
    """
    Complete analytics for structuring an invoice spread trade.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity
        curve: SOFR swap curve
        delivery_years: Time to futures delivery
        futures_notional: Notional per futures contract (default $100k)
        swap_freq: Swap payment frequency

    Returns:
        InvoiceTradeAnalytics with hedge ratio
    """
    result = compute_invoice_spread(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
        curve=curve,
        delivery_years=delivery_years,
        swap_freq=swap_freq,
    )

    # Approximate swap DV01 (per $1M notional)
    # Swap DV01 ≈ tenor × 0.0001 × notional
    swap_tenor = maturity_years - delivery_years
    swap_dv01_per_mm = swap_tenor * 0.0001 * 1_000_000

    # Hedge ratio: swap notional needed to match futures DV01
    # Futures DV01 is per $100k notional
    hedge_ratio = (result.futures_dv01 / swap_dv01_per_mm) * 1_000_000

    return InvoiceTradeAnalytics(
        spread_bp=result.spread_bp,
        implied_yield=result.implied_yield,
        forward_swap_rate=result.forward_swap_rate,
        futures_dv01=result.futures_dv01,
        swap_dv01=swap_dv01_per_mm / 1000,  # Per $1k for comparison
        hedge_ratio=hedge_ratio,
    )


def compute_invoice_spread_adjusted(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    curve: SwapCurve,
    delivery_years: float,
    contract_type: FuturesContract | str = FuturesContract.TY,
    yield_vol_bp: float = 100.0,
    swap_freq: int = 2,
    include_delivery_options: bool = True,
    # Optional: for carry adjustment
    spot_clean_price: float | None = None,
    repo_rate: float | None = None,
    value_date: date | None = None,
    delivery_date: date | None = None,
    ctd_maturity_date: date | None = None,
) -> AdjustedInvoiceSpreadResult:
    """
    Compute invoice spread with carry and delivery option adjustments.

    This is the PRODUCTION version that accounts for:
    1. CARRY: Financing cost vs coupon income (requires spot + repo)
    2. DELIVERY OPTIONS: Short's embedded optionality

    THREE YIELD LEVELS:
    -------------------
    1. RAW: Simple Futures × CF (ignores everything)
       - What you see if you just convert futures to yield naively

    2. CARRY-ADJUSTED: Uses theoretical forward price
       - Forward Price = Spot × (1 + repo × t) - Coupon FV
       - Requires spot_clean_price and repo_rate inputs
       - If not provided, equals raw

    3. FULLY ADJUSTED: Carry + delivery options
       - Adds option value to get "fair" yield for swap comparison

    TYPICAL ADJUSTMENTS (10Y):
    --------------------------
    - Carry: -5 to +10 bp (depends on curve shape, repo vs coupon)
    - Options: -2 to -3 bp (futures trade cheap)
    - Total: varies significantly with market conditions

    Args:
        futures_price: Market futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity from value date
        curve: SOFR swap curve
        delivery_years: Time to futures delivery in years
        contract_type: Contract type for option estimation
        yield_vol_bp: Yield volatility for option estimation
        swap_freq: Swap payment frequency (default 2 = semi-annual)
        include_delivery_options: If False, disables option adjustments

        # For carry adjustment (all required together):
        spot_clean_price: CTD bond clean price (optional)
        repo_rate: Term repo rate to delivery (optional)
        value_date: Current date (optional, for carry calc)
        delivery_date: Futures delivery date (optional)
        ctd_maturity_date: CTD bond maturity date (optional)

    Returns:
        AdjustedInvoiceSpreadResult with raw, carry-adjusted, and fully adjusted spreads
    """
    # Estimate delivery option value
    days_to_delivery = int(delivery_years * 365)
    option_value = estimate_delivery_option_value(
        contract=contract_type,
        days_to_delivery=days_to_delivery,
        yield_vol_bp=yield_vol_bp,
        include_delivery_options=include_delivery_options,
    )
    option_ticks = option_value.total_ticks

    # Raw implied yield (simple calculation)
    raw_analytics = analyze_futures(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
    )
    raw_implied_yield = raw_analytics.implied_yield

    # Forward swap rate
    forward_swap_rate = curve.swap_rate(
        start=delivery_years,
        end=maturity_years,
        freq=swap_freq,
    )

    # ----- CARRY ADJUSTMENT -----
    # If spot price and repo rate provided, compute carry-adjusted yield
    carry_adjustment_bp = 0.0
    carry_adjusted_yield = raw_implied_yield

    if all([spot_clean_price, repo_rate, value_date, delivery_date, ctd_maturity_date]):
        # Build TreasuryBond for carry calculation
        bond = TreasuryBond(
            coupon=coupon,
            maturity_date=ctd_maturity_date,
        )

        # Calculate carry
        carry = calculate_carry(
            bond=bond,
            spot_clean_price=spot_clean_price,
            settle_date=value_date,
            delivery_date=delivery_date,
            repo_rate=repo_rate,
        )

        # Theoretical futures price (no-arbitrage forward)
        # Forward Clean = Spot Dirty + Financing - Coupon - Accrued@Delivery
        theoretical_futures = carry.forward_clean_price / conversion_factor

        # Carry-adjusted yield uses theoretical futures
        carry_adjusted_price = theoretical_futures * conversion_factor
        bond_simple = Bond(coupon=coupon, maturity_years=maturity_years)
        carry_adjusted_yield = bond_yield(bond_simple, carry_adjusted_price)

        carry_adjustment_bp = (carry_adjusted_yield - raw_implied_yield) * 10000

    # ----- OPTION ADJUSTMENT -----
    # Apply option adjustment on top of carry-adjusted yield
    if option_ticks > 0:
        # Option-adjusted futures = carry-adjusted theoretical + option value
        option_price_adjustment = option_ticks / 32.0

        # If we have carry adjustment, apply options to theoretical futures
        if carry_adjustment_bp != 0:
            theoretical_futures = carry.forward_clean_price / conversion_factor
            adjusted_futures = theoretical_futures + option_price_adjustment
        else:
            # No carry data, apply options to market futures
            adjusted_futures = futures_price + option_price_adjustment

        adjusted_implied_price = adjusted_futures * conversion_factor
        bond_simple = Bond(coupon=coupon, maturity_years=maturity_years)
        adjusted_implied_yield = bond_yield(bond_simple, adjusted_implied_price)
    else:
        # No option adjustment
        adjusted_implied_yield = carry_adjusted_yield

    option_adjustment_bp = (adjusted_implied_yield - carry_adjusted_yield) * 10000

    # Invoice spreads at each level
    raw_spread_bp = (raw_implied_yield - forward_swap_rate) * 10000
    carry_adjusted_spread_bp = (carry_adjusted_yield - forward_swap_rate) * 10000
    adjusted_spread_bp = (adjusted_implied_yield - forward_swap_rate) * 10000

    return AdjustedInvoiceSpreadResult(
        raw_spread_bp=raw_spread_bp,
        raw_implied_yield=raw_implied_yield,
        carry_adjusted_spread_bp=carry_adjusted_spread_bp,
        carry_adjusted_yield=carry_adjusted_yield,
        adjusted_spread_bp=adjusted_spread_bp,
        adjusted_implied_yield=adjusted_implied_yield,
        forward_swap_rate=forward_swap_rate,
        delivery_tenor=delivery_years,
        maturity_tenor=maturity_years,
        futures_dv01=raw_analytics.futures_dv01,
        carry_adjustment_bp=carry_adjustment_bp,
        option_adjustment_ticks=option_ticks,
        option_adjustment_bp=option_adjustment_bp,
    )


def reverse_invoice_spread_adjusted(
    invoice_spread_bp: float,
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
    contract_type: FuturesContract | str = FuturesContract.TY,
    yield_vol_bp: float = 100.0,
) -> float:
    """
    Reverse calculate swap rate from adjusted invoice spread.

    Given a TARGET adjusted invoice spread, calculate what swap rate
    you need to execute.

    Args:
        invoice_spread_bp: Target invoice spread (adjusted) in bp
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity
        delivery_years: Time to futures delivery
        contract_type: Contract type for option estimation
        yield_vol_bp: Yield volatility for option estimation

    Returns:
        Required forward swap fixed rate (decimal)
    """
    # Get option-adjusted implied yield
    days_to_delivery = int(delivery_years * 365)
    option_value = estimate_delivery_option_value(
        contract=contract_type,
        days_to_delivery=days_to_delivery,
        yield_vol_bp=yield_vol_bp,
    )

    adjusted_yield = compute_adjusted_implied_yield(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
        delivery_option_ticks=option_value.total_ticks,
    )

    # Swap rate = Adjusted yield - spread
    spread_decimal = invoice_spread_bp / 10000
    return adjusted_yield - spread_decimal
