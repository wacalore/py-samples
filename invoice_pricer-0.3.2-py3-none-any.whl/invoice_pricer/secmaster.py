"""
UST Bond Security Master.

Fetches and manages Treasury bond data from Treasury Direct for
deliverable basket analysis.

Example:
    >>> from invoice_pricer.secmaster import fetch_treasury_auctions, TreasuryBondInfo
    >>> bonds = fetch_treasury_auctions(security_type="Bond")
    >>> for bond in bonds[:5]:
    ...     print(f"{bond.cusip}: {bond.coupon*100:.3f}% {bond.maturity_date}")
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import List, Optional, Literal
import urllib.request
import json


@dataclass
class TreasuryBondInfo:
    """
    Treasury bond security master record.

    Attributes:
        cusip: 9-character CUSIP identifier
        security_type: NOTE, BOND, BILL, FRN, TIPS
        coupon: Annual coupon rate (decimal, e.g., 0.04125 for 4.125%)
        maturity_date: Bond maturity date
        issue_date: Original issue date
        auction_date: Auction date
        dated_date: Dated date (accrual start)
        first_coupon_date: First coupon payment date
        original_amount: Original issue amount in millions
        reopening: Whether this is a reopening of existing CUSIP
    """
    cusip: str
    security_type: str
    coupon: float
    maturity_date: date
    issue_date: date
    auction_date: Optional[date] = None
    dated_date: Optional[date] = None
    first_coupon_date: Optional[date] = None
    original_amount: Optional[float] = None
    reopening: bool = False

    @property
    def coupon_months(self) -> tuple:
        """Return the two coupon payment months based on maturity."""
        m = self.maturity_date.month
        if m <= 6:
            return (m, m + 6)
        else:
            return (m - 6, m)

    @property
    def years_to_maturity(self) -> float:
        """Years from today to maturity."""
        return (self.maturity_date - date.today()).days / 365.0

    def years_to_maturity_from(self, ref_date: date) -> float:
        """Years from reference date to maturity."""
        return (self.maturity_date - ref_date).days / 365.0


def _parse_date(date_str: str) -> Optional[date]:
    """Parse Treasury Direct date format."""
    if not date_str:
        return None
    try:
        # Format: "2024-01-15T00:00:00"
        return datetime.fromisoformat(date_str.replace("Z", "")).date()
    except (ValueError, AttributeError):
        return None


def _parse_float(val) -> Optional[float]:
    """Parse float, handling None and empty strings."""
    if val is None or val == "":
        return None
    try:
        return float(val)
    except (ValueError, TypeError):
        return None


def fetch_treasury_auctions(
    security_type: Literal["Bond", "Note", "Bill", "FRN", "TIPS", "CMB"] = "Bond",
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    days_back: int = 3650,
) -> List[TreasuryBondInfo]:
    """
    Fetch Treasury auction data from Treasury Direct API.

    Args:
        security_type: Type of security to fetch
        start_date: Start date for auction search (default: days_back from today)
        end_date: End date for auction search (default: today)
        days_back: Days to look back if start_date not specified

    Returns:
        List of TreasuryBondInfo records

    Example:
        >>> bonds = fetch_treasury_auctions("Bond", days_back=365*5)
        >>> print(f"Found {len(bonds)} bonds")
    """
    if end_date is None:
        end_date = date.today()
    if start_date is None:
        start_date = date.today().replace(year=date.today().year - (days_back // 365))

    # Treasury Direct API endpoint
    base_url = "https://api.fiscaldata.treasury.gov/services/api/fiscal_service"
    endpoint = "/v1/accounting/od/auctions_query"

    # Build query parameters
    params = [
        f"filter=security_type:eq:{security_type}",
        f"filter=auction_date:gte:{start_date.isoformat()}",
        f"filter=auction_date:lte:{end_date.isoformat()}",
        "sort=-auction_date",
        "page[size]=10000",
    ]

    url = f"{base_url}{endpoint}?{'&'.join(params)}"

    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            data = json.loads(response.read().decode())
    except Exception as e:
        raise RuntimeError(f"Failed to fetch Treasury data: {e}")

    bonds = []
    for record in data.get("data", []):
        # Parse coupon rate (field is 'int_rate' in Treasury API)
        coupon_str = record.get("int_rate", "0")
        coupon = _parse_float(coupon_str)
        if coupon is not None:
            coupon = coupon / 100.0  # Convert from percentage
        else:
            coupon = 0.0

        bond = TreasuryBondInfo(
            cusip=record.get("cusip", ""),
            security_type=record.get("security_type", ""),
            coupon=coupon,
            maturity_date=_parse_date(record.get("maturity_date")) or date.today(),
            issue_date=_parse_date(record.get("issue_date")) or date.today(),
            auction_date=_parse_date(record.get("auction_date")),
            dated_date=_parse_date(record.get("dated_date")),
            first_coupon_date=_parse_date(record.get("first_interest_payment_date")),
            original_amount=_parse_float(record.get("offering_amt")),
            reopening=record.get("reopening", "No") == "Yes",
        )
        bonds.append(bond)

    return bonds


def build_secmaster(
    include_notes: bool = True,
    include_bonds: bool = True,
    days_back: int = 3650,
    dedupe_cusips: bool = True,
) -> List[TreasuryBondInfo]:
    """
    Build a comprehensive security master of Treasury notes and bonds.

    Args:
        include_notes: Include Treasury Notes (2-10Y)
        include_bonds: Include Treasury Bonds (20-30Y)
        days_back: How far back to search for auctions
        dedupe_cusips: Keep only latest record per CUSIP

    Returns:
        List of TreasuryBondInfo records sorted by maturity date

    Example:
        >>> secmaster = build_secmaster(days_back=365*10)
        >>> print(f"Built secmaster with {len(secmaster)} securities")
    """
    all_bonds = []

    if include_notes:
        all_bonds.extend(fetch_treasury_auctions("Note", days_back=days_back))
    if include_bonds:
        all_bonds.extend(fetch_treasury_auctions("Bond", days_back=days_back))

    if dedupe_cusips:
        # Keep latest record per CUSIP
        seen = {}
        for bond in all_bonds:
            if bond.cusip not in seen:
                seen[bond.cusip] = bond
            elif bond.auction_date and seen[bond.cusip].auction_date:
                if bond.auction_date > seen[bond.cusip].auction_date:
                    seen[bond.cusip] = bond
        all_bonds = list(seen.values())

    # Sort by maturity date
    all_bonds.sort(key=lambda b: b.maturity_date)

    return all_bonds


def filter_by_maturity(
    bonds: List[TreasuryBondInfo],
    min_years: float,
    max_years: float,
    as_of: Optional[date] = None,
) -> List[TreasuryBondInfo]:
    """
    Filter bonds by remaining years to maturity.

    Args:
        bonds: List of bonds to filter
        min_years: Minimum years to maturity
        max_years: Maximum years to maturity
        as_of: Reference date (default: today)

    Returns:
        Filtered list of bonds
    """
    if as_of is None:
        as_of = date.today()

    return [
        b for b in bonds
        if min_years <= b.years_to_maturity_from(as_of) <= max_years
    ]
