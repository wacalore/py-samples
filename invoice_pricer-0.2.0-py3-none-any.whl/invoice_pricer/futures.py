"""
Treasury futures pricing and analytics.

UNDERSTANDING IMPLIED YIELD CALCULATIONS
========================================

There are THREE levels of sophistication for computing implied yield from futures:

1. SIMPLE (Textbook)
   Implied Price = Futures × CF
   Then solve for yield from this price.

   PROBLEM: Ignores that futures trade CHEAP to spot due to:
   - Cost of carry (financing vs coupon income)
   - Delivery option value (short's optionality)

2. CARRY-ADJUSTED
   Forward Price = Spot × (1 + repo × t) - Coupon FV
   Futures × CF should equal Forward Price if no options

   By using observed futures + carry, we get closer to true forward yield.

3. FULLY ADJUSTED (Production)
   Also accounts for delivery option value.
   Adjusted Futures = Market Futures + Option Value
   Then compute implied yield from adjusted price.

   This gives the most accurate "economic" yield implied by futures.

WHICH TO USE?
=============
- For TRADING/HEDGING: Use market futures directly (what you transact at)
- For RELATIVE VALUE: Use carry-adjusted (compare to spot basis)
- For INVOICE SPREADS: Use fully adjusted (compare to swaps fairly)
"""

from dataclasses import dataclass
from datetime import date
from typing import Optional

from .bonds import (
    Bond, TreasuryBond, bond_price, bond_yield, dv01, modified_duration,
    accrued_interest,
)
from .carry import calculate_carry, CarryComponents, implied_repo_rate, net_basis
from .delivery_option import (
    estimate_delivery_option_value, DeliveryOptionValue, FuturesContract,
    adjusted_futures_price,
)


@dataclass
class FuturesAnalytics:
    """Analytics for a treasury futures position (simple model)."""
    futures_price: float
    conversion_factor: float
    implied_bond_price: float
    implied_yield: float
    futures_dv01: float
    modified_duration: float


@dataclass
class AdjustedFuturesAnalytics:
    """
    Production-level futures analytics with all adjustments.

    Provides three yield measures:
    1. raw_implied_yield: Simple futures × CF calculation
    2. carry_adjusted_yield: Accounts for financing/carry
    3. option_adjusted_yield: Full adjustment including delivery options
    """
    # Market data
    futures_price: float
    spot_clean_price: float
    conversion_factor: float
    repo_rate: float

    # Simple calculation
    raw_implied_price: float
    raw_implied_yield: float

    # Carry analysis
    carry: CarryComponents
    gross_basis: float          # Spot - Futures × CF (in price points)
    net_basis: float            # Gross basis - carry (in price points)
    implied_repo: float         # Breakeven financing rate

    # Option adjustment
    delivery_option: DeliveryOptionValue
    option_adjusted_futures: float
    option_adjusted_yield: float

    # Risk metrics
    futures_dv01: float
    modified_duration: float

    @property
    def gross_basis_ticks(self) -> float:
        """Gross basis in 32nds."""
        return self.gross_basis * 32

    @property
    def net_basis_ticks(self) -> float:
        """Net basis in 32nds."""
        return self.net_basis * 32

    @property
    def yield_adjustment_bp(self) -> float:
        """Total yield adjustment from raw to option-adjusted (in bp)."""
        return (self.option_adjusted_yield - self.raw_implied_yield) * 10000


def implied_bond_price_from_futures(
    futures_price: float,
    conversion_factor: float,
) -> float:
    """
    Calculate implied bond price from futures price (SIMPLE METHOD).

    The relationship is: Futures Price × CF ≈ Bond Price

    IMPORTANT: This is the TEXTBOOK calculation that ignores:
    - Carry (repo financing cost vs coupon income)
    - Delivery options (short's optionality)

    For production use, see `compute_adjusted_implied_yield`.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor

    Returns:
        Implied clean bond price
    """
    return futures_price * conversion_factor


def implied_yield_from_futures(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
) -> float:
    """
    Calculate implied bond yield from futures price.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity

    Returns:
        Implied yield to maturity
    """
    implied_price = implied_bond_price_from_futures(futures_price, conversion_factor)
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    return bond_yield(bond, implied_price)


def futures_dv01(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
) -> float:
    """
    Calculate DV01 of treasury futures contract.

    The futures DV01 relates to bond DV01 via conversion factor:
    Futures DV01 = Bond DV01 / CF

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity

    Returns:
        Futures DV01 per $100,000 notional
    """
    implied_price = implied_bond_price_from_futures(futures_price, conversion_factor)
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    ytm = bond_yield(bond, implied_price)
    bond_dv01 = dv01(bond, ytm)

    # Futures DV01 = Bond DV01 / CF, scaled to contract notional
    # Standard futures contract is $100,000 face
    return (bond_dv01 / conversion_factor) * 1000  # Per $100k notional


def analyze_futures(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
) -> FuturesAnalytics:
    """
    Complete analytics for a treasury futures position.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity

    Returns:
        FuturesAnalytics with all computed values
    """
    implied_price = implied_bond_price_from_futures(futures_price, conversion_factor)
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    ytm = bond_yield(bond, implied_price)
    mod_dur = modified_duration(bond, ytm)
    fut_dv01 = (dv01(bond, ytm) / conversion_factor) * 1000

    return FuturesAnalytics(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        implied_bond_price=implied_price,
        implied_yield=ytm,
        futures_dv01=fut_dv01,
        modified_duration=mod_dur,
    )


def analyze_futures_adjusted(
    futures_price: float,
    spot_clean_price: float,
    conversion_factor: float,
    bond: TreasuryBond,
    settle_date: date,
    delivery_date: date,
    repo_rate: float,
    contract_type: FuturesContract | str = FuturesContract.TY,
    yield_vol_bp: float = 100.0,
) -> AdjustedFuturesAnalytics:
    """
    Production-level futures analytics with carry and option adjustments.

    This function computes THREE implied yield measures:

    1. RAW IMPLIED YIELD
       Simple: Implied Price = Futures × CF, solve for yield
       Problem: Futures trade cheap, so this OVERSTATES yield

    2. CARRY-ADJUSTED YIELD (not directly output, implicit in net basis)
       Accounts for financing cost and coupon income between now and delivery

    3. OPTION-ADJUSTED YIELD
       Adds estimated delivery option value to futures price, then computes yield
       This is the most accurate "economic" yield for comparing to swaps

    Args:
        futures_price: Market futures price
        spot_clean_price: Current cash bond clean price
        conversion_factor: CTD conversion factor
        bond: Full treasury bond specification with dates
        settle_date: Current settlement date
        delivery_date: Futures delivery date
        repo_rate: Term repo rate to delivery (annualized, Act/360)
        contract_type: Futures contract for option estimation (TU, FV, TY, US)
        yield_vol_bp: Yield volatility for option estimation (default 100bp)

    Returns:
        AdjustedFuturesAnalytics with full breakdown
    """
    # Compute maturity for bond math
    maturity_years = (bond.maturity_date - settle_date).days / 365.0
    simple_bond = Bond(coupon=bond.coupon, maturity_years=maturity_years)

    # 1. Raw implied yield (simple method)
    raw_implied_price = futures_price * conversion_factor
    raw_implied_yield = bond_yield(simple_bond, raw_implied_price)

    # 2. Carry calculation
    carry = calculate_carry(
        bond=bond,
        spot_clean_price=spot_clean_price,
        settle_date=settle_date,
        delivery_date=delivery_date,
        repo_rate=repo_rate,
    )

    # Gross basis = Spot - Futures × CF
    gross = spot_clean_price - futures_price * conversion_factor

    # Net basis = Gross basis - Net carry
    net = gross - carry.net_carry

    # Implied repo rate
    impl_repo = implied_repo_rate(
        bond=bond,
        spot_clean_price=spot_clean_price,
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        settle_date=settle_date,
        delivery_date=delivery_date,
    )

    # 3. Delivery option estimation
    days_to_delivery = (delivery_date - settle_date).days
    option_value = estimate_delivery_option_value(
        contract=contract_type,
        days_to_delivery=days_to_delivery,
        yield_vol_bp=yield_vol_bp,
    )

    # Option-adjusted futures price
    adj_futures = adjusted_futures_price(futures_price, option_value)
    adj_implied_price = adj_futures * conversion_factor
    option_adjusted_yield = bond_yield(simple_bond, adj_implied_price)

    # Risk metrics
    mod_dur = modified_duration(simple_bond, raw_implied_yield)
    fut_dv01 = (dv01(simple_bond, raw_implied_yield) / conversion_factor) * 1000

    return AdjustedFuturesAnalytics(
        futures_price=futures_price,
        spot_clean_price=spot_clean_price,
        conversion_factor=conversion_factor,
        repo_rate=repo_rate,
        raw_implied_price=raw_implied_price,
        raw_implied_yield=raw_implied_yield,
        carry=carry,
        gross_basis=gross,
        net_basis=net,
        implied_repo=impl_repo,
        delivery_option=option_value,
        option_adjusted_futures=adj_futures,
        option_adjusted_yield=option_adjusted_yield,
        futures_dv01=fut_dv01,
        modified_duration=mod_dur,
    )


def compute_adjusted_implied_yield(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_option_ticks: float = 0.0,
) -> float:
    """
    Compute implied yield with optional delivery option adjustment.

    This is a simplified interface when you don't have full spot/repo data
    but want to account for delivery options.

    FORMULA:
    --------
    Adjusted Futures = Market Futures + (option_ticks / 32)
    Adjusted Price = Adjusted Futures × CF
    Yield = solve(price = Adjusted Price)

    WHY ADJUST?
    -----------
    Futures trade cheap due to short's delivery options.
    Adding back the option value gives a yield closer to the
    "true" forward yield that would prevail without optionality.

    Typical adjustments (in ticks/32nds):
    - 2Y (TU): 2-3 ticks
    - 5Y (FV): 4-5 ticks
    - 10Y (TY): 6-8 ticks
    - 30Y (US): 12-15 ticks

    Args:
        futures_price: Market futures price
        conversion_factor: CTD conversion factor
        coupon: Bond coupon (decimal)
        maturity_years: Years to bond maturity
        delivery_option_ticks: Option value in 32nds (default 0 = no adjustment)

    Returns:
        Option-adjusted implied yield
    """
    option_price_adjustment = delivery_option_ticks / 32.0
    adjusted_futures = futures_price + option_price_adjustment
    implied_price = adjusted_futures * conversion_factor
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    return bond_yield(bond, implied_price)
