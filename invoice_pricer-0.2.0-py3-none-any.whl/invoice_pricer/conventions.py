"""Day count conventions and date utilities."""

from abc import ABC, abstractmethod
from datetime import date
from enum import Enum
from typing import Protocol


class DayCountConvention(Protocol):
    """Protocol for day count conventions."""

    def year_fraction(self, start: date, end: date) -> float:
        """Calculate year fraction between two dates."""
        ...


class Act360:
    """Actual/360 day count convention (standard for USD SOFR swaps)."""

    def year_fraction(self, start: date, end: date) -> float:
        return (end - start).days / 360.0


class Act365:
    """Actual/365 day count convention."""

    def year_fraction(self, start: date, end: date) -> float:
        return (end - start).days / 365.0


class Thirty360:
    """30/360 day count convention (bond basis)."""

    def year_fraction(self, start: date, end: date) -> float:
        d1, m1, y1 = start.day, start.month, start.year
        d2, m2, y2 = end.day, end.month, end.year
        d1 = min(d1, 30)
        if d1 == 30:
            d2 = min(d2, 30)
        days = 360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1)
        return days / 360.0


class ActAct:
    """Actual/Actual day count convention (treasury bonds)."""

    def year_fraction(self, start: date, end: date) -> float:
        # Simplified: use actual days / 365.25
        return (end - start).days / 365.25


# Default conventions
DEFAULT_SWAP_DAY_COUNT = Act360()
DEFAULT_BOND_DAY_COUNT = ActAct()
