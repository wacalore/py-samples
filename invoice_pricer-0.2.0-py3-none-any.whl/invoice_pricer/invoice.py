"""
Invoice spread calculation engine.

WHAT IS AN INVOICE SPREAD?
==========================
An invoice spread is the yield difference between:
1. Treasury futures (converted to yield via CTD bond)
2. A forward-starting SOFR swap (delivery date → CTD maturity)

    Invoice Spread = Futures Implied Yield - Forward Swap Rate

WHY TRADE INVOICE SPREADS?
==========================
- Express view on treasury vs swap spreads going forward
- Hedge treasury/swap basis risk
- Relative value between cash treasuries and swaps
- Capture roll-down or curve movements

PRODUCTION CONSIDERATIONS
=========================
The "simple" calculation ignores that futures trade cheap due to:
1. Cost of carry (financing the underlying bond)
2. Delivery option value (short's embedded options)

For accurate relative value analysis, use the ADJUSTED spread which:
- Adds delivery option value to futures price
- Computes "true" forward yield for fair swap comparison

Typical adjustment: 2-4 bp tighter (adjusted spread < raw spread)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional

from .bonds import Bond, TreasuryBond, bond_yield
from .curves import SwapCurve
from .futures import (
    implied_bond_price_from_futures,
    analyze_futures,
    compute_adjusted_implied_yield,
)
from .carry import calculate_carry, CarryComponents
from .delivery_option import estimate_delivery_option_value, FuturesContract


@dataclass
class InvoiceSpreadResult:
    """Result of invoice spread calculation."""
    spread_bp: float              # Invoice spread in basis points
    implied_yield: float          # Futures-implied bond yield
    forward_swap_rate: float      # Forward swap rate
    delivery_tenor: float         # Time to delivery in years
    maturity_tenor: float         # Time to bond maturity in years
    futures_dv01: float           # DV01 of futures position


@dataclass
class AdjustedInvoiceSpreadResult:
    """
    Production-level invoice spread with adjustments.

    Provides THREE yield/spread measures:
    1. RAW: Simple Futures × CF (ignores carry and options)
    2. CARRY-ADJUSTED: Accounts for repo financing (requires spot + repo inputs)
    3. FULLY ADJUSTED: Carry + delivery options

    If spot_price/repo_rate not provided, carry fields will equal raw.
    """
    # Raw calculation (simple futures × CF)
    raw_spread_bp: float
    raw_implied_yield: float

    # Carry-adjusted (uses spot price and repo rate)
    carry_adjusted_spread_bp: float
    carry_adjusted_yield: float

    # Fully adjusted (carry + delivery options)
    adjusted_spread_bp: float
    adjusted_implied_yield: float

    # Common components
    forward_swap_rate: float
    delivery_tenor: float
    maturity_tenor: float
    futures_dv01: float

    # Adjustment details
    carry_adjustment_bp: float       # Carry effect in bp
    option_adjustment_ticks: float   # Option value in ticks
    option_adjustment_bp: float      # Option effect in bp

    @property
    def total_adjustment_bp(self) -> float:
        """Total adjustment from raw to fully adjusted."""
        return self.raw_spread_bp - self.adjusted_spread_bp

    @property
    def spread_difference_bp(self) -> float:
        """Alias for total_adjustment_bp (backwards compatibility)."""
        return self.total_adjustment_bp


def compute_invoice_spread(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    curve: SwapCurve,
    delivery_years: float,
    swap_freq: int = 2,
) -> InvoiceSpreadResult:
    """
    Compute invoice spread in basis points.

    Invoice spread = Implied Bond Yield - Forward Swap Rate

    The forward swap starts at futures delivery and matures at the CTD
    bond maturity. This represents the basis between treasury futures
    and the matched-maturity swap.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity from value date
        curve: SOFR swap curve
        delivery_years: Time to futures delivery in years
        swap_freq: Swap payment frequency (default 2 = semi-annual)

    Returns:
        InvoiceSpreadResult with spread and components
    """
    # Get futures analytics
    analytics = analyze_futures(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
    )

    implied_yield = analytics.implied_yield

    # Compute forward swap rate (delivery → maturity)
    # The swap tenor at delivery = maturity_years - delivery_years
    swap_end = maturity_years
    forward_swap_rate = curve.swap_rate(
        start=delivery_years,
        end=swap_end,
        freq=swap_freq,
    )

    # Invoice spread in basis points
    spread_bp = (implied_yield - forward_swap_rate) * 10000

    return InvoiceSpreadResult(
        spread_bp=spread_bp,
        implied_yield=implied_yield,
        forward_swap_rate=forward_swap_rate,
        delivery_tenor=delivery_years,
        maturity_tenor=maturity_years,
        futures_dv01=analytics.futures_dv01,
    )


def reverse_invoice_spread(
    invoice_spread_bp: float,
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
) -> float:
    """
    Reverse calculate: given invoice spread and futures price, find the
    implied forward swap fixed rate.

    This is useful for:
    - Verifying spread calculations
    - Trading: given target spread, what swap rate to execute

    Args:
        invoice_spread_bp: Invoice spread in basis points
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity from value date
        delivery_years: Time to futures delivery in years

    Returns:
        Implied forward swap fixed rate (decimal)
    """
    # Get implied yield from futures
    implied_price = implied_bond_price_from_futures(futures_price, conversion_factor)
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    implied_yield = bond_yield(bond, implied_price)

    # Swap rate = Implied yield - spread
    spread_decimal = invoice_spread_bp / 10000
    return implied_yield - spread_decimal


@dataclass
class InvoiceTradeAnalytics:
    """Complete analytics for an invoice spread trade."""
    spread_bp: float
    implied_yield: float
    forward_swap_rate: float
    futures_dv01: float
    swap_dv01: float
    hedge_ratio: float  # Swap notional per futures contract


def analyze_invoice_trade(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    curve: SwapCurve,
    delivery_years: float,
    futures_notional: float = 100_000,
    swap_freq: int = 2,
) -> InvoiceTradeAnalytics:
    """
    Complete analytics for structuring an invoice spread trade.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity
        curve: SOFR swap curve
        delivery_years: Time to futures delivery
        futures_notional: Notional per futures contract (default $100k)
        swap_freq: Swap payment frequency

    Returns:
        InvoiceTradeAnalytics with hedge ratio
    """
    result = compute_invoice_spread(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
        curve=curve,
        delivery_years=delivery_years,
        swap_freq=swap_freq,
    )

    # Approximate swap DV01 (per $1M notional)
    # Swap DV01 ≈ tenor × 0.0001 × notional
    swap_tenor = maturity_years - delivery_years
    swap_dv01_per_mm = swap_tenor * 0.0001 * 1_000_000

    # Hedge ratio: swap notional needed to match futures DV01
    # Futures DV01 is per $100k notional
    hedge_ratio = (result.futures_dv01 / swap_dv01_per_mm) * 1_000_000

    return InvoiceTradeAnalytics(
        spread_bp=result.spread_bp,
        implied_yield=result.implied_yield,
        forward_swap_rate=result.forward_swap_rate,
        futures_dv01=result.futures_dv01,
        swap_dv01=swap_dv01_per_mm / 1000,  # Per $1k for comparison
        hedge_ratio=hedge_ratio,
    )


def compute_invoice_spread_adjusted(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    curve: SwapCurve,
    delivery_years: float,
    contract_type: FuturesContract | str = FuturesContract.TY,
    yield_vol_bp: float = 100.0,
    swap_freq: int = 2,
    include_delivery_options: bool = True,
    # Optional: for carry adjustment
    spot_clean_price: float | None = None,
    repo_rate: float | None = None,
    value_date: date | None = None,
    delivery_date: date | None = None,
    ctd_maturity_date: date | None = None,
) -> AdjustedInvoiceSpreadResult:
    """
    Compute invoice spread with carry and delivery option adjustments.

    This is the PRODUCTION version that accounts for:
    1. CARRY: Financing cost vs coupon income (requires spot + repo)
    2. DELIVERY OPTIONS: Short's embedded optionality

    THREE YIELD LEVELS:
    -------------------
    1. RAW: Simple Futures × CF (ignores everything)
       - What you see if you just convert futures to yield naively

    2. CARRY-ADJUSTED: Uses theoretical forward price
       - Forward Price = Spot × (1 + repo × t) - Coupon FV
       - Requires spot_clean_price and repo_rate inputs
       - If not provided, equals raw

    3. FULLY ADJUSTED: Carry + delivery options
       - Adds option value to get "fair" yield for swap comparison

    TYPICAL ADJUSTMENTS (10Y):
    --------------------------
    - Carry: -5 to +10 bp (depends on curve shape, repo vs coupon)
    - Options: -2 to -3 bp (futures trade cheap)
    - Total: varies significantly with market conditions

    Args:
        futures_price: Market futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity from value date
        curve: SOFR swap curve
        delivery_years: Time to futures delivery in years
        contract_type: Contract type for option estimation
        yield_vol_bp: Yield volatility for option estimation
        swap_freq: Swap payment frequency (default 2 = semi-annual)
        include_delivery_options: If False, disables option adjustments

        # For carry adjustment (all required together):
        spot_clean_price: CTD bond clean price (optional)
        repo_rate: Term repo rate to delivery (optional)
        value_date: Current date (optional, for carry calc)
        delivery_date: Futures delivery date (optional)
        ctd_maturity_date: CTD bond maturity date (optional)

    Returns:
        AdjustedInvoiceSpreadResult with raw, carry-adjusted, and fully adjusted spreads
    """
    # Estimate delivery option value
    days_to_delivery = int(delivery_years * 365)
    option_value = estimate_delivery_option_value(
        contract=contract_type,
        days_to_delivery=days_to_delivery,
        yield_vol_bp=yield_vol_bp,
        include_delivery_options=include_delivery_options,
    )
    option_ticks = option_value.total_ticks

    # Raw implied yield (simple calculation)
    raw_analytics = analyze_futures(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
    )
    raw_implied_yield = raw_analytics.implied_yield

    # Forward swap rate
    forward_swap_rate = curve.swap_rate(
        start=delivery_years,
        end=maturity_years,
        freq=swap_freq,
    )

    # ----- CARRY ADJUSTMENT -----
    # If spot price and repo rate provided, compute carry-adjusted yield
    carry_adjustment_bp = 0.0
    carry_adjusted_yield = raw_implied_yield

    if all([spot_clean_price, repo_rate, value_date, delivery_date, ctd_maturity_date]):
        # Build TreasuryBond for carry calculation
        bond = TreasuryBond(
            coupon=coupon,
            maturity_date=ctd_maturity_date,
        )

        # Calculate carry
        carry = calculate_carry(
            bond=bond,
            spot_clean_price=spot_clean_price,
            settle_date=value_date,
            delivery_date=delivery_date,
            repo_rate=repo_rate,
        )

        # Theoretical futures price (no-arbitrage forward)
        # Forward Clean = Spot Dirty + Financing - Coupon - Accrued@Delivery
        theoretical_futures = carry.forward_clean_price / conversion_factor

        # Carry-adjusted yield uses theoretical futures
        carry_adjusted_price = theoretical_futures * conversion_factor
        bond_simple = Bond(coupon=coupon, maturity_years=maturity_years)
        carry_adjusted_yield = bond_yield(bond_simple, carry_adjusted_price)

        carry_adjustment_bp = (carry_adjusted_yield - raw_implied_yield) * 10000

    # ----- OPTION ADJUSTMENT -----
    # Apply option adjustment on top of carry-adjusted yield
    if option_ticks > 0:
        # Option-adjusted futures = carry-adjusted theoretical + option value
        option_price_adjustment = option_ticks / 32.0

        # If we have carry adjustment, apply options to theoretical futures
        if carry_adjustment_bp != 0:
            theoretical_futures = carry.forward_clean_price / conversion_factor
            adjusted_futures = theoretical_futures + option_price_adjustment
        else:
            # No carry data, apply options to market futures
            adjusted_futures = futures_price + option_price_adjustment

        adjusted_implied_price = adjusted_futures * conversion_factor
        bond_simple = Bond(coupon=coupon, maturity_years=maturity_years)
        adjusted_implied_yield = bond_yield(bond_simple, adjusted_implied_price)
    else:
        # No option adjustment
        adjusted_implied_yield = carry_adjusted_yield

    option_adjustment_bp = (adjusted_implied_yield - carry_adjusted_yield) * 10000

    # Invoice spreads at each level
    raw_spread_bp = (raw_implied_yield - forward_swap_rate) * 10000
    carry_adjusted_spread_bp = (carry_adjusted_yield - forward_swap_rate) * 10000
    adjusted_spread_bp = (adjusted_implied_yield - forward_swap_rate) * 10000

    return AdjustedInvoiceSpreadResult(
        raw_spread_bp=raw_spread_bp,
        raw_implied_yield=raw_implied_yield,
        carry_adjusted_spread_bp=carry_adjusted_spread_bp,
        carry_adjusted_yield=carry_adjusted_yield,
        adjusted_spread_bp=adjusted_spread_bp,
        adjusted_implied_yield=adjusted_implied_yield,
        forward_swap_rate=forward_swap_rate,
        delivery_tenor=delivery_years,
        maturity_tenor=maturity_years,
        futures_dv01=raw_analytics.futures_dv01,
        carry_adjustment_bp=carry_adjustment_bp,
        option_adjustment_ticks=option_ticks,
        option_adjustment_bp=option_adjustment_bp,
    )


def reverse_invoice_spread_adjusted(
    invoice_spread_bp: float,
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
    contract_type: FuturesContract | str = FuturesContract.TY,
    yield_vol_bp: float = 100.0,
) -> float:
    """
    Reverse calculate swap rate from adjusted invoice spread.

    Given a TARGET adjusted invoice spread, calculate what swap rate
    you need to execute.

    Args:
        invoice_spread_bp: Target invoice spread (adjusted) in bp
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD bond annual coupon (decimal)
        maturity_years: CTD time to maturity
        delivery_years: Time to futures delivery
        contract_type: Contract type for option estimation
        yield_vol_bp: Yield volatility for option estimation

    Returns:
        Required forward swap fixed rate (decimal)
    """
    # Get option-adjusted implied yield
    days_to_delivery = int(delivery_years * 365)
    option_value = estimate_delivery_option_value(
        contract=contract_type,
        days_to_delivery=days_to_delivery,
        yield_vol_bp=yield_vol_bp,
    )

    adjusted_yield = compute_adjusted_implied_yield(
        futures_price=futures_price,
        conversion_factor=conversion_factor,
        coupon=coupon,
        maturity_years=maturity_years,
        delivery_option_ticks=option_value.total_ticks,
    )

    # Swap rate = Adjusted yield - spread
    spread_decimal = invoice_spread_bp / 10000
    return adjusted_yield - spread_decimal
