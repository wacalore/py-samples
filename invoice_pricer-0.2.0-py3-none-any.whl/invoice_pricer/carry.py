"""
Carry and basis calculations for treasury futures.

WHAT IS CARRY?
==============
Carry is the profit/loss from holding a bond and financing it in the repo market
until futures delivery. It has two components:

1. INCOME: Coupon payments received while holding the bond
2. COST: Interest paid to finance the bond position (repo rate)

Net Carry = Coupon Income - Financing Cost

If carry > 0: "positive carry" - you earn money holding the bond
If carry < 0: "negative carry" - it costs money to hold the bond

WHY IT MATTERS FOR FUTURES
==========================
The theoretical futures price should reflect the forward price of the bond:

    Futures × CF = Spot Price × (1 + repo × t) - FV(Coupons)

Or equivalently:
    Futures × CF = Spot Price - Net Carry

The difference between actual futures price and this theoretical price is the "basis":
    Basis = Spot Price - Futures × CF - Carry

In practice, basis exists due to:
- Delivery option value (short's optionality)
- Liquidity differences
- Supply/demand imbalances

REPO RATES
==========
The repo rate is the financing rate for borrowing against treasury collateral.
- General Collateral (GC) rate: Generic treasury financing
- Special repo rate: When specific bonds are in high demand (trades below GC)
- Term repo: Locked-in rate to a specific date

For futures basis trading:
- Use term repo to delivery date when available
- Otherwise use GC rate as approximation
"""

from dataclasses import dataclass
from datetime import date

from .bonds import TreasuryBond, accrued_interest, dirty_price


@dataclass
class CarryComponents:
    """
    Breakdown of carry calculation.

    All values are per 100 face value of the bond.
    """
    # Inputs
    spot_clean_price: float
    spot_accrued: float
    repo_rate: float
    days_to_delivery: int

    # Calculated
    financing_cost: float      # Interest paid to hold position
    coupon_income: float       # Coupons received (if any)
    reinvestment_income: float # Interest earned on coupon (if received)
    accrued_at_delivery: float # Accrued interest at delivery

    @property
    def spot_dirty_price(self) -> float:
        """Full price paid to acquire the bond."""
        return self.spot_clean_price + self.spot_accrued

    @property
    def net_carry(self) -> float:
        """
        Net carry = Income - Cost

        Positive = profitable to hold
        Negative = costly to hold
        """
        return self.coupon_income + self.reinvestment_income - self.financing_cost

    @property
    def forward_dirty_price(self) -> float:
        """
        Theoretical forward dirty price at delivery.

        Forward = Spot Dirty × (1 + repo × t) - Coupon × (1 + repo × t_remaining)
        """
        return self.spot_dirty_price + self.financing_cost - self.coupon_income - self.reinvestment_income

    @property
    def forward_clean_price(self) -> float:
        """Forward clean price = Forward dirty - Accrued at delivery."""
        return self.forward_dirty_price - self.accrued_at_delivery


def calculate_carry(
    bond: TreasuryBond,
    spot_clean_price: float,
    settle_date: date,
    delivery_date: date,
    repo_rate: float,
) -> CarryComponents:
    """
    Calculate carry for holding a bond to futures delivery.

    FORMULA DERIVATION:
    -------------------
    You buy the bond at settlement for: Spot Dirty = Clean + Accrued_settle
    You finance this amount at the repo rate until delivery.
    If a coupon is paid between settle and delivery, you receive it and can reinvest.
    At delivery, you deliver the bond and receive: Futures × CF + Accrued_delivery

    Financing Cost = Spot Dirty × repo × (days / 360)
    Coupon Income = coupon payment if paid during holding period
    Reinvestment = coupon × repo × (days from coupon to delivery / 360)

    Args:
        bond: Treasury bond specification
        spot_clean_price: Current clean price
        settle_date: Trade settlement date
        delivery_date: Futures delivery date
        repo_rate: Repo financing rate (annualized, Act/360)

    Returns:
        CarryComponents with full breakdown
    """
    # Calculate accrued interest at settlement and delivery
    spot_accrued = accrued_interest(bond, settle_date)
    delivery_accrued = accrued_interest(bond, delivery_date)
    spot_dirty = spot_clean_price + spot_accrued

    # Time to delivery (Act/360 for repo)
    days_to_delivery = (delivery_date - settle_date).days
    year_frac = days_to_delivery / 360.0

    # Financing cost: interest on full investment
    financing_cost = spot_dirty * repo_rate * year_frac

    # Check for coupon payment during holding period
    coupon_income = 0.0
    reinvestment_income = 0.0

    next_coupon = bond.next_coupon_date(settle_date)
    if settle_date < next_coupon <= delivery_date:
        # Coupon is paid during holding period
        coupon_income = bond.coupon_payment

        # Reinvest coupon from payment date to delivery
        days_to_reinvest = (delivery_date - next_coupon).days
        if days_to_reinvest > 0:
            reinvestment_income = coupon_income * repo_rate * (days_to_reinvest / 360.0)

    return CarryComponents(
        spot_clean_price=spot_clean_price,
        spot_accrued=spot_accrued,
        repo_rate=repo_rate,
        days_to_delivery=days_to_delivery,
        financing_cost=financing_cost,
        coupon_income=coupon_income,
        reinvestment_income=reinvestment_income,
        accrued_at_delivery=delivery_accrued,
    )


def theoretical_futures_price(
    bond: TreasuryBond,
    spot_clean_price: float,
    conversion_factor: float,
    settle_date: date,
    delivery_date: date,
    repo_rate: float,
) -> float:
    """
    Calculate theoretical (fair value) futures price.

    FORMULA:
    --------
    Futures × CF = Forward Clean Price

    Where Forward Clean = Spot Dirty × (1 + r × t) - Coupon FV - Accrued_delivery

    This is the no-arbitrage futures price. If actual futures trade away from this:
    - Futures < theoretical: basis is positive, delivery option has value
    - Futures > theoretical: negative basis, unusual (arbitrage opportunity)

    Args:
        bond: Treasury bond with dates
        spot_clean_price: Current clean price
        conversion_factor: CTD conversion factor
        settle_date: Current settlement date
        delivery_date: Futures delivery date
        repo_rate: Term repo rate to delivery

    Returns:
        Theoretical futures price
    """
    carry = calculate_carry(bond, spot_clean_price, settle_date, delivery_date, repo_rate)
    return carry.forward_clean_price / conversion_factor


def gross_basis(
    spot_clean_price: float,
    futures_price: float,
    conversion_factor: float,
) -> float:
    """
    Calculate gross basis.

    Gross Basis = Spot Clean - Futures × CF

    This is the raw price difference before accounting for carry.
    Typically positive because futures trade cheap to spot.

    Args:
        spot_clean_price: Current clean price
        futures_price: Futures price
        conversion_factor: CTD conversion factor

    Returns:
        Gross basis in price points (32nds can be computed as basis × 32)
    """
    return spot_clean_price - futures_price * conversion_factor


def net_basis(
    bond: TreasuryBond,
    spot_clean_price: float,
    futures_price: float,
    conversion_factor: float,
    settle_date: date,
    delivery_date: date,
    repo_rate: float,
) -> float:
    """
    Calculate net basis (basis net of carry).

    Net Basis = Gross Basis - Net Carry
              = Spot - Futures × CF - Carry
              = Spot - Forward Price (theoretical)

    INTERPRETATION:
    ---------------
    Net basis represents the value of the delivery option embedded in futures.
    The short has optionality:
    - WHEN to deliver (timing option within delivery month)
    - WHICH bond to deliver (quality option - CTD can switch)
    - WILD CARD: deliver after close at settlement price

    Net basis is typically positive (0-20 ticks for 10Y) reflecting this optionality.

    If net basis < 0: Futures are expensive, potential sell futures/buy basis trade
    If net basis > 0: Normal - reflects delivery option value

    Args:
        bond: Treasury bond
        spot_clean_price: Current clean price
        futures_price: Futures price
        conversion_factor: CTD conversion factor
        settle_date: Current settlement date
        delivery_date: Futures delivery date
        repo_rate: Repo rate

    Returns:
        Net basis in price points
    """
    carry = calculate_carry(bond, spot_clean_price, settle_date, delivery_date, repo_rate)
    gross = gross_basis(spot_clean_price, futures_price, conversion_factor)
    return gross - carry.net_carry


def implied_repo_rate(
    bond: TreasuryBond,
    spot_clean_price: float,
    futures_price: float,
    conversion_factor: float,
    settle_date: date,
    delivery_date: date,
) -> float:
    """
    Calculate implied repo rate from spot and futures prices.

    The implied repo is the financing rate at which carry exactly explains
    the basis. It's the breakeven repo rate for a cash-and-carry arbitrage.

    FORMULA:
    --------
    Futures × CF + Accrued_delivery = Spot Dirty × (1 + r × t) - Coupon × (1 + r × t')

    Solving for r gives the implied repo rate.

    INTERPRETATION:
    ---------------
    - If implied repo > market repo: Futures are cheap, buy basis (buy bond, sell futures)
    - If implied repo < market repo: Futures are rich, sell basis (sell bond, buy futures)

    In practice, implied repo is typically below market GC rate due to delivery option.

    Args:
        bond: Treasury bond
        spot_clean_price: Current clean price
        futures_price: Futures price
        conversion_factor: Conversion factor
        settle_date: Settlement date
        delivery_date: Delivery date

    Returns:
        Implied repo rate (annualized, Act/360)
    """
    spot_accrued = accrued_interest(bond, settle_date)
    delivery_accrued = accrued_interest(bond, delivery_date)
    spot_dirty = spot_clean_price + spot_accrued

    invoice_price = futures_price * conversion_factor + delivery_accrued

    days = (delivery_date - settle_date).days
    if days <= 0:
        return 0.0

    # Check for interim coupon
    next_coupon = bond.next_coupon_date(settle_date)
    has_coupon = settle_date < next_coupon <= delivery_date

    if has_coupon:
        # With interim coupon, need to solve iteratively
        # Approximate: ignore reinvestment for simplicity
        cpn = bond.coupon_payment
        implied = ((invoice_price + cpn - spot_dirty) / spot_dirty) * (360 / days)
    else:
        # Simple case: no interim coupon
        implied = ((invoice_price - spot_dirty) / spot_dirty) * (360 / days)

    return implied
