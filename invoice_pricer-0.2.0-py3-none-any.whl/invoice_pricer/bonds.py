"""Bond mathematics: pricing, yield, duration, DV01."""

from dataclasses import dataclass
from datetime import date
from dateutil.relativedelta import relativedelta
from typing import Sequence

import numpy as np
from scipy.optimize import brentq


@dataclass
class Bond:
    """
    Treasury bond specification.

    Attributes:
        coupon: Annual coupon rate (e.g., 0.045 for 4.5%)
        maturity_years: Time to maturity in years
        face: Face value (default 100)
    """
    coupon: float
    maturity_years: float
    face: float = 100.0

    @property
    def coupon_payment(self) -> float:
        """Semi-annual coupon payment."""
        return self.face * self.coupon / 2


@dataclass
class TreasuryBond:
    """
    Full treasury bond specification with dates for accrued interest.

    Attributes:
        coupon: Annual coupon rate (decimal, e.g., 0.04125 for 4.125%)
        maturity_date: Bond maturity date
        issue_date: Original issue date (for coupon schedule)
        face: Face value (default 100)
    """
    coupon: float
    maturity_date: date
    issue_date: date | None = None
    face: float = 100.0

    @property
    def coupon_payment(self) -> float:
        """Semi-annual coupon payment per 100 face."""
        return self.face * self.coupon / 2

    def coupon_dates(self, from_date: date) -> list[date]:
        """
        Generate coupon payment dates from a given date to maturity.

        Treasury bonds pay semi-annually on the anniversary of maturity.
        """
        dates = []
        # Coupon months are 6 months apart, aligned to maturity
        cpn_month1 = self.maturity_date.month
        cpn_month2 = (cpn_month1 - 6) % 12 or 12
        cpn_day = min(self.maturity_date.day, 28)  # Handle month-end

        # Find next coupon date after from_date
        year = from_date.year
        for month in sorted([cpn_month1, cpn_month2]):
            try:
                cpn_date = date(year, month, cpn_day)
            except ValueError:
                cpn_date = date(year, month, 28)
            if cpn_date > from_date:
                break
        else:
            year += 1
            month = min(cpn_month1, cpn_month2)
            cpn_date = date(year, month, cpn_day)

        # Generate all future coupon dates
        while cpn_date <= self.maturity_date:
            dates.append(cpn_date)
            cpn_date = cpn_date + relativedelta(months=6)

        return dates

    def prev_coupon_date(self, settle_date: date) -> date:
        """Find the most recent coupon date before settlement."""
        cpn_month1 = self.maturity_date.month
        cpn_month2 = (cpn_month1 - 6) % 12 or 12
        cpn_day = min(self.maturity_date.day, 28)

        # Search backwards from settlement
        year = settle_date.year
        candidates = []
        for y in [year, year - 1]:
            for m in [cpn_month1, cpn_month2]:
                try:
                    d = date(y, m, cpn_day)
                except ValueError:
                    d = date(y, m, 28)
                if d < settle_date:
                    candidates.append(d)

        return max(candidates) if candidates else settle_date - relativedelta(months=6)

    def next_coupon_date(self, settle_date: date) -> date:
        """Find the next coupon date on or after settlement."""
        cpn_month1 = self.maturity_date.month
        cpn_month2 = (cpn_month1 - 6) % 12 or 12
        cpn_day = min(self.maturity_date.day, 28)

        year = settle_date.year
        candidates = []
        for y in [year, year + 1]:
            for m in [cpn_month1, cpn_month2]:
                try:
                    d = date(y, m, cpn_day)
                except ValueError:
                    d = date(y, m, 28)
                if d >= settle_date:
                    candidates.append(d)

        return min(candidates)


def accrued_interest(
    bond: TreasuryBond,
    settle_date: date,
) -> float:
    """
    Calculate accrued interest for a treasury bond.

    Uses Actual/Actual day count convention per treasury market standard:
    Accrued = (Days since last coupon / Days in coupon period) × Semi-annual coupon

    WHY THIS MATTERS:
    - When you buy a bond, you pay Clean Price + Accrued Interest = Dirty Price
    - The seller earned interest from last coupon to settlement
    - You compensate them for that accrued interest
    - At delivery of a futures contract, you pay: Futures × CF + Accrued

    Args:
        bond: Treasury bond specification
        settle_date: Settlement date

    Returns:
        Accrued interest per 100 face value
    """
    prev_cpn = bond.prev_coupon_date(settle_date)
    next_cpn = bond.next_coupon_date(settle_date)

    days_accrued = (settle_date - prev_cpn).days
    days_in_period = (next_cpn - prev_cpn).days

    if days_in_period <= 0:
        return 0.0

    accrual_fraction = days_accrued / days_in_period
    return accrual_fraction * bond.coupon_payment


def dirty_price(clean_price: float, accrued: float) -> float:
    """
    Calculate dirty (full) price from clean price.

    Dirty Price = Clean Price + Accrued Interest

    WHY THIS MATTERS:
    - Clean price is quoted in the market (excludes accrued)
    - Dirty price is what you actually pay
    - Yield calculations should use dirty price and actual cash flows
    """
    return clean_price + accrued


def clean_price_from_dirty(dirty: float, accrued: float) -> float:
    """Calculate clean price from dirty price."""
    return dirty - accrued


def bond_price(bond: Bond, ytm: float) -> float:
    """
    Calculate bond price from yield to maturity.

    Uses closed-form annuity formula for performance.

    Args:
        bond: Bond specification
        ytm: Yield to maturity (annualized, semi-annual compounding)

    Returns:
        Clean price per 100 face value
    """
    c = bond.coupon_payment
    n = int(bond.maturity_years * 2 + 0.5)  # Round to nearest period
    y = ytm * 0.5  # Semi-annual yield

    if abs(y) < 1e-10:
        return c * n + bond.face

    # Closed-form: PV = c * (1 - v^n) / y + F * v^n, where v = 1/(1+y)
    v_n = (1.0 + y) ** (-n)
    return c * (1.0 - v_n) / y + bond.face * v_n


def bond_yield(bond: Bond, price: float, guess: float = 0.05) -> float:
    """
    Calculate yield to maturity from price using Newton-Raphson.

    Optimized for speed with analytical derivative.

    Args:
        bond: Bond specification
        price: Clean price
        guess: Initial yield guess (default 5%)

    Returns:
        Yield to maturity (annualized)
    """
    c = bond.coupon_payment
    n = int(bond.maturity_years * 2 + 0.5)
    F = bond.face

    # Newton-Raphson with analytical derivative
    y = guess * 0.5  # Semi-annual
    for _ in range(50):  # Max iterations
        v = 1.0 / (1.0 + y)
        v_n = v ** n

        # Price function: P = c * (1 - v^n) / y + F * v^n
        if abs(y) < 1e-12:
            P = c * n + F
            dP = -c * n * (n + 1) * 0.5 - F * n
        else:
            P = c * (1.0 - v_n) / y + F * v_n
            # Derivative: dP/dy
            dP = -c * (1.0 - v_n) / (y * y) + (c / y + F) * n * v_n * v

        err = P - price
        if abs(err) < 1e-10:
            return y * 2.0  # Convert back to annual

        # Newton step with damping for stability
        dy = err / dP if abs(dP) > 1e-12 else 0.001
        dy = max(-0.02, min(0.02, dy))  # Limit step size
        y -= dy

        # Bound check
        y = max(-0.05, min(0.25, y))

    # Fallback to Brent if Newton fails
    return brentq(lambda yy: bond_price(bond, yy) - price, -0.10, 0.50)


def modified_duration(bond: Bond, ytm: float) -> float:
    """
    Calculate modified duration using closed-form formula.

    Args:
        bond: Bond specification
        ytm: Yield to maturity

    Returns:
        Modified duration in years
    """
    c = bond.coupon_payment
    n = int(bond.maturity_years * 2 + 0.5)
    y = ytm * 0.5
    C = bond.coupon  # Annual coupon rate
    F = bond.face

    if abs(y) < 1e-10:
        # Zero yield approximation
        return bond.maturity_years * 0.5

    v = 1.0 / (1.0 + y)
    v_n = v ** n
    price = bond_price(bond, ytm)

    if price <= 0:
        return 0.0

    # Closed-form Macaulay duration for semi-annual bond:
    # Mac = (1+y)/y - (1+y + n*(C/2 - y)) / (C*(1+y)^n - C + 2*y)
    # Simplified for semi-annual
    numerator = (1.0 + y) - (1.0 + y + n * (C * 0.5 - y)) * v_n
    denominator = C * (1.0 - v_n) + 2.0 * y * v_n

    if abs(denominator) < 1e-12:
        return bond.maturity_years * 0.5

    mac_dur = (1.0 + y) / y - numerator / denominator
    mac_dur *= 0.5  # Convert to years

    # Modified duration = Macaulay / (1 + y)
    return mac_dur / (1.0 + y)


def dv01(bond: Bond, ytm: float) -> float:
    """
    Calculate DV01 (dollar value of 1 basis point).

    DV01 = Modified Duration × Price × 0.0001

    Args:
        bond: Bond specification
        ytm: Yield to maturity

    Returns:
        DV01 per 100 face value
    """
    price = bond_price(bond, ytm)
    mod_dur = modified_duration(bond, ytm)
    return mod_dur * price * 0.0001


def convexity(bond: Bond, ytm: float) -> float:
    """
    Calculate convexity.

    Args:
        bond: Bond specification
        ytm: Yield to maturity

    Returns:
        Convexity measure
    """
    c = bond.coupon_payment
    n = int(np.ceil(bond.maturity_years * 2))
    y = ytm / 2
    price = bond_price(bond, ytm)

    if price <= 0:
        return 0.0

    conv = 0.0
    for i in range(1, n + 1):
        t = i / 2
        cf = c if i < n else c + bond.face
        pv = cf * (1 + y) ** -i
        conv += t * (t + 0.5) * pv

    conv /= (price * (1 + y) ** 2)
    return conv
