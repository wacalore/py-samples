"""
Clean, simple API for invoice spread pricing.

This module provides a streamlined interface for common operations.
For advanced usage, import from submodules directly.

Curve Construction:
    Uses smoothing spline interpolation on swap rates with exact recovery
    at input tenors (λ=1e-10 by default).

Example:
    >>> from invoice_pricer import price_invoice_spread, build_curve
    >>> curve = build_curve([1,2,5,10,30], [0.043,0.041,0.042,0.045,0.046])
    >>> curve.swap_rate(0, 10)  # Exactly 0.045 (matches input)
    >>> result = price_invoice_spread(
    ...     futures_price=110.25,
    ...     conversion_factor=0.8456,
    ...     coupon=0.04125,
    ...     maturity_years=9.5,
    ...     delivery_years=0.12,
    ...     curve=curve,
    ... )
    >>> print(f"Spread: {result.spread_bp:.2f} bp")
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Sequence

from .curves import SwapCurve, bootstrap_swap_curve
from .bonds import Bond, bond_price, bond_yield, dv01, modified_duration
from .futures import analyze_futures
from .delivery_option import estimate_delivery_option_value, FuturesContract
from .carry import calculate_carry
from .bonds import TreasuryBond
from .swaps import price_swap, swap_dv01, SwapValuation


@dataclass(frozen=True, slots=True)
class InvoiceSpread:
    """
    Result of invoice spread calculation.

    Attributes:
        spread_bp: Invoice spread in basis points (primary result)
        implied_yield: Futures-implied bond yield
        swap_rate: Forward swap rate
        futures_dv01: DV01 per $100k futures notional

        # With adjustments (if enabled)
        adjusted_spread_bp: Spread with carry/option adjustments
        carry_bp: Carry adjustment in bp (0 if no spot/repo provided)
        option_bp: Option adjustment in bp (0 if disabled)
    """
    spread_bp: float
    implied_yield: float
    swap_rate: float
    futures_dv01: float

    adjusted_spread_bp: float = 0.0
    carry_bp: float = 0.0
    option_bp: float = 0.0

    def __repr__(self) -> str:
        return f"InvoiceSpread(spread={self.spread_bp:+.2f}bp, adj={self.adjusted_spread_bp:+.2f}bp)"


def build_curve(
    tenors: Sequence[float],
    rates: Sequence[float],
    value_date: date | None = None,
    method: str = "smoothing",
    lam: float | None = 1e-10,
) -> SwapCurve:
    """
    Build a SOFR swap curve from par rates.

    Uses the swap rate spline approach which guarantees exact recovery
    of input swap rates at the reference tenors.

    Args:
        tenors: Swap tenors in years (e.g., [1, 2, 5, 10, 30])
        rates: Par swap rates as decimals (e.g., [0.043, 0.041, ...])
        value_date: Curve date (default: today)
        method: Interpolation method for swap rate curve:
            - 'smoothing': Smoothing spline (RECOMMENDED - exact with λ=1e-10)
            - 'cubic': Natural cubic spline (exact at knots)
            - 'pchip': Monotone cubic (shape-preserving, no overshoots)
        lam: Lambda for smoothing spline. Default 1e-10 = exact fit.
             Larger values = more smoothing. None = auto (GCV).

    Returns:
        SwapCurve object for use in spread calculations

    Example:
        >>> curve = build_curve([1,2,5,10,30], [0.043,0.041,0.042,0.045,0.046])
        >>> curve.swap_rate(0, 10)  # 10Y spot swap rate (exact at input)
    """
    if value_date is None:
        value_date = date.today()
    return bootstrap_swap_curve(value_date, list(tenors), list(rates), method=method, lam=lam)


def price_invoice_spread(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
    curve: SwapCurve,
    *,
    # Optional adjustments
    contract: str = "TY",
    include_options: bool = True,
    yield_vol_bp: float = 100.0,
    spot_price: float | None = None,
    repo_rate: float | None = None,
    value_date: date | None = None,
    delivery_date: date | None = None,
    maturity_date: date | None = None,
) -> InvoiceSpread:
    """
    Calculate invoice spread between treasury futures and forward swap.

    Args:
        futures_price: Treasury futures price (e.g., 110.25)
        conversion_factor: CTD conversion factor
        coupon: CTD annual coupon as decimal (e.g., 0.04125 for 4.125%)
        maturity_years: CTD years to maturity
        delivery_years: Years to futures delivery
        curve: SOFR swap curve

        # Optional adjustments
        contract: Contract type for option sizing ("TU","FV","TY","US","WN")
        include_options: Include delivery option adjustment (default True)
        yield_vol_bp: Yield volatility for option calc (default 100)
        spot_price: CTD spot clean price (for carry adjustment)
        repo_rate: Term repo rate (for carry adjustment)
        value_date: Current date (for carry adjustment)
        delivery_date: Delivery date (for carry adjustment)
        maturity_date: CTD maturity date (for carry adjustment)

    Returns:
        InvoiceSpread with spread_bp and adjusted_spread_bp

    Example:
        >>> result = price_invoice_spread(
        ...     futures_price=110.25,
        ...     conversion_factor=0.8456,
        ...     coupon=0.04125,
        ...     maturity_years=9.5,
        ...     delivery_years=0.12,
        ...     curve=curve,
        ... )
        >>> print(f"Spread: {result.spread_bp:.2f} bp")
    """
    # Raw calculation
    analytics = analyze_futures(futures_price, conversion_factor, coupon, maturity_years)
    raw_yield = analytics.implied_yield

    swap_rate = curve.swap_rate(delivery_years, maturity_years)
    raw_spread = (raw_yield - swap_rate) * 10000

    # Carry adjustment
    carry_bp = 0.0
    carry_yield = raw_yield

    if all([spot_price, repo_rate, value_date, delivery_date, maturity_date]):
        bond = TreasuryBond(coupon=coupon, maturity_date=maturity_date)
        carry = calculate_carry(bond, spot_price, value_date, delivery_date, repo_rate)
        theoretical_futures = carry.forward_clean_price / conversion_factor
        carry_price = theoretical_futures * conversion_factor
        carry_yield = bond_yield(Bond(coupon, maturity_years), carry_price)
        carry_bp = (carry_yield - raw_yield) * 10000

    # Option adjustment
    option_bp = 0.0
    adj_yield = carry_yield

    if include_options:
        contract_enum = getattr(FuturesContract, contract.upper(), FuturesContract.TY)
        days = int(delivery_years * 365)
        opt = estimate_delivery_option_value(contract_enum, days, yield_vol_bp)

        if opt.total_ticks > 0:
            opt_price_adj = opt.total_ticks / 32.0
            if carry_bp != 0:
                adj_futures = theoretical_futures + opt_price_adj
            else:
                adj_futures = futures_price + opt_price_adj
            adj_price = adj_futures * conversion_factor
            adj_yield = bond_yield(Bond(coupon, maturity_years), adj_price)
            option_bp = (adj_yield - carry_yield) * 10000

    adj_spread = (adj_yield - swap_rate) * 10000

    return InvoiceSpread(
        spread_bp=raw_spread,
        implied_yield=raw_yield,
        swap_rate=swap_rate,
        futures_dv01=analytics.futures_dv01,
        adjusted_spread_bp=adj_spread,
        carry_bp=carry_bp,
        option_bp=option_bp,
    )


def implied_yield(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
) -> float:
    """
    Calculate implied bond yield from futures price.

    Simple formula: Implied Price = Futures × CF, then solve for yield.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: Annual coupon (decimal)
        maturity_years: Years to maturity

    Returns:
        Implied yield to maturity (decimal)

    Example:
        >>> y = implied_yield(110.25, 0.8456, 0.04125, 9.5)
        >>> print(f"{y*100:.4f}%")
    """
    price = futures_price * conversion_factor
    return bond_yield(Bond(coupon, maturity_years), price)


def futures_dv01(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
) -> float:
    """
    Calculate DV01 of treasury futures contract.

    Returns dollar value change per 1bp yield move per $100k notional.

    Args:
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: Annual coupon (decimal)
        maturity_years: Years to maturity

    Returns:
        DV01 in dollars per contract per basis point

    Example:
        >>> dv = futures_dv01(110.25, 0.8456, 0.04125, 9.5)
        >>> print(f"${dv:.2f} per bp")
    """
    return analyze_futures(futures_price, conversion_factor, coupon, maturity_years).futures_dv01


def forward_swap_rate(
    curve: SwapCurve,
    start_years: float,
    end_years: float,
) -> float:
    """
    Get forward swap rate from curve.

    Args:
        curve: SOFR swap curve
        start_years: Forward start in years
        end_years: Swap maturity in years

    Returns:
        Forward par swap rate (decimal)

    Example:
        >>> rate = forward_swap_rate(curve, 0.12, 9.5)
        >>> print(f"{rate*100:.4f}%")
    """
    return curve.swap_rate(start_years, end_years)
