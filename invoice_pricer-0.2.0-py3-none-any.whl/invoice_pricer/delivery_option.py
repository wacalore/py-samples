"""
Delivery option valuation for treasury futures.

WHAT ARE DELIVERY OPTIONS?
==========================
Treasury futures give the SHORT several valuable options:

1. QUALITY OPTION (aka Switching Option)
   - The short can deliver ANY bond from the deliverable basket
   - They will choose the cheapest-to-deliver (CTD)
   - If yields change, a different bond may become CTD
   - Value increases with: yield volatility, basket heterogeneity, time to delivery

2. TIMING OPTION
   - The short can deliver on ANY business day in the delivery month
   - Optimal strategy depends on carry: deliver early if negative carry, late if positive
   - Value is typically small (few ticks)

3. WILD CARD OPTION
   - Futures settle at 2:00 PM, but delivery notice can be given until 8:00 PM
   - If bond prices fall after 2pm, short can give notice at the stale 2pm price
   - Creates a daily 6-hour put option
   - Value: roughly 0.5-2 ticks for 10Y, more for longer duration

4. END-OF-MONTH OPTION
   - Futures stop trading ~7 business days before month end
   - But delivery continues through month end at the final settlement price
   - Another timing option layer

WHY THIS MATTERS
================
These options have VALUE to the short position. Therefore:
- Futures trade CHEAPER than theoretical (spot - carry) / CF
- Net basis is typically POSITIVE (reflects option value)
- The difference is called the "delivery option value" or "basis value"

For invoice spread pricing:
- Using raw futures price understates the "true" bond equivalent yield
- We can adjust by adding estimated option value to futures price
- Or work with the implied yield directly and acknowledge the basis

ESTIMATION APPROACHES
=====================
1. HISTORICAL: Average net basis for similar contracts
2. MODEL-BASED: Monte Carlo simulation of yield paths and CTD switches
3. MARKET-IMPLIED: Calibrate to options on futures
4. RULE OF THUMB: Use typical values (e.g., 4-8 ticks for 10Y)

This module provides simple estimation methods suitable for production use.
"""

from dataclasses import dataclass
from datetime import date
from enum import Enum

import numpy as np


class FuturesContract(Enum):
    """Treasury futures contract types."""
    TU = "2Y"   # 2-Year Note
    FV = "5Y"   # 5-Year Note
    TY = "10Y"  # 10-Year Note
    TN = "10Y Ultra"  # Ultra 10-Year
    US = "30Y"  # Treasury Bond (30Y)
    WN = "Ultra Bond"  # Ultra Bond


@dataclass
class DeliveryOptionValue:
    """
    Estimated delivery option values.

    All values in 32nds of a point (ticks).
    """
    quality_option: float    # CTD switching value
    timing_option: float     # Early/late delivery value
    wild_card_option: float  # End-of-day optionality
    end_of_month_option: float  # Post-trading delivery value

    @property
    def total_ticks(self) -> float:
        """Total option value in ticks (32nds)."""
        return (
            self.quality_option +
            self.timing_option +
            self.wild_card_option +
            self.end_of_month_option
        )

    @property
    def total_price(self) -> float:
        """Total option value in price points (divide by 32)."""
        return self.total_ticks / 32.0

    @property
    def total_yield_bp(self) -> float:
        """
        Approximate yield impact in basis points.

        Rule of thumb: 1 tick ≈ 0.3-0.5 bp for 10Y duration
        This is a rough approximation; actual impact depends on DV01.
        """
        # Assume ~8 year duration, DV01 ≈ $80/bp per $100k
        # 1 tick = 1/32 = $31.25 per $100k
        # Yield impact ≈ 31.25 / 80 ≈ 0.4 bp per tick
        return self.total_ticks * 0.4


def estimate_delivery_option_value(
    contract: FuturesContract | str,
    days_to_delivery: int,
    yield_vol_bp: float = 100.0,
    is_front_month: bool = True,
    include_delivery_options: bool = True,
) -> DeliveryOptionValue:
    """
    Estimate delivery option values using empirical/analytical approximations.

    This combines:
    - Historical average net basis by contract type
    - Adjustments for time to delivery
    - Adjustments for yield volatility

    Args:
        contract: Futures contract type (TU, FV, TY, US, etc.)
        days_to_delivery: Days until first delivery date
        yield_vol_bp: Annualized yield volatility in basis points (default 100bp)
        is_front_month: Whether this is the front month contract
        include_delivery_options: If False, returns zero for all options.
            Use this to disable option adjustments entirely.

    Returns:
        DeliveryOptionValue with component estimates
    """
    # If disabled, return zeros
    if not include_delivery_options:
        return DeliveryOptionValue(
            quality_option=0.0,
            timing_option=0.0,
            wild_card_option=0.0,
            end_of_month_option=0.0,
        )

    if isinstance(contract, str):
        contract = FuturesContract[contract.upper()]

    # Base values by contract (historical averages in ticks)
    # These reflect typical net basis levels
    base_values = {
        FuturesContract.TU: {"quality": 1.0, "timing": 0.5, "wildcard": 0.5, "eom": 0.5},
        FuturesContract.FV: {"quality": 2.0, "timing": 0.5, "wildcard": 1.0, "eom": 0.5},
        FuturesContract.TY: {"quality": 4.0, "timing": 1.0, "wildcard": 1.5, "eom": 1.0},
        FuturesContract.TN: {"quality": 5.0, "timing": 1.0, "wildcard": 2.0, "eom": 1.0},
        FuturesContract.US: {"quality": 8.0, "timing": 1.5, "wildcard": 3.0, "eom": 1.5},
        FuturesContract.WN: {"quality": 10.0, "timing": 2.0, "wildcard": 4.0, "eom": 2.0},
    }

    base = base_values.get(contract, base_values[FuturesContract.TY])

    # Time decay: options worth less as delivery approaches
    # Use sqrt decay (like option theta)
    time_factor = np.sqrt(min(days_to_delivery, 90) / 90.0)

    # Volatility adjustment: higher vol = more option value
    # Normalize to 100bp base vol
    vol_factor = yield_vol_bp / 100.0

    # Back month contracts have more time value
    month_factor = 1.0 if is_front_month else 1.3

    # Quality option scales with vol and time
    quality = base["quality"] * vol_factor * time_factor * month_factor

    # Timing option is mostly time-dependent
    timing = base["timing"] * time_factor

    # Wild card is vol-dependent (it's a daily option)
    wildcard = base["wildcard"] * vol_factor * np.sqrt(time_factor)

    # End of month is small and time-dependent
    eom = base["eom"] * time_factor

    return DeliveryOptionValue(
        quality_option=quality,
        timing_option=timing,
        wild_card_option=wildcard,
        end_of_month_option=eom,
    )


def adjusted_futures_price(
    futures_price: float,
    option_value: DeliveryOptionValue,
) -> float:
    """
    Adjust futures price upward to account for delivery option value.

    Since futures trade cheap due to short's options, we add the option value
    to get an "option-adjusted" futures price closer to theoretical.

    Adjusted Futures = Market Futures + Option Value

    This adjusted price can then be used to compute a more accurate implied yield.

    Args:
        futures_price: Market futures price
        option_value: Estimated delivery option value

    Returns:
        Option-adjusted futures price
    """
    return futures_price + option_value.total_price


def net_basis_to_option_value(
    net_basis_ticks: float,
    contract: FuturesContract | str,
) -> DeliveryOptionValue:
    """
    Convert observed net basis to option value decomposition.

    If you observe net basis in the market, this function provides
    a reasonable decomposition into component options based on
    typical proportions.

    Args:
        net_basis_ticks: Observed net basis in ticks (32nds)
        contract: Contract type for proportion estimation

    Returns:
        DeliveryOptionValue with proportional breakdown
    """
    if isinstance(contract, str):
        contract = FuturesContract[contract.upper()]

    # Typical proportions of total option value
    proportions = {
        FuturesContract.TU: {"quality": 0.40, "timing": 0.20, "wildcard": 0.20, "eom": 0.20},
        FuturesContract.FV: {"quality": 0.50, "timing": 0.12, "wildcard": 0.25, "eom": 0.13},
        FuturesContract.TY: {"quality": 0.53, "timing": 0.13, "wildcard": 0.20, "eom": 0.14},
        FuturesContract.US: {"quality": 0.57, "timing": 0.11, "wildcard": 0.21, "eom": 0.11},
        FuturesContract.WN: {"quality": 0.56, "timing": 0.11, "wildcard": 0.22, "eom": 0.11},
    }

    props = proportions.get(contract, proportions[FuturesContract.TY])

    return DeliveryOptionValue(
        quality_option=net_basis_ticks * props["quality"],
        timing_option=net_basis_ticks * props["timing"],
        wild_card_option=net_basis_ticks * props["wildcard"],
        end_of_month_option=net_basis_ticks * props["eom"],
    )


@dataclass
class BasisAnalysis:
    """Complete basis analysis for a futures position."""
    gross_basis_ticks: float
    net_carry_ticks: float
    net_basis_ticks: float
    estimated_option_value: DeliveryOptionValue
    implied_repo_rate: float

    @property
    def basis_cheap_rich(self) -> str:
        """Assess if basis is cheap or rich vs estimated fair value."""
        diff = self.net_basis_ticks - self.estimated_option_value.total_ticks
        if diff > 2:
            return "CHEAP (basis wide to fair value)"
        elif diff < -2:
            return "RICH (basis tight to fair value)"
        else:
            return "FAIR"
