"""Interest rate swap pricing.

Price existing swaps using a discount curve. Supports both payer and receiver swaps.

Example:
    >>> from invoice_pricer import build_curve, price_swap
    >>> curve = build_curve([1,2,5,10,30], [0.043,0.041,0.042,0.045,0.046])
    >>> npv = price_swap(
    ...     fixed_rate=0.035,      # 3.5% fixed rate
    ...     remaining_years=7.5,   # 7.5 years remaining
    ...     notional=10_000_000,   # $10M notional
    ...     curve=curve,
    ...     payer=True,            # Paying fixed, receiving float
    ... )
    >>> print(f"Swap NPV: ${npv:,.0f}")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from .curves import SwapCurve


@dataclass(frozen=True, slots=True)
class SwapValuation:
    """
    Result of swap valuation.

    Attributes:
        npv: Net present value of the swap
        fixed_leg_pv: Present value of fixed leg (positive = pay)
        float_leg_pv: Present value of floating leg (positive = receive)
        dv01: Dollar value of 1bp parallel shift in curve
        fixed_rate: The swap's fixed rate
        par_rate: Current par swap rate for remaining tenor
        pnl_bp: P&L in basis points (par_rate - fixed_rate for payer)
    """
    npv: float
    fixed_leg_pv: float
    float_leg_pv: float
    dv01: float
    fixed_rate: float
    par_rate: float
    pnl_bp: float

    def __repr__(self) -> str:
        direction = "Payer" if self.npv > 0 and self.fixed_leg_pv > 0 else "Receiver"
        return f"SwapValuation(npv=${self.npv:,.0f}, dv01=${self.dv01:,.0f}, pnl={self.pnl_bp:+.1f}bp)"


def price_swap(
    fixed_rate: float,
    remaining_years: float,
    notional: float,
    curve: SwapCurve,
    *,
    payer: bool = True,
    freq: int = 2,
    start_years: float = 0.0,
) -> SwapValuation:
    """
    Price an existing interest rate swap.

    For a PAYER swap: pay fixed, receive floating (SOFR)
    For a RECEIVER swap: receive fixed, pay floating (SOFR)

    Args:
        fixed_rate: The swap's fixed rate (decimal, e.g., 0.035 for 3.5%)
        remaining_years: Years remaining until maturity
        notional: Swap notional amount
        curve: Current SOFR swap curve for discounting
        payer: True for payer swap (pay fixed), False for receiver
        freq: Payment frequency (default 2 = semi-annual)
        start_years: Forward start in years (default 0 = spot)

    Returns:
        SwapValuation with NPV and risk metrics

    Example:
        >>> # Price a $10M 7.5Y payer swap at 3.5% fixed
        >>> result = price_swap(
        ...     fixed_rate=0.035,
        ...     remaining_years=7.5,
        ...     notional=10_000_000,
        ...     curve=curve,
        ...     payer=True,
        ... )
        >>> print(f"NPV: ${result.npv:,.0f}")
        >>> print(f"DV01: ${result.dv01:,.0f}")
    """
    end_years = start_years + remaining_years

    # Fixed leg PV = fixed_rate × notional × annuity
    annuity = curve.annuity(start_years, end_years, freq)
    fixed_leg_pv = fixed_rate * notional * annuity

    # Floating leg PV: notional × (DF_start - DF_end)
    df_start = curve.df(start_years)
    df_end = curve.df(end_years)
    float_leg_pv = notional * (df_start - df_end)

    # NPV depends on direction
    if payer:
        npv = float_leg_pv - fixed_leg_pv
    else:
        npv = fixed_leg_pv - float_leg_pv

    # DV01: use annuity (more accurate than approximation)
    dv01 = notional * annuity * 0.0001

    # Par rate and P&L
    par_rate = (df_start - df_end) / annuity
    if payer:
        pnl_bp = (par_rate - fixed_rate) * 10000
    else:
        pnl_bp = (fixed_rate - par_rate) * 10000

    return SwapValuation(
        npv=npv,
        fixed_leg_pv=fixed_leg_pv,
        float_leg_pv=float_leg_pv,
        dv01=dv01,
        fixed_rate=fixed_rate,
        par_rate=par_rate,
        pnl_bp=pnl_bp,
    )


def price_swap_schedule(
    fixed_rate: float,
    payment_times: Sequence[float],
    notional: float,
    curve: SwapCurve,
    *,
    payer: bool = True,
) -> SwapValuation:
    """
    Price a swap with explicit payment schedule.

    Use this for swaps with irregular schedules or when you have
    exact payment dates converted to year fractions.

    Args:
        fixed_rate: The swap's fixed rate (decimal)
        payment_times: List of payment times in years from today
        notional: Swap notional amount
        curve: Current SOFR swap curve
        payer: True for payer swap (pay fixed)

    Returns:
        SwapValuation with NPV and risk metrics
    """
    if len(payment_times) == 0:
        raise ValueError("payment_times cannot be empty")

    payment_times = sorted(payment_times)
    end_years = payment_times[-1]

    # Fixed leg PV
    fixed_leg_pv = 0.0
    prev_t = 0.0
    for t in payment_times:
        accrual = t - prev_t
        fixed_leg_pv += fixed_rate * accrual * notional * curve.df(t)
        prev_t = t

    # Floating leg PV
    float_leg_pv = notional * (1.0 - curve.df(end_years))

    # NPV
    if payer:
        npv = float_leg_pv - fixed_leg_pv
    else:
        npv = fixed_leg_pv - float_leg_pv

    # Approximate DV01
    remaining_years = end_years
    avg_df = (1.0 + curve.df(end_years)) / 2
    dv01 = remaining_years * 0.0001 * notional * avg_df

    # Par rate
    par_rate = curve.swap_rate(0, end_years)
    if payer:
        pnl_bp = (par_rate - fixed_rate) * 10000
    else:
        pnl_bp = (fixed_rate - par_rate) * 10000

    return SwapValuation(
        npv=npv,
        fixed_leg_pv=fixed_leg_pv,
        float_leg_pv=float_leg_pv,
        dv01=dv01,
        fixed_rate=fixed_rate,
        par_rate=par_rate,
        pnl_bp=pnl_bp,
    )


def swap_dv01(
    remaining_years: float,
    notional: float,
    curve: SwapCurve,
    *,
    start_years: float = 0.0,
) -> float:
    """
    Calculate DV01 of a swap position.

    Returns the dollar value change for a 1bp parallel shift in rates.

    Args:
        remaining_years: Years remaining until maturity
        notional: Swap notional amount
        curve: Current SOFR swap curve
        start_years: Forward start in years (default 0)

    Returns:
        DV01 in dollars (absolute value)
    """
    end_years = start_years + remaining_years
    df_start = curve.df(start_years)
    df_end = curve.df(end_years)
    avg_df = (df_start + df_end) / 2
    return remaining_years * 0.0001 * notional * avg_df
