"""
Optional Numba acceleration for performance-critical functions.

This module provides JIT-compiled versions of hot functions when Numba is available.
Falls back gracefully to pure NumPy implementations if Numba is not installed.

Usage:
    from invoice_pricer.accel import newton_yield_solve, HAS_NUMBA

    if HAS_NUMBA:
        print("Using Numba-accelerated functions")
"""

import numpy as np

# Try to import Numba, provide fallback if not available
try:
    from numba import jit
    HAS_NUMBA = True
except ImportError:
    HAS_NUMBA = False
    # Dummy decorator that does nothing
    def jit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator


# =============================================================================
# NUMBA-ACCELERATED YIELD SOLVER
# =============================================================================

@jit(nopython=True, cache=True, fastmath=True)
def _newton_yield_core(cf_amounts: np.ndarray, cf_times: np.ndarray,
                       dirty_price: float, guess: float = 0.05) -> float:
    """
    Core Newton-Raphson yield solver - Numba compiled.

    Args:
        cf_amounts: Array of cash flow amounts
        cf_times: Array of times in semi-annual periods (days/180)
        dirty_price: Target dirty price
        guess: Initial yield guess

    Returns:
        Solved yield (annual), or NaN if failed
    """
    y = guess
    y_semi = y * 0.5

    for _ in range(30):
        v = 1.0 / (1.0 + y_semi)

        # Compute PV and derivative in single pass
        pv = 0.0
        dPV = 0.0

        for i in range(len(cf_amounts)):
            # v^t using manual power (Numba optimizes this well)
            t = cf_times[i]
            df = v ** t
            cf = cf_amounts[i]

            pv += cf * df
            dPV -= 0.5 * cf * t * df * v

        f = pv - dirty_price

        if abs(f) < 1e-10:
            return y

        if abs(dPV) < 1e-12:
            break

        # Newton step with damping
        dy = f / dPV
        if dy > 0.02:
            dy = 0.02
        elif dy < -0.02:
            dy = -0.02

        y = y - dy

        # Bound check
        if y < -0.10:
            y = -0.10
        elif y > 0.50:
            y = 0.50

        y_semi = y * 0.5

    # Return NaN to signal fallback needed
    return np.nan


@jit(nopython=True, cache=True, fastmath=True)
def _npv_at_yield(cf_amounts: np.ndarray, cf_times: np.ndarray, y: float) -> float:
    """Compute NPV at a given yield - Numba compiled."""
    v = 1.0 / (1.0 + y * 0.5)
    pv = 0.0
    for i in range(len(cf_amounts)):
        pv += cf_amounts[i] * (v ** cf_times[i])
    return pv


def newton_yield_solve(cf_amounts: np.ndarray, cf_times: np.ndarray,
                       dirty_price: float, guess: float = 0.05) -> float:
    """
    Solve for yield using Newton-Raphson with Numba acceleration.

    Falls back to scipy.brentq if Newton fails.

    Args:
        cf_amounts: Array of cash flow amounts
        cf_times: Array of times in semi-annual periods
        dirty_price: Target dirty price
        guess: Initial yield guess

    Returns:
        Solved yield (annual)
    """
    # Try Numba-accelerated Newton
    result = _newton_yield_core(cf_amounts, cf_times, dirty_price, guess)

    if not np.isnan(result):
        return result

    # Fallback to brentq (rare)
    from scipy.optimize import brentq

    def npv_func(y):
        if HAS_NUMBA:
            return _npv_at_yield(cf_amounts, cf_times, y) - dirty_price
        else:
            v = 1.0 / (1.0 + y / 2)
            return np.sum(cf_amounts * np.power(v, cf_times)) - dirty_price

    return brentq(npv_func, -0.20, 0.50)


# =============================================================================
# NUMBA-ACCELERATED BOND PRICE/YIELD
# =============================================================================

@jit(nopython=True, cache=True, fastmath=True)
def bond_price_fast(coupon: float, maturity_years: float, ytm: float,
                    face: float = 100.0) -> float:
    """
    Calculate bond price from yield - Numba compiled.

    Uses closed-form annuity formula.
    """
    c = face * coupon * 0.5  # Semi-annual coupon
    n = int(maturity_years * 2 + 0.5)
    y = ytm * 0.5

    if abs(y) < 1e-10:
        return c * n + face

    v_n = (1.0 + y) ** (-n)
    return c * (1.0 - v_n) / y + face * v_n


@jit(nopython=True, cache=True, fastmath=True)
def bond_yield_fast(coupon: float, maturity_years: float, price: float,
                    face: float = 100.0, guess: float = 0.05) -> float:
    """
    Calculate yield from price using Newton-Raphson - Numba compiled.
    """
    c = face * coupon * 0.5
    n = int(maturity_years * 2 + 0.5)

    y = guess * 0.5  # Semi-annual

    for _ in range(50):
        v = 1.0 / (1.0 + y)
        v_n = v ** n

        if abs(y) < 1e-12:
            P = c * n + face
            dP = -c * n * (n + 1) * 0.5 - face * n
        else:
            P = c * (1.0 - v_n) / y + face * v_n
            dP = -c * (1.0 - v_n) / (y * y) + (c / y + face) * n * v_n * v

        err = P - price

        if abs(err) < 1e-10:
            return y * 2.0

        if abs(dP) < 1e-12:
            break

        dy = err / dP
        if dy > 0.02:
            dy = 0.02
        elif dy < -0.02:
            dy = -0.02

        y = y - dy

        if y < -0.05:
            y = -0.05
        elif y > 0.25:
            y = 0.25

    return y * 2.0


# =============================================================================
# WARM-UP FUNCTION
# =============================================================================

def warmup():
    """
    Pre-compile Numba functions to avoid first-call latency.

    Call this at application startup if you want predictable timing.

    Example:
        from invoice_pricer.accel import warmup
        warmup()  # Takes ~500ms, then all calls are fast
    """
    if not HAS_NUMBA:
        return

    # Trigger compilation with dummy data
    cf_amounts = np.array([2.0, 2.0, 102.0])
    cf_times = np.array([1.0, 2.0, 3.0])

    _newton_yield_core(cf_amounts, cf_times, 100.0, 0.05)
    _npv_at_yield(cf_amounts, cf_times, 0.05)
    bond_price_fast(0.04, 10.0, 0.05)
    bond_yield_fast(0.04, 10.0, 100.0)


# Provide info about acceleration status
def get_accel_info() -> dict:
    """Get information about acceleration status."""
    return {
        "numba_available": HAS_NUMBA,
        "functions_accelerated": [
            "newton_yield_solve",
            "bond_price_fast",
            "bond_yield_fast",
        ] if HAS_NUMBA else [],
    }
