"""SOFR swap curve construction and interpolation.

Two bootstrap approaches available:
- 'discount_factors': Bootstrap DFs, then spline log(DFs) - traditional approach
- 'swap_rates': Spline swap rates directly, derive DFs - exact rate recovery

Interpolation methods for swap rates or log(DFs):
- 'cubic': Natural cubic spline (smooth, exact at knots)
- 'pchip': Monotone cubic (shape-preserving, no overshoots)
- 'smoothing': Smoothing spline with GCV (recommended for noisy data)

Reference:
    Hagan & West (2006), "Interpolation Methods for Curve Construction"
    Applied Mathematical Finance, 13(2):89-129
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Callable, Literal, Sequence

import numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator, UnivariateSpline
from scipy.interpolate import make_smoothing_spline

from .conventions import DayCountConvention, DEFAULT_SWAP_DAY_COUNT


# =============================================================================
# MODULE-LEVEL CACHES
# =============================================================================
# Annuity cache: Persists across curve objects with same content.
# Curve cache: Reuses curve objects with identical inputs.

_annuity_cache: dict[tuple, float] = {}
_annuity_cache_max_size = 10000

_curve_cache: dict[tuple, "SwapRateSplineCurve"] = {}
_curve_cache_max_size = 100  # Keep recent curves (e.g., last 100 days)


def clear_annuity_cache():
    """Clear the module-level annuity cache."""
    global _annuity_cache
    _annuity_cache = {}


def clear_curve_cache():
    """Clear the module-level curve cache."""
    global _curve_cache
    _curve_cache = {}


def clear_all_caches():
    """Clear all module-level caches."""
    clear_annuity_cache()
    clear_curve_cache()


def get_cache_stats() -> dict:
    """Get cache statistics."""
    return {
        "annuity_cache_size": len(_annuity_cache),
        "annuity_cache_max": _annuity_cache_max_size,
        "curve_cache_size": len(_curve_cache),
        "curve_cache_max": _curve_cache_max_size,
    }


class InterpolationMethod(Enum):
    """Available interpolation methods for curve construction."""
    SMOOTHING = "smoothing"          # Smoothing spline with GCV (auto lambda)
    CUBIC = "cubic"                  # Natural cubic spline (exact fit)
    LOG_LINEAR = "log_linear"        # Log-linear on discount factors
    MONOTONE_CONVEX = "monotone_convex"  # Hagan-West monotone convex
    PCHIP = "pchip"                  # Monotone cubic (shape-preserving)
    UNIVARIATE = "univariate"        # UnivariateSpline with smoothing factor


@dataclass
class SwapCurve:
    """
    Bootstrapped and interpolated swap curve.

    Attributes:
        value_date: Curve valuation date
        tenors: Array of tenors in years
        discount_factors: Bootstrapped discount factors
        _interp_func: Interpolation function for log discount factors
        method: Interpolation method used
    """
    value_date: date
    tenors: np.ndarray
    discount_factors: np.ndarray
    _interp_func: Callable
    day_count: DayCountConvention
    method: str = "smoothing"

    def df(self, t: float | np.ndarray) -> float | np.ndarray:
        """Get discount factor for tenor t (years). Accepts scalar or array."""
        t = np.asarray(t)
        scalar = t.ndim == 0
        t = np.atleast_1d(t).astype(float)

        result = np.ones_like(t, dtype=float)
        mask_interp = (t > 0) & (t <= self.tenors[-1])
        mask_extrap = t > self.tenors[-1]

        if np.any(mask_interp):
            log_df = self._interp_func(t[mask_interp])
            log_df = np.atleast_1d(log_df)  # Ensure array
            result[mask_interp] = np.exp(log_df)
        if np.any(mask_extrap):
            # Flat forward extrapolation
            result[mask_extrap] = self.discount_factors[-1] ** (t[mask_extrap] / self.tenors[-1])

        return float(result[0]) if scalar else result

    def forward_rate(self, t1: float, t2: float) -> float:
        """
        Compute simple forward rate between t1 and t2.

        Returns annualized rate for period [t1, t2].
        """
        if t2 <= t1:
            raise ValueError("t2 must be greater than t1")
        df1 = self.df(t1)
        df2 = self.df(t2)
        return (df1 / df2 - 1) / (t2 - t1)

    def instantaneous_forward(self, t: float) -> float:
        """
        Compute instantaneous forward rate at time t.

        f(t) = -d/dt ln(DF(t))
        """
        if t <= 0:
            return self.forward_rate(0, 0.01)
        eps = 0.001
        return -np.log(self.df(t + eps) / self.df(t)) / eps

    def swap_rate(self, start: float, end: float, freq: int = 2) -> float:
        """
        Compute par swap rate from start to end tenor.

        Args:
            start: Start tenor in years
            end: End tenor in years
            freq: Payment frequency per year (default 2 = semi-annual)

        Returns:
            Par swap rate (annualized)
        """
        if end <= start:
            raise ValueError("end must be greater than start")

        # Use vectorized annuity calculation
        annuity_val = self.annuity(start, end, freq)

        # Par swap rate = (DF_start - DF_end) / annuity
        df_start = self.df(start)
        df_end = self.df(end)

        return (df_start - df_end) / annuity_val

    def zero_rate(self, t: float) -> float:
        """Get continuously compounded zero rate for tenor t."""
        if t <= 0:
            return 0.0
        return -np.log(self.df(t)) / t

    def annuity(self, start: float, end: float, freq: int = 2) -> float:
        """
        Compute swap annuity (PV01) from start to end.

        Annuity = Σ DF(t_i) × accrual_i

        This is the present value of receiving 1bp per period.
        """
        dt = 1.0 / freq
        tenor = end - start
        n_full_periods = int(tenor * freq)

        if n_full_periods == 0:
            # Single stub period
            return float(self.df(end) * tenor)

        # Generate all payment times at once (vectorized)
        payment_times = start + np.arange(1, n_full_periods + 1) * dt
        payment_times = payment_times[payment_times <= end + 1e-10]

        if len(payment_times) == 0:
            return float(self.df(end) * tenor)

        # Get all DFs in one vectorized call
        dfs = self.df(payment_times)

        # Vectorized accrual: each period is dt (regular schedule)
        # For first period: accrual = payment_times[0] - start
        # For subsequent: accrual = dt
        accruals = np.full(len(payment_times), dt)
        accruals[0] = payment_times[0] - start

        annuity = np.sum(dfs * accruals)

        # Stub period at end if needed
        last_payment = payment_times[-1]
        if last_payment < end - 1e-10:
            stub_accrual = end - last_payment
            annuity += self.df(end) * stub_accrual

        return float(annuity)


class SwapRateSplineCurve:
    """
    Swap curve built by splining swap rates directly, then deriving DFs.

    This approach guarantees exact recovery of input swap rates at reference
    tenors, which is critical for trading applications.

    Algorithm:
    1. Spline the input swap rates to get a continuous swap rate curve
    2. Build a semi-annual DF grid by solving for each DF to match the splined rate
    3. Spline the resulting log(DFs) for smooth interpolation

    Attributes:
        value_date: Curve valuation date
        tenors: Input tenor points
        input_rates: Input swap rates
        method: Interpolation method for swap rate spline
    """

    def __init__(
        self,
        value_date: date,
        tenors: np.ndarray,
        swap_rates: np.ndarray,
        freq: int = 2,
        day_count: DayCountConvention | None = None,
        method: str = "smoothing",
        lam: float | None = 1e-10,
    ):
        self.value_date = value_date
        self.tenors = np.array(tenors, dtype=float)
        self.input_rates = np.array(swap_rates, dtype=float)
        self.freq = freq
        self.dt = 1.0 / freq
        self.day_count = day_count or DEFAULT_SWAP_DAY_COUNT
        self.method = method
        self.lam = lam

        # Compute curve fingerprint for module-level caching
        # Hash of (date, rates, method, lam) - uniquely identifies curve content
        rates_tuple = tuple(round(r, 8) for r in self.input_rates)
        self._fingerprint = hash((
            value_date.toordinal(),
            tuple(round(t, 6) for t in self.tenors),
            rates_tuple,
            method,
            lam if lam is not None else "auto",
        ))

        # Build swap rate spline (add t=0 point)
        tenors_with_zero = np.concatenate([[0.0], self.tenors])
        rates_with_zero = np.concatenate([[swap_rates[0]], self.input_rates])

        if method == "cubic":
            self._rate_spline = CubicSpline(tenors_with_zero, rates_with_zero)
        elif method == "pchip":
            self._rate_spline = PchipInterpolator(tenors_with_zero, rates_with_zero)
        elif method == "smoothing":
            # Use smoothing spline with lambda parameter
            # λ=1e-10 gives exact fit; larger λ = more smoothing
            if lam is None:
                self._rate_spline = make_smoothing_spline(tenors_with_zero, rates_with_zero)
            else:
                self._rate_spline = make_smoothing_spline(tenors_with_zero, rates_with_zero, lam=lam)
        else:
            # Default to smoothing with near-exact fit
            self._rate_spline = make_smoothing_spline(tenors_with_zero, rates_with_zero, lam=1e-10)

        # Derive discount factors from splined swap rates
        self._build_discount_factors()

    def _build_discount_factors(self):
        """Build DF curve consistent with the splined swap rates."""
        max_tenor = self.tenors[-1]

        # Semi-annual grid matching payment frequency
        self.df_tenors = np.arange(0, max_tenor + self.dt, self.dt)
        self.df_tenors = self.df_tenors[self.df_tenors <= max_tenor + 1e-9]

        n = len(self.df_tenors)
        self.discount_factors = np.ones(n)

        for i in range(1, n):
            T = self.df_tenors[i]
            target_rate = float(self._rate_spline(T))

            # Sum of DF * accrual for all payments before T
            annuity_before = 0.0
            for j in range(1, i):
                annuity_before += self.discount_factors[j] * self.dt

            # Solve for DF(T) from: rate = (1 - DF(T)) / (annuity_before + DF(T) * dt)
            # DF(T) = (1 - rate * annuity_before) / (1 + rate * dt)
            self.discount_factors[i] = (1.0 - target_rate * annuity_before) / (1.0 + target_rate * self.dt)

        # Build spline on log DFs for smooth interpolation
        log_dfs = np.log(np.maximum(self.discount_factors, 1e-10))
        self._log_df_spline = CubicSpline(self.df_tenors, log_dfs)

    def df(self, t: float | np.ndarray) -> float | np.ndarray:
        """Get discount factor for tenor t (years)."""
        t = np.asarray(t)
        scalar = t.ndim == 0
        t = np.atleast_1d(t).astype(float)

        result = np.ones_like(t, dtype=float)
        mask_interp = (t > 0) & (t <= self.df_tenors[-1])
        mask_extrap = t > self.df_tenors[-1]

        if np.any(mask_interp):
            result[mask_interp] = np.exp(self._log_df_spline(t[mask_interp]))
        if np.any(mask_extrap):
            # Flat forward extrapolation
            result[mask_extrap] = self.discount_factors[-1] ** (t[mask_extrap] / self.df_tenors[-1])

        return float(result[0]) if scalar else result

    def swap_rate(self, start: float, end: float, freq: int = 2) -> float:
        """
        Compute par swap rate from start to end tenor.

        For spot-starting swaps (start=0), returns the splined rate directly
        for exact recovery at input tenors.
        """
        if end <= start:
            raise ValueError("end must be greater than start")

        if start == 0 and end <= self.tenors[-1]:
            # Use splined rate directly for spot-starting swaps
            return float(self._rate_spline(end))

        # For forward-starting swaps, compute from DFs
        return self._compute_swap_rate_from_dfs(start, end, freq)

    def _compute_swap_rate_from_dfs(self, start: float, end: float, freq: int) -> float:
        """Compute swap rate from discount factors (uses vectorized annuity)."""
        annuity_val = self.annuity(start, end, freq)
        df_start = self.df(start)
        df_end = self.df(end)
        return (df_start - df_end) / annuity_val

    def forward_rate(self, t1: float, t2: float) -> float:
        """Compute simple forward rate between t1 and t2."""
        if t2 <= t1:
            raise ValueError("t2 must be greater than t1")
        df1 = self.df(t1)
        df2 = self.df(t2)
        return (df1 / df2 - 1) / (t2 - t1)

    def instantaneous_forward(self, t: float) -> float:
        """Compute instantaneous forward rate at time t."""
        if t <= 0:
            return self.forward_rate(0, 0.01)
        eps = 0.001
        return -np.log(self.df(t + eps) / self.df(t)) / eps

    def zero_rate(self, t: float) -> float:
        """Get continuously compounded zero rate for tenor t."""
        if t <= 0:
            return 0.0
        return -np.log(self.df(t)) / t

    def annuity(self, start: float, end: float, freq: int = 2) -> float:
        """Compute swap annuity (PV01) from start to end (vectorized, cached)."""
        global _annuity_cache, _annuity_cache_max_size

        # Check module-level cache (persists across curve objects with same content)
        cache_key = (self._fingerprint, round(start, 6), round(end, 6), freq)
        if cache_key in _annuity_cache:
            return _annuity_cache[cache_key]

        dt = 1.0 / freq
        tenor = end - start
        n_full_periods = int(tenor * freq)

        if n_full_periods == 0:
            result = float(self.df(end) * tenor)
            if len(_annuity_cache) < _annuity_cache_max_size:
                _annuity_cache[cache_key] = result
            return result

        # Generate all payment times at once
        payment_times = start + np.arange(1, n_full_periods + 1) * dt
        payment_times = payment_times[payment_times <= end + 1e-10]

        if len(payment_times) == 0:
            result = float(self.df(end) * tenor)
            if len(_annuity_cache) < _annuity_cache_max_size:
                _annuity_cache[cache_key] = result
            return result

        # Get all DFs in one vectorized call
        dfs = self.df(payment_times)

        # Vectorized accrual calculation
        accruals = np.full(len(payment_times), dt)
        accruals[0] = payment_times[0] - start

        annuity_val = np.sum(dfs * accruals)

        # Stub period at end if needed
        last_payment = payment_times[-1]
        if last_payment < end - 1e-10:
            annuity_val += self.df(end) * (end - last_payment)

        result = float(annuity_val)
        if len(_annuity_cache) < _annuity_cache_max_size:
            _annuity_cache[cache_key] = result
        return result


# =============================================================================
# INTERPOLATION METHODS
# =============================================================================

def _build_smoothing_spline(tenors: np.ndarray, log_dfs: np.ndarray, lam: float | None = None) -> Callable:
    """
    Build smoothing spline with penalty parameter lambda.

    Args:
        tenors: Tenor points
        log_dfs: Log discount factors
        lam: Smoothing parameter. If None, uses GCV to auto-select.
             lam=0 -> interpolating spline (exact fit)
             lam->inf -> approaches straight line
             Typical values: 1e-6 to 1e-2 for near-exact fit with smoothing

    This minimizes: Σ|y - g(x)|² + λ∫(g''(x))²dx
    """
    tenors_with_zero = np.concatenate([[0.0], tenors])
    log_dfs_with_zero = np.concatenate([[0.0], log_dfs])

    if lam is None:
        # Use GCV to find optimal lambda
        spline = make_smoothing_spline(tenors_with_zero, log_dfs_with_zero)
    else:
        # Use specified lambda
        spline = make_smoothing_spline(tenors_with_zero, log_dfs_with_zero, lam=lam)
    return spline


def _build_univariate_spline(tenors: np.ndarray, log_dfs: np.ndarray, s: float | None = None) -> Callable:
    """
    Build UnivariateSpline with smoothing factor s.

    Args:
        tenors: Tenor points
        log_dfs: Log discount factors
        s: Smoothing factor. If None or 0, fits exactly through points.
           Larger s = more smoothing.
           s = len(data) is a good starting point for smoothing.

    UnivariateSpline minimizes: Σ(w[i] * (y[i] - g(x[i]))²) <= s
    """
    tenors_with_zero = np.concatenate([[0.0], tenors])
    log_dfs_with_zero = np.concatenate([[0.0], log_dfs])

    if s is None or s == 0:
        # Exact interpolation
        spline = UnivariateSpline(tenors_with_zero, log_dfs_with_zero, k=3, s=0)
    else:
        spline = UnivariateSpline(tenors_with_zero, log_dfs_with_zero, k=3, s=s)
    return spline


def _build_cubic_spline(tenors: np.ndarray, log_dfs: np.ndarray) -> Callable:
    """Build natural cubic spline on log discount factors."""
    tenors_with_zero = np.concatenate([[0.0], tenors])
    log_dfs_with_zero = np.concatenate([[0.0], log_dfs])

    spline = CubicSpline(tenors_with_zero, log_dfs_with_zero, bc_type='natural')
    return spline


def _build_log_linear(tenors: np.ndarray, log_dfs: np.ndarray) -> Callable:
    """
    Build log-linear interpolation on discount factors.

    Simple and produces stable (piecewise constant) forward rates.
    """
    tenors_with_zero = np.concatenate([[0.0], tenors])
    log_dfs_with_zero = np.concatenate([[0.0], log_dfs])

    def interp(t):
        t = np.atleast_1d(np.asarray(t, dtype=float))
        return np.interp(t, tenors_with_zero, log_dfs_with_zero)

    return interp


def _build_pchip(tenors: np.ndarray, log_dfs: np.ndarray) -> Callable:
    """
    Build PCHIP (Piecewise Cubic Hermite Interpolating Polynomial).

    Shape-preserving, monotone cubic interpolation. Prevents overshoots
    and oscillations that can occur with natural cubic splines.
    """
    tenors_with_zero = np.concatenate([[0.0], tenors])
    log_dfs_with_zero = np.concatenate([[0.0], log_dfs])

    pchip = PchipInterpolator(tenors_with_zero, log_dfs_with_zero)
    return pchip


def _build_monotone_convex(tenors: np.ndarray, log_dfs: np.ndarray) -> Callable:
    """
    Build Hagan-West monotone convex interpolation.

    Ensures positive forward rates when discrete forwards are positive.
    Interpolates on instantaneous forward rates, not discount factors.

    Reference: Hagan & West (2006)
    """
    tenors_with_zero = np.concatenate([[0.0], tenors])
    dfs_with_zero = np.concatenate([[1.0], np.exp(log_dfs)])

    n = len(tenors_with_zero)

    # Compute discrete forward rates for each interval
    # f_i = -ln(DF_{i+1}/DF_i) / (t_{i+1} - t_i)
    f_discrete = np.zeros(n - 1)
    for i in range(n - 1):
        dt = tenors_with_zero[i + 1] - tenors_with_zero[i]
        if dt > 0:
            f_discrete[i] = -np.log(dfs_with_zero[i + 1] / dfs_with_zero[i]) / dt

    # Compute forward rates at nodes using monotone convex scheme
    f_node = np.zeros(n)
    f_node[0] = f_discrete[0]
    f_node[-1] = f_discrete[-1]

    for i in range(1, n - 1):
        # Weighted average ensuring monotonicity
        f_left = f_discrete[i - 1]
        f_right = f_discrete[i]

        # Simple monotone scheme: use harmonic mean if same sign
        if f_left * f_right > 0:
            f_node[i] = 2 * f_left * f_right / (f_left + f_right)
        else:
            f_node[i] = 0.5 * (f_left + f_right)

    # Build interpolator on instantaneous forwards, then integrate
    def interp(t):
        t = np.atleast_1d(np.asarray(t, dtype=float))
        result = np.zeros_like(t, dtype=float)

        for j, tj in enumerate(t):
            if tj <= 0:
                result[j] = 0.0
                continue

            # Find interval
            idx = np.searchsorted(tenors_with_zero, tj, side='right') - 1
            idx = max(0, min(idx, n - 2))

            # Integrate forward rate from 0 to t
            integral = 0.0

            # Full intervals
            for i in range(idx):
                dt = tenors_with_zero[i + 1] - tenors_with_zero[i]
                f_avg = 0.5 * (f_node[i] + f_node[i + 1])
                integral += f_avg * dt

            # Partial interval
            t_start = tenors_with_zero[idx]
            dt_partial = tj - t_start
            if dt_partial > 0:
                dt_full = tenors_with_zero[idx + 1] - t_start
                w = dt_partial / dt_full if dt_full > 0 else 0
                f_at_t = f_node[idx] * (1 - w) + f_node[idx + 1] * w
                f_avg = 0.5 * (f_node[idx] + f_at_t)
                integral += f_avg * dt_partial

            result[j] = -integral  # log(DF) = -∫f dt

        return result  # Always return array

    return interp


# Map method names to builders (simple methods without extra params)
_INTERPOLATION_BUILDERS = {
    "cubic": _build_cubic_spline,
    "log_linear": _build_log_linear,
    "pchip": _build_pchip,
    "monotone_convex": _build_monotone_convex,
}


# =============================================================================
# MAIN BOOTSTRAP FUNCTION
# =============================================================================

def bootstrap_swap_curve(
    value_date: date,
    tenors_years: Sequence[float],
    swap_rates: Sequence[float],
    freq: int = 2,
    day_count: DayCountConvention | None = None,
    method: Literal["smoothing", "cubic", "log_linear", "pchip", "monotone_convex", "univariate"] = "smoothing",
    lam: float | None = 1e-10,
    smooth_factor: float | None = None,
    bootstrap: Literal["discount_factors", "swap_rates"] = "swap_rates",
) -> SwapCurve | SwapRateSplineCurve:
    """
    Build a swap curve from par swap rates.

    Args:
        value_date: Curve valuation date
        tenors_years: Swap tenors in years (e.g., [1, 2, 3, ..., 40])
        swap_rates: Par swap rates as decimals (e.g., 0.045 for 4.5%)
        freq: Payment frequency per year (default 2 = semi-annual)
        day_count: Day count convention
        method: Interpolation method for swap rate curve:
            - 'smoothing': Smoothing spline (RECOMMENDED - exact with λ=1e-10)
            - 'cubic': Natural cubic spline (exact at knots)
            - 'pchip': Monotone cubic (shape-preserving)
            - 'log_linear': Log-linear (only for bootstrap='discount_factors')
            - 'monotone_convex': Hagan-West (only for bootstrap='discount_factors')
            - 'univariate': UnivariateSpline (only for bootstrap='discount_factors')
        lam: Lambda for smoothing spline. Default 1e-10 gives exact fit.
             Larger values = more smoothing (less exact). None = auto (GCV).
        smooth_factor: Smoothing factor for 'univariate' method.
        bootstrap: Bootstrap approach:
            - 'swap_rates': Spline swap rates, derive DFs (RECOMMENDED)
              Guarantees exact swap rate recovery at input tenors.
            - 'discount_factors': Bootstrap DFs, then spline log(DFs)
              Traditional approach, may have rate recovery errors.

    Returns:
        SwapCurve or SwapRateSplineCurve with interpolated rates/discount factors
    """
    global _curve_cache, _curve_cache_max_size

    # Use new swap rate spline approach (recommended)
    if bootstrap == "swap_rates":
        tenors = np.array(tenors_years, dtype=float)
        rates = np.array(swap_rates, dtype=float)

        if len(tenors) != len(rates):
            raise ValueError("tenors and rates must have same length")

        # Sort by tenor
        idx = np.argsort(tenors)
        tenors = tenors[idx]
        rates = rates[idx]

        # Map interpolation method (only cubic, pchip, smoothing supported)
        interp_method = method if method in ("cubic", "pchip", "smoothing") else "smoothing"

        # Check curve cache (reuse existing curve with same inputs)
        cache_key = (
            value_date.toordinal(),
            tuple(round(t, 6) for t in tenors),
            tuple(round(r, 8) for r in rates),
            freq,
            interp_method,
            lam if lam is not None else "auto",
        )

        if cache_key in _curve_cache:
            return _curve_cache[cache_key]

        # Build new curve
        curve = SwapRateSplineCurve(
            value_date=value_date,
            tenors=tenors,
            swap_rates=rates,
            freq=freq,
            day_count=day_count,
            method=interp_method,
            lam=lam,
        )

        # Cache the curve (with size limit)
        if len(_curve_cache) < _curve_cache_max_size:
            _curve_cache[cache_key] = curve

        return curve

    # Legacy discount factor bootstrap approach
    if day_count is None:
        day_count = DEFAULT_SWAP_DAY_COUNT

    tenors = np.array(tenors_years, dtype=float)
    rates = np.array(swap_rates, dtype=float)

    if len(tenors) != len(rates):
        raise ValueError("tenors and rates must have same length")

    # Sort by tenor
    idx = np.argsort(tenors)
    tenors = tenors[idx]
    rates = rates[idx]

    # Bootstrap discount factors
    dt = 1.0 / freq
    dfs = np.zeros(len(tenors))

    for i, (T, r) in enumerate(zip(tenors, rates)):
        # Sum previous DFs for coupon payments before maturity
        coupon_pv = 0.0
        t = dt
        while t < T - 1e-9:
            # Interpolate DF for intermediate dates
            if t <= tenors[0]:
                # Linear interpolation for very short end
                df_t = 1.0 - t * rates[0]
            else:
                # Find bracketing tenors
                j = np.searchsorted(tenors[:i + 1], t) - 1
                if j < 0:
                    j = 0
                if j >= i:
                    df_t = dfs[i - 1] if i > 0 else 1.0 / (1 + t * rates[0])
                else:
                    # Log-linear interpolation during bootstrap
                    t1, t2 = tenors[j], tenors[j + 1] if j + 1 <= i else T
                    df1, df2 = dfs[j], dfs[j + 1] if j + 1 < i else dfs[j]
                    w = (t - t1) / (t2 - t1) if t2 > t1 else 0
                    df_t = np.exp((1 - w) * np.log(df1) + w * np.log(df2)) if df1 > 0 and df2 > 0 else df1

            coupon_pv += r * dt * df_t
            t += dt

        # Compute final accrual: time from last coupon payment to maturity
        # Handles short tenors (< dt) and stub periods correctly
        n_full_pmts = int(T / dt)
        last_pmt_time = n_full_pmts * dt
        if last_pmt_time >= T - 1e-9:
            last_pmt_time -= dt  # Payment at T is the final payment, not a prior one
        final_accrual = T - max(0.0, last_pmt_time)

        # Solve for DF at maturity: DF_T = (1 - coupon_pv) / (1 + r * final_accrual)
        dfs[i] = (1.0 - coupon_pv) / (1.0 + r * final_accrual)

    # Build interpolation function based on method
    log_dfs = np.log(dfs)

    if method == "smoothing":
        interp_func = _build_smoothing_spline(tenors, log_dfs, lam=lam)
    elif method == "univariate":
        interp_func = _build_univariate_spline(tenors, log_dfs, s=smooth_factor)
    elif method in _INTERPOLATION_BUILDERS:
        interp_func = _INTERPOLATION_BUILDERS[method](tenors, log_dfs)
    else:
        valid = list(_INTERPOLATION_BUILDERS.keys()) + ["smoothing", "univariate"]
        raise ValueError(f"Unknown method '{method}'. Choose from: {valid}")

    return SwapCurve(
        value_date=value_date,
        tenors=tenors,
        discount_factors=dfs,
        _interp_func=interp_func,
        day_count=day_count,
        method=method,
    )
