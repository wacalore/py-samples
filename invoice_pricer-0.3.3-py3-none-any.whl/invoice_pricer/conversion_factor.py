"""
Treasury Futures Conversion Factor Calculator.

Computes conversion factors for deliverable bonds into CME Treasury futures
using the standard 6% yield methodology.

Example:
    >>> from invoice_pricer.conversion_factor import compute_cf
    >>> cf = compute_cf(coupon=0.04, maturity_years=9.5, first_delivery_month=3)
    >>> print(f"Conversion factor: {cf:.4f}")
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional, Literal
import math


# Standard yield for CF calculation (6%)
CF_YIELD = 0.06


@dataclass
class ConversionFactorResult:
    """
    Result of conversion factor calculation.

    Attributes:
        cf: Conversion factor
        coupon: Bond coupon rate
        maturity_years: Years to maturity at delivery
        n: Number of whole 6-month periods
        z: Months to first coupon (rounded)
        accrued_factor: Accrued interest adjustment
    """
    cf: float
    coupon: float
    maturity_years: float
    n: int
    z: int
    accrued_factor: float


def compute_cf(
    coupon: float,
    maturity_years: float,
    first_delivery_month: int = 3,
) -> float:
    """
    Compute conversion factor for a Treasury bond.

    Uses CME methodology: price at 6% yield, rounded to nearest quarter.

    Args:
        coupon: Annual coupon rate (decimal, e.g., 0.04 for 4%)
        maturity_years: Years from first delivery date to maturity
        first_delivery_month: First delivery month (3=Mar, 6=Jun, 9=Sep, 12=Dec)

    Returns:
        Conversion factor

    Example:
        >>> cf = compute_cf(0.0375, 9.75)
        >>> print(f"CF: {cf:.4f}")
    """
    result = compute_cf_detailed(coupon, maturity_years, first_delivery_month)
    return result.cf


def compute_cf_detailed(
    coupon: float,
    maturity_years: float,
    first_delivery_month: int = 3,
) -> ConversionFactorResult:
    """
    Compute conversion factor with detailed breakdown.

    CME Methodology:
    1. Round maturity down to nearest quarter (3 months)
    2. If rounded maturity has 3-month stub, use z=3; else z=6
    3. Calculate price at 6% yield
    4. Subtract accrued interest

    Args:
        coupon: Annual coupon rate (decimal)
        maturity_years: Years from first delivery date to maturity
        first_delivery_month: First delivery month

    Returns:
        ConversionFactorResult with CF and calculation details
    """
    c = coupon  # Annual coupon rate
    y = CF_YIELD  # 6% standard yield

    # Round maturity down to nearest quarter (3 months = 0.25 years)
    maturity_quarters = int(maturity_years * 4)
    rounded_maturity = maturity_quarters / 4.0

    # Determine z (months to first coupon) and n (whole semi-annual periods)
    # If remaining months after rounding is 3, z=3; otherwise z=6
    remainder_months = int((maturity_years - rounded_maturity) * 12 + 0.5)

    if maturity_quarters % 2 == 1:
        # Odd number of quarters: 3-month stub
        z = 3
        n = (maturity_quarters - 1) // 2
    else:
        # Even number of quarters: 6-month stub or exact
        z = 6
        n = maturity_quarters // 2

    # Semi-annual yield
    y_semi = y / 2

    # Time to first coupon in semi-annual periods
    v = z / 6.0

    # Discount factor
    d = 1 / (1 + y_semi)

    # Price formula (per $100 face)
    # PV of coupons + PV of principal
    if n > 0:
        # Annuity factor for n payments starting at time v
        annuity = (c / 2) * d**v * (1 - d**n) / (1 - d)
        principal = 100 * d**(n + v - 1)
    else:
        # Short-dated bond
        annuity = 0
        principal = 100 * d**v

    # Add final coupon with principal
    price = annuity + principal + (c / 2) * 100 * d**(n + v - 1) if n > 0 else principal

    # Recalculate using standard CF formula
    # CF = (1/(1.03)^v) * [(c/2) * ((1-(1/1.03)^n)/0.03) + (1/1.03)^n] - (c/2)*(6-z)/6

    factor_v = 1 / (1.03 ** v)
    factor_n = 1 / (1.03 ** n)

    if n > 0:
        annuity_factor = (1 - factor_n) / 0.03
    else:
        annuity_factor = 0

    cf_price = factor_v * ((c / 2) * annuity_factor + factor_n)

    # Accrued interest adjustment
    accrued_factor = (c / 2) * (6 - z) / 6

    cf = cf_price - accrued_factor

    return ConversionFactorResult(
        cf=round(cf, 4),
        coupon=coupon,
        maturity_years=maturity_years,
        n=n,
        z=z,
        accrued_factor=accrued_factor,
    )


def compute_cf_from_dates(
    coupon: float,
    maturity_date: date,
    delivery_date: date,
) -> float:
    """
    Compute conversion factor from actual dates.

    Args:
        coupon: Annual coupon rate (decimal)
        maturity_date: Bond maturity date
        delivery_date: First day of delivery month

    Returns:
        Conversion factor

    Example:
        >>> from datetime import date
        >>> cf = compute_cf_from_dates(0.04, date(2029, 11, 15), date(2024, 3, 1))
        >>> print(f"CF: {cf:.4f}")
    """
    # Calculate years to maturity from first delivery date
    maturity_years = (maturity_date - delivery_date).days / 365.0

    return compute_cf(coupon, maturity_years)


def get_contract_cf_yield() -> float:
    """Return the standard conversion factor yield (6%)."""
    return CF_YIELD


# Contract specifications
CONTRACT_SPECS = {
    "TU": {
        "name": "2-Year T-Note",
        "min_maturity": 1.75,
        "max_maturity": 2.0,
        "tick_size": 1/128,
        "tick_value": 15.625,
        "contract_size": 200000,
    },
    "FV": {
        "name": "5-Year T-Note",
        "min_maturity": 4.167,
        "max_maturity": 5.25,
        "tick_size": 1/128,
        "tick_value": 7.8125,
        "contract_size": 100000,
    },
    "TY": {
        "name": "10-Year T-Note",
        "min_maturity": 6.5,
        "max_maturity": 10.0,
        "tick_size": 1/64,
        "tick_value": 15.625,
        "contract_size": 100000,
    },
    "US": {
        "name": "T-Bond",
        "min_maturity": 15.0,
        "max_maturity": 25.0,
        "tick_size": 1/32,
        "tick_value": 31.25,
        "contract_size": 100000,
    },
    "WN": {
        "name": "Ultra T-Bond",
        "min_maturity": 25.0,
        "max_maturity": 99.0,
        "tick_size": 1/32,
        "tick_value": 31.25,
        "contract_size": 100000,
    },
}


def get_contract_spec(contract: str) -> dict:
    """
    Get contract specifications.

    Args:
        contract: Contract code (TU, FV, TY, US, WN)

    Returns:
        Dictionary of contract specifications
    """
    contract = contract.upper()
    if contract not in CONTRACT_SPECS:
        raise ValueError(f"Unknown contract: {contract}. Use: {list(CONTRACT_SPECS.keys())}")
    return CONTRACT_SPECS[contract]
