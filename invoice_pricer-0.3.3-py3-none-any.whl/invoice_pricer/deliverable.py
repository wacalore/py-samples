"""
Treasury Futures Deliverable Basket Analysis.

Screens bonds for deliverability and identifies CTD (cheapest-to-deliver).

Example:
    >>> from invoice_pricer.deliverable import get_deliverable_basket, find_ctd
    >>> from invoice_pricer.secmaster import build_secmaster
    >>> secmaster = build_secmaster()
    >>> basket = get_deliverable_basket("TY", secmaster, delivery_date=date(2024, 3, 1))
    >>> ctd = find_ctd(basket, futures_price=110.5)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import List, Optional, Literal

from .secmaster import TreasuryBondInfo
from .conversion_factor import (
    compute_cf_from_dates,
    get_contract_spec,
    CONTRACT_SPECS,
)
from .bonds import bond_yield, Bond


@dataclass
class DeliverableBond:
    """
    A bond in the deliverable basket with computed analytics.

    Attributes:
        bond: Underlying bond info
        cf: Conversion factor
        years_to_maturity: Years from delivery to maturity
        implied_price: Futures price × CF
        implied_yield: Yield at implied price
        basis: Spot price - implied price (requires spot_price)
        net_basis: Basis adjusted for carry (requires additional inputs)
    """
    bond: TreasuryBondInfo
    cf: float
    years_to_maturity: float
    implied_price: Optional[float] = None
    implied_yield: Optional[float] = None
    gross_basis: Optional[float] = None
    net_basis: Optional[float] = None
    implied_repo: Optional[float] = None

    @property
    def cusip(self) -> str:
        return self.bond.cusip

    @property
    def coupon(self) -> float:
        return self.bond.coupon

    @property
    def maturity_date(self) -> date:
        return self.bond.maturity_date


def is_deliverable(
    bond: TreasuryBondInfo,
    contract: str,
    delivery_date: date,
) -> bool:
    """
    Check if a bond is deliverable into a futures contract.

    Args:
        bond: Treasury bond info
        contract: Contract code (TU, FV, TY, US, WN)
        delivery_date: First day of delivery month

    Returns:
        True if bond is deliverable
    """
    spec = get_contract_spec(contract)
    years_to_mat = bond.years_to_maturity_from(delivery_date)

    return spec["min_maturity"] <= years_to_mat <= spec["max_maturity"]


def get_deliverable_basket(
    contract: str,
    secmaster: List[TreasuryBondInfo],
    delivery_date: date,
    futures_price: Optional[float] = None,
) -> List[DeliverableBond]:
    """
    Get all deliverable bonds for a futures contract.

    Args:
        contract: Contract code (TU, FV, TY, US, WN)
        secmaster: List of all available bonds
        delivery_date: First day of delivery month
        futures_price: Optional futures price to compute implied metrics

    Returns:
        List of DeliverableBond with CFs and analytics

    Example:
        >>> basket = get_deliverable_basket("TY", secmaster, date(2024, 3, 1), 110.5)
        >>> for b in basket:
        ...     print(f"{b.cusip}: CF={b.cf:.4f}, Implied={b.implied_price:.3f}")
    """
    basket = []

    for bond in secmaster:
        if not is_deliverable(bond, contract, delivery_date):
            continue

        years_to_mat = bond.years_to_maturity_from(delivery_date)
        cf = compute_cf_from_dates(bond.coupon, bond.maturity_date, delivery_date)

        deliverable = DeliverableBond(
            bond=bond,
            cf=cf,
            years_to_maturity=years_to_mat,
        )

        # Compute implied metrics if futures price provided
        if futures_price is not None:
            deliverable.implied_price = futures_price * cf

            # Compute implied yield
            try:
                bond_obj = Bond(coupon=bond.coupon, maturity_years=years_to_mat)
                deliverable.implied_yield = bond_yield(bond_obj, deliverable.implied_price)
            except Exception:
                pass

        basket.append(deliverable)

    # Sort by conversion factor (descending)
    basket.sort(key=lambda x: x.cf, reverse=True)

    return basket


def compute_basis(
    basket: List[DeliverableBond],
    spot_prices: dict,
    futures_price: float,
) -> List[DeliverableBond]:
    """
    Compute gross basis for each bond in the basket.

    Gross Basis = Spot Price - (Futures × CF)

    Args:
        basket: List of deliverable bonds
        spot_prices: Dict of CUSIP -> spot clean price
        futures_price: Current futures price

    Returns:
        Updated basket with gross_basis populated
    """
    for bond in basket:
        if bond.cusip in spot_prices:
            spot = spot_prices[bond.cusip]
            implied = futures_price * bond.cf
            bond.implied_price = implied
            bond.gross_basis = spot - implied

    return basket


def compute_accrued_at_date(
    coupon: float,
    maturity_date: date,
    calc_date: date,
) -> float:
    """
    Compute accrued interest at a given date using 30/360 convention.

    Args:
        coupon: Annual coupon rate (decimal)
        maturity_date: Bond maturity date (determines coupon months)
        calc_date: Date to compute accrued as of

    Returns:
        Accrued interest per $100 face
    """
    # Coupon months based on maturity
    mat_month = maturity_date.month
    if mat_month <= 6:
        coupon_months = [mat_month, mat_month + 6]
    else:
        coupon_months = [mat_month - 6, mat_month]

    # Find most recent coupon date before calc_date
    year = calc_date.year
    coupon_day = maturity_date.day

    potential_dates = []
    for y in [year - 1, year]:
        for m in coupon_months:
            try:
                potential_dates.append(date(y, m, min(coupon_day, 28)))
            except ValueError:
                pass

    # Last coupon date on or before calc_date
    past_dates = [d for d in potential_dates if d <= calc_date]
    if not past_dates:
        return 0.0

    last_coupon = max(past_dates)

    # 30/360 day count
    d1, m1, y1 = last_coupon.day, last_coupon.month, last_coupon.year
    d2, m2, y2 = calc_date.day, calc_date.month, calc_date.year

    if d1 == 31:
        d1 = 30
    if d2 == 31 and d1 >= 30:
        d2 = 30

    days = (y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1)
    accrued = (coupon / 2) * (days / 180) * 100

    return accrued


def compute_carry(
    spot_price: float,
    coupon: float,
    maturity_date: date,
    settle_date: date,
    delivery_date: date,
    repo_rate: float,
) -> float:
    """
    Compute carry from settlement to delivery.

    Carry = Coupon Accrual Gain - Financing Cost

    Args:
        spot_price: Clean spot price
        coupon: Annual coupon rate (decimal)
        maturity_date: Bond maturity date
        settle_date: Settlement date
        delivery_date: Futures delivery date
        repo_rate: Repo financing rate (decimal, e.g., 0.05 for 5%)

    Returns:
        Carry in price points (per $100 face)
    """
    # Accrued at delivery vs settlement
    accrued_settle = compute_accrued_at_date(coupon, maturity_date, settle_date)
    accrued_delivery = compute_accrued_at_date(coupon, maturity_date, delivery_date)

    # Check for interim coupon payment
    mat_month = maturity_date.month
    if mat_month <= 6:
        coupon_months = [mat_month, mat_month + 6]
    else:
        coupon_months = [mat_month - 6, mat_month]

    coupon_day = min(maturity_date.day, 28)
    interim_coupon = 0.0

    for y in [settle_date.year, settle_date.year + 1]:
        for m in coupon_months:
            try:
                cpn_date = date(y, m, coupon_day)
                if settle_date < cpn_date <= delivery_date:
                    interim_coupon += (coupon / 2) * 100
            except ValueError:
                pass

    # Days from settle to delivery (actual)
    days = (delivery_date - settle_date).days

    # Dirty price for financing
    dirty_price = spot_price + accrued_settle

    # Financing cost (Act/360)
    financing_cost = dirty_price * repo_rate * (days / 360)

    # Coupon income = accrual gain + any interim coupons
    coupon_income = (accrued_delivery - accrued_settle) + interim_coupon

    carry = coupon_income - financing_cost

    return carry


def compute_net_basis(
    basket: List[DeliverableBond],
    spot_prices: dict,
    futures_price: float,
    settle_date: date,
    delivery_date: date,
    repo_rate: float,
) -> List[DeliverableBond]:
    """
    Compute net basis for each bond in the basket.

    Net Basis = Gross Basis - Carry

    Args:
        basket: List of deliverable bonds
        spot_prices: Dict of CUSIP -> spot clean price
        futures_price: Current futures price
        settle_date: Trade settlement date
        delivery_date: Futures delivery date
        repo_rate: Repo financing rate (decimal)

    Returns:
        Updated basket with net_basis populated

    Example:
        >>> basket = compute_net_basis(
        ...     basket, spot_prices, 110.5,
        ...     settle_date=date(2024, 1, 15),
        ...     delivery_date=date(2024, 3, 1),
        ...     repo_rate=0.05
        ... )
    """
    # First compute gross basis
    basket = compute_basis(basket, spot_prices, futures_price)

    for bond in basket:
        if bond.cusip in spot_prices and bond.gross_basis is not None:
            spot = spot_prices[bond.cusip]

            carry = compute_carry(
                spot_price=spot,
                coupon=bond.coupon,
                maturity_date=bond.maturity_date,
                settle_date=settle_date,
                delivery_date=delivery_date,
                repo_rate=repo_rate,
            )

            bond.net_basis = bond.gross_basis - carry

    return basket


def compute_implied_repo(
    basket: List[DeliverableBond],
    spot_prices: dict,
    futures_price: float,
    settle_date: date,
    delivery_date: date,
) -> List[DeliverableBond]:
    """
    Compute implied repo rate for each bond.

    Implied repo is the financing rate that makes net basis = 0.

    Implied Repo = (Invoice Price - Purchase Price) / Purchase Price × (360/days)

    Where:
        Invoice Price = Futures × CF + Accrued at Delivery
        Purchase Price = Spot + Accrued at Settlement

    Args:
        basket: List of deliverable bonds
        spot_prices: Dict of CUSIP -> spot clean price
        futures_price: Current futures price
        settle_date: Trade settlement date
        delivery_date: Futures delivery date

    Returns:
        Updated basket with implied_repo populated

    Example:
        >>> basket = compute_implied_repo(
        ...     basket, spot_prices, 110.5,
        ...     settle_date=date(2024, 1, 15),
        ...     delivery_date=date(2024, 3, 1)
        ... )
        >>> ctd = find_ctd(basket, 110.5, method="implied_repo")
    """
    days = (delivery_date - settle_date).days
    if days <= 0:
        return basket

    for bond in basket:
        if bond.cusip not in spot_prices:
            continue

        spot = spot_prices[bond.cusip]

        # Accrued interest
        accrued_settle = compute_accrued_at_date(
            bond.coupon, bond.maturity_date, settle_date
        )
        accrued_delivery = compute_accrued_at_date(
            bond.coupon, bond.maturity_date, delivery_date
        )

        # Check for interim coupon
        mat_month = bond.maturity_date.month
        if mat_month <= 6:
            coupon_months = [mat_month, mat_month + 6]
        else:
            coupon_months = [mat_month - 6, mat_month]

        coupon_day = min(bond.maturity_date.day, 28)
        interim_coupon = 0.0

        for y in [settle_date.year, settle_date.year + 1]:
            for m in coupon_months:
                try:
                    cpn_date = date(y, m, coupon_day)
                    if settle_date < cpn_date <= delivery_date:
                        interim_coupon += (bond.coupon / 2) * 100
                except ValueError:
                    pass

        # Purchase price (dirty)
        purchase_price = spot + accrued_settle

        # Invoice price at delivery
        invoice_price = futures_price * bond.cf + accrued_delivery

        # Total return including interim coupon
        total_proceeds = invoice_price + interim_coupon

        # Implied repo rate (annualized, Act/360)
        implied_repo = ((total_proceeds - purchase_price) / purchase_price) * (360 / days)

        bond.implied_repo = implied_repo
        bond.implied_price = futures_price * bond.cf
        bond.gross_basis = spot - bond.implied_price

    return basket


def find_ctd(
    basket: List[DeliverableBond],
    futures_price: float,
    spot_prices: Optional[dict] = None,
    method: Literal["implied_repo", "net_basis", "gross_basis"] = "gross_basis",
) -> Optional[DeliverableBond]:
    """
    Find the cheapest-to-deliver bond.

    CTD is determined by:
    - Lowest gross basis (spot - futures×CF)
    - Or highest implied repo rate
    - Or lowest net basis (basis - carry)

    Args:
        basket: List of deliverable bonds
        futures_price: Current futures price
        spot_prices: Dict of CUSIP -> spot price (required for basis methods)
        method: CTD determination method

    Returns:
        CTD bond or None if basket is empty

    Example:
        >>> ctd = find_ctd(basket, 110.5, spot_prices, method="gross_basis")
        >>> if ctd:
        ...     print(f"CTD: {ctd.cusip}, Basis: {ctd.gross_basis:.4f}")
    """
    if not basket:
        return None

    if method == "gross_basis" and spot_prices:
        basket = compute_basis(basket, spot_prices, futures_price)
        valid = [b for b in basket if b.gross_basis is not None]
        if valid:
            return min(valid, key=lambda x: x.gross_basis)

    elif method == "implied_repo":
        valid = [b for b in basket if b.implied_repo is not None]
        if valid:
            return max(valid, key=lambda x: x.implied_repo)

    elif method == "net_basis" and spot_prices:
        valid = [b for b in basket if b.net_basis is not None]
        if valid:
            return min(valid, key=lambda x: x.net_basis)

    # Fallback: highest CF (proxy for low coupon bonds which tend to be CTD)
    return max(basket, key=lambda x: x.cf)


def rank_deliverables(
    basket: List[DeliverableBond],
    futures_price: float,
    spot_prices: dict,
) -> List[DeliverableBond]:
    """
    Rank deliverables by gross basis (ascending = cheapest first).

    Args:
        basket: List of deliverable bonds
        futures_price: Current futures price
        spot_prices: Dict of CUSIP -> spot price

    Returns:
        Basket sorted by gross basis (CTD first)
    """
    basket = compute_basis(basket, spot_prices, futures_price)
    valid = [b for b in basket if b.gross_basis is not None]
    valid.sort(key=lambda x: x.gross_basis)
    return valid


def get_delivery_months(year: int) -> List[date]:
    """
    Get first delivery dates for all quarterly contracts in a year.

    Treasury futures deliver in March, June, September, December.

    Args:
        year: Calendar year

    Returns:
        List of first delivery dates
    """
    return [
        date(year, 3, 1),
        date(year, 6, 1),
        date(year, 9, 1),
        date(year, 12, 1),
    ]


def get_next_delivery_date(as_of: Optional[date] = None) -> date:
    """
    Get the next futures delivery date.

    Args:
        as_of: Reference date (default: today)

    Returns:
        First day of next delivery month
    """
    if as_of is None:
        as_of = date.today()

    # Delivery months: 3, 6, 9, 12
    month = as_of.month
    year = as_of.year

    if month <= 3:
        return date(year, 3, 1)
    elif month <= 6:
        return date(year, 6, 1)
    elif month <= 9:
        return date(year, 9, 1)
    elif month <= 12:
        return date(year, 12, 1)
    else:
        return date(year + 1, 3, 1)


def print_basket(basket: List[DeliverableBond], top_n: int = 10) -> None:
    """
    Print deliverable basket summary.

    Args:
        basket: List of deliverable bonds
        top_n: Number of bonds to display
    """
    print(f"{'CUSIP':<12} {'Coupon':>7} {'Maturity':>12} {'CF':>8} {'YTM':>8} {'Implied':>9} {'Basis':>8}")
    print("-" * 75)

    for bond in basket[:top_n]:
        coupon_str = f"{bond.coupon*100:.3f}%"
        mat_str = str(bond.maturity_date)
        cf_str = f"{bond.cf:.4f}"
        ytm_str = f"{bond.years_to_maturity:.2f}Y"
        implied_str = f"{bond.implied_price:.3f}" if bond.implied_price else "N/A"
        basis_str = f"{bond.gross_basis:.4f}" if bond.gross_basis is not None else "N/A"

        print(f"{bond.cusip:<12} {coupon_str:>7} {mat_str:>12} {cf_str:>8} {ytm_str:>8} {implied_str:>9} {basis_str:>8}")
