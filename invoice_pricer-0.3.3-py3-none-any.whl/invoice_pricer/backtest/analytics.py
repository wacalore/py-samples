"""
Backtest Analytics and Performance Metrics.

Includes leg-level P&L attribution (futures vs swap).

Example:
    >>> from invoice_pricer.backtest.analytics import Analytics, BacktestResult
    >>> sharpe = Analytics.compute_sharpe(daily_pnl)
    >>> max_dd, duration = Analytics.compute_drawdown(cumulative_pnl)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import List, Tuple, Dict, Optional
import math

from .position import ClosedTrade


@dataclass
class TradeRecord:
    """
    Record of a single completed trade with leg-level attribution.

    Attributes:
        entry_date: Trade entry date
        exit_date: Trade exit date
        direction: "long" or "short"

        # Spread (reference)
        entry_spread_bp: Spread at entry
        exit_spread_bp: Spread at exit

        # Futures leg
        entry_futures_price: Futures price at entry
        exit_futures_price: Futures price at exit
        futures_pnl: P&L from futures leg

        # Swap leg
        entry_swap_rate: Swap rate at entry (decimal)
        exit_swap_rate: Swap rate at exit (decimal)
        swap_pnl: P&L from swap leg

        # Totals
        pnl: Total realized P&L
        holding_days: Days position was held
        ctd_rolls: Number of CTD changes during trade
        swap_notional: Notional amount of swap leg
        futures_notional: Notional amount of futures leg
    """
    entry_date: date
    exit_date: date
    direction: str

    # Spread (reference)
    entry_spread_bp: float
    exit_spread_bp: float

    # Futures leg
    entry_futures_price: float
    exit_futures_price: float
    futures_pnl: float

    # Swap leg
    entry_swap_rate: float
    exit_swap_rate: float
    swap_pnl: float

    # Totals
    pnl: float
    holding_days: int
    ctd_rolls: int
    swap_notional: float
    futures_notional: float

    @classmethod
    def from_closed_trade(cls, trade: ClosedTrade) -> "TradeRecord":
        """Create from ClosedTrade."""
        return cls(
            entry_date=trade.entry_date,
            exit_date=trade.exit_date,
            direction=trade.direction,
            entry_spread_bp=trade.entry_spread_bp,
            exit_spread_bp=trade.exit_spread_bp,
            entry_futures_price=trade.entry_futures_price,
            exit_futures_price=trade.exit_futures_price,
            futures_pnl=trade.futures_pnl,
            entry_swap_rate=trade.entry_swap_rate,
            exit_swap_rate=trade.exit_swap_rate,
            swap_pnl=trade.swap_pnl,
            pnl=trade.pnl,
            holding_days=trade.holding_days,
            ctd_rolls=trade.ctd_rolls,
            swap_notional=trade.swap_notional,
            futures_notional=trade.futures_notional,
        )


@dataclass
class BacktestResult:
    """
    Complete backtest results with leg-level attribution.

    Contains time series, trade records, and summary statistics.
    """
    # Time series
    dates: List[date]
    daily_pnl: List[float]
    cumulative_pnl: List[float]
    spread_series: List[float]
    position_series: List[int]  # 1=long, -1=short, 0=flat

    # Trade list
    trades: List[TradeRecord]

    # Leg-level time series (optional)
    futures_pnl_series: List[float] = field(default_factory=list)
    swap_pnl_series: List[float] = field(default_factory=list)
    futures_price_series: List[float] = field(default_factory=list)
    swap_rate_series: List[float] = field(default_factory=list)

    # Summary statistics
    total_pnl: float = 0.0
    total_futures_pnl: float = 0.0
    total_swap_pnl: float = 0.0
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    max_drawdown: float = 0.0
    max_drawdown_duration: int = 0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    num_trades: int = 0
    avg_holding_period: float = 0.0
    ctd_rolls_total: int = 0

    # Computed from time series
    annualized_return: float = 0.0
    annualized_volatility: float = 0.0
    calmar_ratio: float = 0.0

    def __post_init__(self):
        """Compute summary statistics."""
        self.num_trades = len(self.trades)
        self.total_pnl = sum(self.daily_pnl)

        # Leg-level totals
        if self.futures_pnl_series:
            self.total_futures_pnl = sum(self.futures_pnl_series)
        if self.swap_pnl_series:
            self.total_swap_pnl = sum(self.swap_pnl_series)

        self.ctd_rolls_total = sum(t.ctd_rolls for t in self.trades)

        if self.daily_pnl:
            self.sharpe_ratio = Analytics.compute_sharpe(self.daily_pnl)
            self.sortino_ratio = Analytics.compute_sortino(self.daily_pnl)
            self.max_drawdown, self.max_drawdown_duration = Analytics.compute_drawdown(
                self.cumulative_pnl
            )

            # Annualized metrics
            n_days = len(self.daily_pnl)
            mean_daily = sum(self.daily_pnl) / n_days if n_days else 0
            self.annualized_return = mean_daily * 252

            variance = sum((x - mean_daily) ** 2 for x in self.daily_pnl) / n_days if n_days > 1 else 0
            self.annualized_volatility = math.sqrt(variance * 252) if variance else 0

            if self.max_drawdown != 0:
                self.calmar_ratio = self.annualized_return / abs(self.max_drawdown)

        if self.trades:
            trade_stats = Analytics.compute_trade_stats(self.trades)
            self.win_rate = trade_stats["win_rate"]
            self.profit_factor = trade_stats["profit_factor"]
            self.avg_win = trade_stats["avg_win"]
            self.avg_loss = trade_stats["avg_loss"]
            self.avg_holding_period = trade_stats["avg_holding_period"]


class Analytics:
    """Static methods for computing performance metrics."""

    @staticmethod
    def compute_sharpe(
        daily_pnl: List[float],
        risk_free_rate: float = 0.0,
        annualization: float = 252,
    ) -> float:
        """
        Compute annualized Sharpe ratio.

        Args:
            daily_pnl: List of daily P&L values
            risk_free_rate: Annual risk-free rate (decimal)
            annualization: Trading days per year

        Returns:
            Annualized Sharpe ratio
        """
        if not daily_pnl or len(daily_pnl) < 2:
            return 0.0

        n = len(daily_pnl)
        mean = sum(daily_pnl) / n
        daily_rf = risk_free_rate / annualization
        excess = mean - daily_rf

        variance = sum((x - mean) ** 2 for x in daily_pnl) / (n - 1)
        std = math.sqrt(variance) if variance > 0 else 1e-10

        return (excess / std) * math.sqrt(annualization)

    @staticmethod
    def compute_sortino(
        daily_pnl: List[float],
        risk_free_rate: float = 0.0,
        annualization: float = 252,
    ) -> float:
        """
        Compute annualized Sortino ratio (downside deviation only).

        Args:
            daily_pnl: List of daily P&L values
            risk_free_rate: Annual risk-free rate
            annualization: Trading days per year

        Returns:
            Annualized Sortino ratio
        """
        if not daily_pnl or len(daily_pnl) < 2:
            return 0.0

        n = len(daily_pnl)
        mean = sum(daily_pnl) / n
        daily_rf = risk_free_rate / annualization
        excess = mean - daily_rf

        # Downside deviation
        negative_returns = [x for x in daily_pnl if x < 0]
        if not negative_returns:
            return float("inf") if excess > 0 else 0.0

        downside_var = sum(x ** 2 for x in negative_returns) / len(negative_returns)
        downside_std = math.sqrt(downside_var) if downside_var > 0 else 1e-10

        return (excess / downside_std) * math.sqrt(annualization)

    @staticmethod
    def compute_drawdown(cumulative_pnl: List[float]) -> Tuple[float, int]:
        """
        Compute maximum drawdown and its duration.

        Args:
            cumulative_pnl: List of cumulative P&L values

        Returns:
            (max_drawdown, max_duration_days)
        """
        if not cumulative_pnl:
            return 0.0, 0

        max_dd = 0.0
        max_duration = 0
        peak = cumulative_pnl[0]
        peak_idx = 0

        for i, pnl in enumerate(cumulative_pnl):
            if pnl > peak:
                peak = pnl
                peak_idx = i

            dd = peak - pnl
            if dd > max_dd:
                max_dd = dd
                max_duration = i - peak_idx

        return max_dd, max_duration

    @staticmethod
    def compute_trade_stats(trades: List[TradeRecord]) -> Dict:
        """
        Compute trade-level statistics.

        Args:
            trades: List of completed trades

        Returns:
            Dict with win_rate, profit_factor, avg_win, avg_loss, etc.
        """
        if not trades:
            return {
                "win_rate": 0.0,
                "profit_factor": 0.0,
                "avg_win": 0.0,
                "avg_loss": 0.0,
                "avg_holding_period": 0.0,
                "best_trade": 0.0,
                "worst_trade": 0.0,
            }

        wins = [t for t in trades if t.pnl > 0]
        losses = [t for t in trades if t.pnl < 0]

        total_wins = sum(t.pnl for t in wins)
        total_losses = abs(sum(t.pnl for t in losses))

        return {
            "win_rate": len(wins) / len(trades) if trades else 0.0,
            "profit_factor": total_wins / total_losses if total_losses > 0 else float("inf"),
            "avg_win": total_wins / len(wins) if wins else 0.0,
            "avg_loss": -total_losses / len(losses) if losses else 0.0,
            "avg_holding_period": sum(t.holding_days for t in trades) / len(trades),
            "best_trade": max(t.pnl for t in trades),
            "worst_trade": min(t.pnl for t in trades),
            "num_wins": len(wins),
            "num_losses": len(losses),
        }

    @staticmethod
    def leg_attribution(trades: List[TradeRecord]) -> Dict:
        """
        Break down P&L by leg (futures vs swap).

        Args:
            trades: List of completed trades

        Returns:
            Dict with leg-level P&L breakdown
        """
        if not trades:
            return {}

        total_futures_pnl = sum(t.futures_pnl for t in trades)
        total_swap_pnl = sum(t.swap_pnl for t in trades)
        total_pnl = sum(t.pnl for t in trades)

        return {
            "total_pnl": total_pnl,
            "futures_pnl": total_futures_pnl,
            "swap_pnl": total_swap_pnl,
            "futures_pct": total_futures_pnl / total_pnl * 100 if total_pnl != 0 else 0,
            "swap_pct": total_swap_pnl / total_pnl * 100 if total_pnl != 0 else 0,
            "avg_futures_price_change": (
                sum(t.exit_futures_price - t.entry_futures_price for t in trades) / len(trades)
            ),
            "avg_swap_rate_change_bp": (
                sum((t.exit_swap_rate - t.entry_swap_rate) * 10000 for t in trades) / len(trades)
            ),
        }

    @staticmethod
    def pnl_attribution(trades: List[TradeRecord]) -> Dict:
        """
        Break down P&L by various factors.

        Args:
            trades: List of completed trades

        Returns:
            Dict with P&L attribution breakdown
        """
        if not trades:
            return {}

        long_trades = [t for t in trades if t.direction == "long"]
        short_trades = [t for t in trades if t.direction == "short"]

        trades_with_rolls = [t for t in trades if t.ctd_rolls > 0]
        trades_without_rolls = [t for t in trades if t.ctd_rolls == 0]

        # Leg attribution
        leg_attr = Analytics.leg_attribution(trades)

        result = {
            "total_pnl": sum(t.pnl for t in trades),
            "futures_pnl": leg_attr.get("futures_pnl", 0),
            "swap_pnl": leg_attr.get("swap_pnl", 0),
            "long_pnl": sum(t.pnl for t in long_trades),
            "short_pnl": sum(t.pnl for t in short_trades),
            "num_long": len(long_trades),
            "num_short": len(short_trades),
            "pnl_with_ctd_rolls": sum(t.pnl for t in trades_with_rolls),
            "pnl_without_ctd_rolls": sum(t.pnl for t in trades_without_rolls),
            "num_trades_with_rolls": len(trades_with_rolls),
            "avg_spread_change_long": (
                sum(t.exit_spread_bp - t.entry_spread_bp for t in long_trades) / len(long_trades)
                if long_trades else 0.0
            ),
            "avg_spread_change_short": (
                sum(t.exit_spread_bp - t.entry_spread_bp for t in short_trades) / len(short_trades)
                if short_trades else 0.0
            ),
        }

        # Add leg attribution for long/short
        if long_trades:
            result["long_futures_pnl"] = sum(t.futures_pnl for t in long_trades)
            result["long_swap_pnl"] = sum(t.swap_pnl for t in long_trades)
        if short_trades:
            result["short_futures_pnl"] = sum(t.futures_pnl for t in short_trades)
            result["short_swap_pnl"] = sum(t.swap_pnl for t in short_trades)

        return result

    @staticmethod
    def monthly_returns(
        dates: List[date],
        daily_pnl: List[float],
    ) -> Dict[str, float]:
        """
        Aggregate returns by month.

        Args:
            dates: List of dates
            daily_pnl: List of daily P&L

        Returns:
            Dict mapping "YYYY-MM" -> monthly P&L
        """
        monthly = {}
        for dt, pnl in zip(dates, daily_pnl):
            key = dt.strftime("%Y-%m")
            monthly[key] = monthly.get(key, 0.0) + pnl
        return monthly


def print_backtest_summary(result: BacktestResult) -> None:
    """Print formatted backtest summary with leg attribution."""
    print("=" * 65)
    print("BACKTEST RESULTS")
    print("=" * 65)
    print(f"Period: {result.dates[0]} to {result.dates[-1]}")
    print(f"Trading Days: {len(result.dates)}")
    print("-" * 65)
    print("PERFORMANCE")
    print(f"  Total P&L:           ${result.total_pnl:>12,.0f}")
    print(f"    Futures P&L:       ${result.total_futures_pnl:>12,.0f}")
    print(f"    Swap P&L:          ${result.total_swap_pnl:>12,.0f}")
    print(f"  Sharpe Ratio:        {result.sharpe_ratio:>12.2f}")
    print(f"  Sortino Ratio:       {result.sortino_ratio:>12.2f}")
    print(f"  Max Drawdown:        ${result.max_drawdown:>12,.0f}")
    print(f"  Max DD Duration:     {result.max_drawdown_duration:>12} days")
    print(f"  Calmar Ratio:        {result.calmar_ratio:>12.2f}")
    print("-" * 65)
    print("TRADES")
    print(f"  Number of Trades:    {result.num_trades:>12}")
    print(f"  Win Rate:            {result.win_rate:>12.1%}")
    print(f"  Profit Factor:       {result.profit_factor:>12.2f}")
    print(f"  Avg Win:             ${result.avg_win:>12,.0f}")
    print(f"  Avg Loss:            ${result.avg_loss:>12,.0f}")
    print(f"  Avg Holding Period:  {result.avg_holding_period:>12.1f} days")
    print(f"  CTD Rolls:           {result.ctd_rolls_total:>12}")
    print("=" * 65)
