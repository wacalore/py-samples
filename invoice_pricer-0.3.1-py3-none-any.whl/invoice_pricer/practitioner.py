"""
Practitioner API for invoice spread trading.

Five core functions for daily trading workflow:
1. invoice_spread()         - Raw invoice spread (futures yield - swap rate)
2. invoice_spread_carry()   - Carry-adjusted spread (accounts for financing)
3. invoice_spread_adjusted() - Fully adjusted (carry + delivery options)
4. spread_to_swap_rate()    - Back out swap rate from target spread
5. swap_pnl()               - P&L and DV01 of a fixed-rate swap position

Example:
    >>> from invoice_pricer.practitioner import (
    ...     invoice_spread, spread_to_swap_rate, swap_pnl
    ... )
    >>> from invoice_pricer import build_curve
    >>>
    >>> # Build curve (smoothing spline, exact at input points)
    >>> curve = build_curve([1,2,5,10,30], [0.043,0.041,0.042,0.045,0.046])
    >>>
    >>> # 1. Raw spread
    >>> spread = invoice_spread(110.25, 0.8456, 0.04125, 9.5, 0.12, curve)
    >>> print(f"Spread: {spread.spread_bp:+.1f} bp")
    >>>
    >>> # 2. What swap rate for -10bp spread?
    >>> rate = spread_to_swap_rate(-10.0, 110.25, 0.8456, 0.04125, 9.5)
    >>> print(f"Swap rate: {rate*100:.4f}%")
    >>>
    >>> # 3. Swap P&L
    >>> pnl = swap_pnl(0.035, 7.5, 10_000_000, curve)
    >>> print(f"NPV: ${pnl.npv:,.0f}, DV01: ${pnl.dv01:,.0f}")
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

import numpy as np

from .curves import SwapCurve
from .bonds import Bond, TreasuryBond, bond_yield, bond_price
from .delivery_option import estimate_delivery_option_value, FuturesContract


# =============================================================================
# CORE DATA STRUCTURES
# =============================================================================

@dataclass(frozen=True)
class SpreadResult:
    """Invoice spread calculation result."""
    spread_bp: float          # Invoice spread in basis points
    futures_yield: float      # Implied yield from futures
    swap_rate: float          # Forward swap rate
    futures_dv01: float       # DV01 per contract ($)


@dataclass(frozen=True)
class CarrySpreadResult:
    """Carry-adjusted invoice spread result."""
    spread_bp: float          # Carry-adjusted spread (bp)
    raw_spread_bp: float      # Raw spread before carry (bp)
    carry_bp: float           # Carry adjustment (bp)
    futures_yield: float      # Carry-adjusted implied yield
    swap_rate: float          # Forward swap rate
    net_carry: float          # Net carry in price points


@dataclass(frozen=True)
class AdjustedSpreadResult:
    """Fully adjusted invoice spread (carry + delivery options)."""
    spread_bp: float          # Fully adjusted spread (bp)
    raw_spread_bp: float      # Raw spread (bp)
    carry_bp: float           # Carry adjustment (bp)
    option_bp: float          # Delivery option adjustment (bp)
    futures_yield: float      # Adjusted implied yield
    swap_rate: float          # Forward swap rate
    option_ticks: float       # Option value in 32nds


@dataclass(frozen=True)
class SwapPnL:
    """Swap P&L and risk metrics."""
    npv: float                # Net present value ($)
    dv01: float               # Dollar value of 1bp ($)
    pnl_bp: float             # P&L in basis points
    fixed_rate: float         # Trade fixed rate
    market_rate: float        # Current par rate


# =============================================================================
# 1. RAW INVOICE SPREAD
# =============================================================================

def invoice_spread(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
    curve: SwapCurve,
) -> SpreadResult:
    """
    Compute raw invoice spread in basis points.

    Invoice Spread = Futures Implied Yield - Forward Swap Rate

    This is the "headline" spread without carry or option adjustments.
    Use for quick relative value screening.

    Args:
        futures_price: Treasury futures price (e.g., 110.25)
        conversion_factor: CTD bond conversion factor
        coupon: CTD annual coupon (decimal, e.g., 0.04125)
        maturity_years: CTD years to maturity from today
        delivery_years: Years to futures delivery
        curve: SOFR swap curve

    Returns:
        SpreadResult with spread_bp, yields, and DV01

    Example:
        >>> spread = invoice_spread(110.25, 0.8456, 0.04125, 9.5, 0.12, curve)
        >>> print(f"{spread.spread_bp:+.1f} bp")
    """
    # Implied bond price and yield
    implied_price = futures_price * conversion_factor
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    futures_yield = bond_yield(bond, implied_price)

    # Forward swap rate (delivery → maturity)
    swap_rate = curve.swap_rate(delivery_years, maturity_years)

    # Invoice spread
    spread_bp = (futures_yield - swap_rate) * 10000

    # Futures DV01 (per $100k contract)
    bond_dv01 = _bond_dv01(bond, futures_yield)
    futures_dv01 = (bond_dv01 / conversion_factor) * 1000

    return SpreadResult(
        spread_bp=spread_bp,
        futures_yield=futures_yield,
        swap_rate=swap_rate,
        futures_dv01=futures_dv01,
    )


# =============================================================================
# 2. CARRY-ADJUSTED INVOICE SPREAD
# =============================================================================

def invoice_spread_carry(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
    curve: SwapCurve,
    spot_price: float,
    repo_rate: float,
) -> CarrySpreadResult:
    """
    Compute carry-adjusted invoice spread.

    Accounts for the financing cost of holding the CTD bond to delivery.
    The theoretical futures price is:

        Forward = (Spot + Financing - Coupon Income) / CF

    If market futures < theoretical → negative carry (futures cheap)
    If market futures > theoretical → positive carry (futures rich)

    Args:
        futures_price: Market treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD annual coupon (decimal)
        maturity_years: CTD years to maturity
        delivery_years: Years to delivery
        curve: SOFR swap curve
        spot_price: CTD clean spot price
        repo_rate: Term repo rate to delivery (decimal)

    Returns:
        CarrySpreadResult with raw and adjusted spreads

    Example:
        >>> result = invoice_spread_carry(
        ...     110.25, 0.8456, 0.04125, 9.5, 0.12, curve,
        ...     spot_price=93.50, repo_rate=0.0435
        ... )
        >>> print(f"Raw: {result.raw_spread_bp:+.1f} bp")
        >>> print(f"Carry-adj: {result.spread_bp:+.1f} bp")
    """
    # Raw spread first
    raw = invoice_spread(
        futures_price, conversion_factor, coupon,
        maturity_years, delivery_years, curve
    )

    # Carry calculation
    # Financing cost = spot_price × repo_rate × time
    financing = spot_price * repo_rate * delivery_years

    # Coupon income (simple accrual for short periods)
    coupon_income = 100.0 * coupon * delivery_years

    # Net carry (positive = carry is in your favor)
    net_carry = coupon_income - financing

    # Theoretical forward price
    forward_price = spot_price + financing - coupon_income
    theoretical_futures = forward_price / conversion_factor

    # Carry-adjusted yield
    carry_adjusted_price = theoretical_futures * conversion_factor
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    carry_yield = bond_yield(bond, carry_adjusted_price)

    # Carry-adjusted spread
    swap_rate = curve.swap_rate(delivery_years, maturity_years)
    carry_spread_bp = (carry_yield - swap_rate) * 10000
    carry_bp = carry_spread_bp - raw.spread_bp

    return CarrySpreadResult(
        spread_bp=carry_spread_bp,
        raw_spread_bp=raw.spread_bp,
        carry_bp=carry_bp,
        futures_yield=carry_yield,
        swap_rate=swap_rate,
        net_carry=net_carry,
    )


# =============================================================================
# 3. FULLY ADJUSTED SPREAD (CARRY + OPTIONS)
# =============================================================================

def invoice_spread_adjusted(
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
    delivery_years: float,
    curve: SwapCurve,
    spot_price: float,
    repo_rate: float,
    contract: str = "TY",
    yield_vol_bp: float = 100.0,
) -> AdjustedSpreadResult:
    """
    Compute fully adjusted invoice spread (carry + delivery options).

    This is the "true" spread for relative value analysis. It accounts for:
    1. CARRY: Financing cost vs coupon income
    2. OPTIONS: Delivery optionality that makes futures trade cheap

    The delivery option adjustment adds value to futures (tightens the spread)
    because the short has embedded options that aren't reflected in the price.

    Args:
        futures_price: Market treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD annual coupon (decimal)
        maturity_years: CTD years to maturity
        delivery_years: Years to delivery
        curve: SOFR swap curve
        spot_price: CTD clean spot price
        repo_rate: Term repo rate to delivery (decimal)
        contract: Contract type ("TU", "FV", "TY", "US", "WN")
        yield_vol_bp: Yield volatility in bp (default 100)

    Returns:
        AdjustedSpreadResult with full breakdown

    Example:
        >>> result = invoice_spread_adjusted(
        ...     110.25, 0.8456, 0.04125, 9.5, 0.12, curve,
        ...     spot_price=93.50, repo_rate=0.0435,
        ...     contract="TY", yield_vol_bp=100,
        ... )
        >>> print(f"Raw:      {result.raw_spread_bp:+.1f} bp")
        >>> print(f"Carry:    {result.carry_bp:+.1f} bp")
        >>> print(f"Options:  {result.option_bp:+.1f} bp")
        >>> print(f"Adjusted: {result.spread_bp:+.1f} bp")
    """
    # Get raw spread
    raw = invoice_spread(
        futures_price, conversion_factor, coupon,
        maturity_years, delivery_years, curve
    )

    # Carry calculation
    financing = spot_price * repo_rate * delivery_years
    coupon_income = 100.0 * coupon * delivery_years
    forward_price = spot_price + financing - coupon_income
    theoretical_futures = forward_price / conversion_factor

    # Carry-adjusted yield
    carry_adjusted_price = theoretical_futures * conversion_factor
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    carry_yield = bond_yield(bond, carry_adjusted_price)
    carry_bp = (carry_yield - raw.futures_yield) * 10000

    # Delivery option value
    contract_enum = getattr(FuturesContract, contract.upper(), FuturesContract.TY)
    days_to_delivery = int(delivery_years * 365)
    option_value = estimate_delivery_option_value(
        contract=contract_enum,
        days_to_delivery=days_to_delivery,
        yield_vol_bp=yield_vol_bp,
    )
    option_ticks = option_value.total_ticks

    # Option-adjusted yield (add option value to theoretical futures)
    option_price_adj = option_ticks / 32.0
    adjusted_futures = theoretical_futures + option_price_adj
    adjusted_price = adjusted_futures * conversion_factor
    adjusted_yield = bond_yield(bond, adjusted_price)
    option_bp = (adjusted_yield - carry_yield) * 10000

    # Final adjusted spread
    swap_rate = curve.swap_rate(delivery_years, maturity_years)
    adjusted_spread_bp = (adjusted_yield - swap_rate) * 10000

    return AdjustedSpreadResult(
        spread_bp=adjusted_spread_bp,
        raw_spread_bp=raw.spread_bp,
        carry_bp=carry_bp,
        option_bp=option_bp,
        futures_yield=adjusted_yield,
        swap_rate=swap_rate,
        option_ticks=option_ticks,
    )


# =============================================================================
# 4. SPREAD TO SWAP RATE
# =============================================================================

def spread_to_swap_rate(
    target_spread_bp: float,
    futures_price: float,
    conversion_factor: float,
    coupon: float,
    maturity_years: float,
) -> float:
    """
    Back out the swap rate needed to achieve a target invoice spread.

    Given: Invoice Spread = Futures Yield - Swap Rate
    Solve: Swap Rate = Futures Yield - Spread

    Use this to find execution levels for invoice spread trades.

    Args:
        target_spread_bp: Target invoice spread in basis points
        futures_price: Treasury futures price
        conversion_factor: CTD conversion factor
        coupon: CTD annual coupon (decimal)
        maturity_years: CTD years to maturity

    Returns:
        Required swap rate (decimal)

    Example:
        >>> # What swap rate for a -10bp invoice spread?
        >>> rate = spread_to_swap_rate(-10.0, 110.25, 0.8456, 0.04125, 9.5)
        >>> print(f"Execute swap at {rate*100:.4f}%")
    """
    # Futures implied yield
    implied_price = futures_price * conversion_factor
    bond = Bond(coupon=coupon, maturity_years=maturity_years)
    futures_yield = bond_yield(bond, implied_price)

    # Swap rate = yield - spread
    return futures_yield - (target_spread_bp / 10000)


# =============================================================================
# 4. SWAP P&L AND DV01
# =============================================================================

def swap_pnl(
    fixed_rate: float,
    remaining_years: float,
    notional: float,
    curve: SwapCurve,
    *,
    payer: bool = True,
) -> SwapPnL:
    """
    Compute P&L and DV01 of an existing fixed-rate swap.

    Args:
        fixed_rate: The swap's fixed rate (decimal, e.g., 0.035 for 3.5%)
        remaining_years: Years remaining to maturity
        notional: Swap notional amount
        curve: Current SOFR swap curve
        payer: True = pay fixed (default), False = receive fixed

    Returns:
        SwapPnL with npv, dv01, and pnl_bp

    Example:
        >>> pnl = swap_pnl(0.035, 7.5, 10_000_000, curve, payer=True)
        >>> print(f"NPV: ${pnl.npv:,.0f}")
        >>> print(f"DV01: ${pnl.dv01:,.0f}")
        >>> print(f"P&L: {pnl.pnl_bp:+.1f} bp")
    """
    # Get discount factors and annuity
    df_start = curve.df(0.0)
    df_end = curve.df(remaining_years)
    annuity = curve.annuity(0.0, remaining_years)

    # Fixed and floating leg PVs
    fixed_leg_pv = fixed_rate * notional * annuity
    float_leg_pv = notional * (df_start - df_end)

    # NPV
    if payer:
        npv = float_leg_pv - fixed_leg_pv
    else:
        npv = fixed_leg_pv - float_leg_pv

    # DV01 (using annuity)
    dv01 = notional * annuity * 0.0001

    # Market rate and P&L
    market_rate = (df_start - df_end) / annuity
    if payer:
        pnl_bp = (market_rate - fixed_rate) * 10000
    else:
        pnl_bp = (fixed_rate - market_rate) * 10000

    return SwapPnL(
        npv=npv,
        dv01=dv01,
        pnl_bp=pnl_bp,
        fixed_rate=fixed_rate,
        market_rate=market_rate,
    )


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def _bond_dv01(bond: Bond, ytm: float) -> float:
    """Fast DV01 calculation using closed-form modified duration."""
    c = bond.coupon / 2
    n = int(bond.maturity_years * 2 + 0.5)
    y = ytm / 2
    F = bond.face

    if abs(y) < 1e-10:
        return bond.maturity_years * bond.face * 0.0001

    v = 1.0 / (1.0 + y)
    v_n = v ** n

    # Price
    price = (c * F * (1.0 - v_n) / y) + (F * v_n)

    # Macaulay duration (closed form)
    if abs(bond.coupon) < 1e-10:
        mac_dur = bond.maturity_years
    else:
        mac_dur = ((1 + y) / y) - ((1 + y + n * (c - y)) / (bond.coupon * ((1 + y) ** n - 1) + 2 * y))
        mac_dur *= 0.5  # Convert to years

    # Modified duration
    mod_dur = mac_dur / (1 + y)

    return mod_dur * price * 0.0001
