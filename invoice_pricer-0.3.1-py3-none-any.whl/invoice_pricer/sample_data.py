"""Sample data generation for testing and development."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import NamedTuple

import numpy as np

from .bonds import Bond
from .curves import SwapCurve, bootstrap_swap_curve


class SofrCurveData(NamedTuple):
    """SOFR swap curve market data."""
    tenors: list[float]  # Years
    rates: list[float]   # Decimal rates


class CTDSpec(NamedTuple):
    """Cheapest-to-deliver bond specification."""
    coupon: float           # Annual coupon (decimal)
    maturity_years: float   # Years to maturity
    conversion_factor: float


class FuturesData(NamedTuple):
    """Treasury futures market data."""
    contract: str           # e.g., "TYH5" for 10Y Mar 2025
    price: float            # Futures price (e.g., 110.5)
    delivery_date: date     # First delivery date
    ctd: CTDSpec


def sample_sofr_curve() -> SofrCurveData:
    """
    Generate realistic SOFR swap curve (as of late 2024).

    Returns slightly inverted curve typical of tightening cycle end.
    """
    tenors = list(range(1, 41))  # 1Y to 40Y

    # Realistic curve shape: inverted short end, upward sloping long end
    rates = []
    for t in tenors:
        if t <= 2:
            # Short end inverted (Fed cutting expectations)
            r = 0.0475 - 0.003 * t
        elif t <= 5:
            # Transition zone
            r = 0.0445 + 0.002 * (t - 2)
        elif t <= 10:
            # Belly
            r = 0.0455 + 0.001 * (t - 5)
        else:
            # Long end - gradual steepening
            r = 0.0465 + 0.0003 * (t - 10)
        rates.append(r)

    return SofrCurveData(tenors=tenors, rates=rates)


def sample_10y_futures() -> FuturesData:
    """Sample 10-year treasury futures (TY contract)."""
    return FuturesData(
        contract="TYH5",
        price=110.25,  # 110-08 in 32nds
        delivery_date=date(2025, 3, 1),
        ctd=CTDSpec(
            coupon=0.04125,      # 4.125% coupon
            maturity_years=9.5,  # ~9.5 years remaining
            conversion_factor=0.8456,
        )
    )


def sample_5y_futures() -> FuturesData:
    """Sample 5-year treasury futures (FV contract)."""
    return FuturesData(
        contract="FVH5",
        price=107.75,
        delivery_date=date(2025, 3, 1),
        ctd=CTDSpec(
            coupon=0.0425,       # 4.25% coupon
            maturity_years=4.75,
            conversion_factor=0.9123,
        )
    )


def sample_30y_futures() -> FuturesData:
    """Sample 30-year treasury futures (US contract)."""
    return FuturesData(
        contract="USH5",
        price=118.50,
        delivery_date=date(2025, 3, 1),
        ctd=CTDSpec(
            coupon=0.0375,       # 3.75% coupon
            maturity_years=28.5,
            conversion_factor=0.7234,
        )
    )


def sample_2y_futures() -> FuturesData:
    """Sample 2-year treasury futures (TU contract)."""
    return FuturesData(
        contract="TUH5",
        price=103.125,
        delivery_date=date(2025, 3, 1),
        ctd=CTDSpec(
            coupon=0.0475,       # 4.75% coupon
            maturity_years=1.8,
            conversion_factor=0.9678,
        )
    )


def sample_ultra_futures() -> FuturesData:
    """
    Sample Ultra Bond futures (WN contract).

    The Ultra Bond contract covers treasury bonds with remaining
    maturity of at least 25 years. CTD is typically a very long-dated
    bond with significant duration and convexity.
    """
    return FuturesData(
        contract="WNH5",
        price=126.75,
        delivery_date=date(2025, 3, 1),
        ctd=CTDSpec(
            coupon=0.03,         # 3.0% coupon (low coupon long bond)
            maturity_years=29.5, # ~29.5 years remaining
            conversion_factor=0.6512,
        )
    )


def build_sample_curve(value_date: date | None = None) -> SwapCurve:
    """
    Build a complete sample SOFR curve.

    Args:
        value_date: Curve valuation date (defaults to today-ish)

    Returns:
        Bootstrapped SwapCurve
    """
    if value_date is None:
        value_date = date(2025, 1, 15)

    data = sample_sofr_curve()
    return bootstrap_swap_curve(
        value_date=value_date,
        tenors_years=data.tenors,
        swap_rates=data.rates,
    )


@dataclass
class SampleScenario:
    """Complete scenario for testing invoice spread calculations."""
    curve: SwapCurve
    futures: FuturesData
    value_date: date


def get_sample_scenario(
    contract: str = "TY",
    value_date: date | None = None,
) -> SampleScenario:
    """
    Get a complete sample scenario for testing.

    Args:
        contract: Contract type ("TU", "FV", "TY", "US", "WN")
        value_date: Valuation date

    Returns:
        Complete scenario with curve and futures data
    """
    if value_date is None:
        value_date = date(2025, 1, 15)

    curve = build_sample_curve(value_date)

    futures_map = {
        "TU": sample_2y_futures,
        "FV": sample_5y_futures,
        "TY": sample_10y_futures,
        "US": sample_30y_futures,
        "WN": sample_ultra_futures,
    }

    futures_fn = futures_map.get(contract.upper(), sample_10y_futures)
    futures = futures_fn()

    return SampleScenario(
        curve=curve,
        futures=futures,
        value_date=value_date,
    )
